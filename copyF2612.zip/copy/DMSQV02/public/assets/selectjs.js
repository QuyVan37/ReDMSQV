'use strict'
{
    // HƯỚNG DẪN SỬ DỤNG
    // thêm class selectjs vào the select sẽ tự động được apply thư viện này
    // nếu multiplie select => thêm property "multiple" vào thẻ select
    // vd:
    // <div>
    //     <select class="selectjs" multiple>
    //         <option value="">---</option>
    //         <option value="1">1</option>
    //         <option value="2">2</option>
    //         <option value="3">3</option>
    //         <option value="4">4</option>
    //     </select>
    // </div>
    
    selectjs()
    function selectjs() {
       
        $(document).ready(function () {
            let selectElement
            let rundomName = generateRandomString(6)
            // get all thẻ select có class selectjs có thuộc tính mutiple và chuyển sang thẻ select thường
            // thêm nhận biết bằng thuộc tính "_multiple"
            let multipSelects = $('select.selectjs[multiple]').get()
            
            for (let sele of multipSelects) {
                let checkedValues = $(sele).val()
                if (checkedValues.length > 0) {
                    let optionsData = getOptionData(sele)
                    let view = []
                    for (let data of optionsData) {
                        for (let val of checkedValues) {
                            if (data.value == val) {
                                view.push(data.name)
                            }
                        }
                    }
                    addResultOption(sele, checkedValues, view)
                }

                $(sele).prop('multiple', false)
                $(sele).attr('_multiple', '_multiple')
            }


            $(document).on('focus', 'select.selectjs', function (e) {
                selectElement = e.target

                $(selectElement).attr("disabled", 'disabled')
                let optionsData = getOptionData(selectElement)


                // create container
                createContainer()
                $(window).on('resize', function () {
                    let width = $(selectElement).parent().width()
                    $('.selecjs_option_container').css({
                        'width': width,
                    })
                })

                // show option
                let ismultiple = $(e.currentTarget).attr('_multiple')
               
                showOption(selectElement, optionsData, ismultiple, rundomName)
                $('.searchOption').focus()


                // search
                $('.selecjs_option_container .searchOption').on('input', function () {
                    let searchValue = $(this).val().toLocaleLowerCase()
                    dataSearchResult = []
                    for (let item of optionsData) {
                        if (item.name.toLocaleLowerCase().includes(searchValue)) {
                            dataSearchResult.push(item)
                        }
                    }
                    let resultSearch = debounce(() => showOption(selectElement, dataSearchResult, ismultiple, rundomName))
                    resultSearch()
                })

                // user Chose option
                $(document).on('change', `input[name=${rundomName}]`, function(e){
                    inputE = e.currentTarget
                    if ($(inputE).val() == '') {
                        $(`input:checkbox:checked[name=${rundomName}]`).prop('checked', false)
                        $(`input:checkbox[name=${rundomName}][value='']`).prop('checked', 'checked')
                    } else {
                        $(`input:checkbox[name=${rundomName}][value='']`).prop('checked', false)
                    }

                    renderValueInactualSelection(selectElement, ismultiple, rundomName, optionsData)
                })

               

            })


            $(document).on('click', function (evt) {
                let selecjs_option_container = document.querySelector('.selecjs_option_container'),
                    targetEl = evt.target; // clicked element      
                do {
                    if (targetEl == selecjs_option_container) {
                        // This is a click inside, does nothing, just return.

                        return;
                    }
                    // Go up the DOM
                    targetEl = targetEl.parentNode;
                } while (targetEl);
                // This is a click outside.

                close()

            })


            function getOptionData(selectElement) {
                let optionsData = []
                $(selectElement).children('option').each(function (index, element) {
                    if (!$(element).hasClass('resultSelected')) {
                        optionsData.push({
                            index: index,
                            value: $(element).val(),
                            name: $(element).text(),
                        })
                    }

                })
                return optionsData
            }


            function renderValueInactualSelection(selectElement, ismultiple, rundomName, optionsData) {
                if (ismultiple) {
                    var checkedValues = $(`input:checkbox:checked[name=${rundomName}]`).map(function () {
                        return this.value;
                    }).get();

                    let view = []
                    for (let data of optionsData) {
                        for (let val of checkedValues) {
                            if (data.value == val) {
                                view.push(data.name)
                            }
                        }
                    }
                    addResultOption(selectElement, checkedValues, view)

                } else {
                    let checkedValues = $(`input:radio:checked[name=${rundomName}]`).val()
                    $(selectElement).val(checkedValues)
                }

            }


            function close() {

                $('select.selectjs').removeAttr("disabled")
                $('.selecjs_option_container').remove()
            }

            function createContainer() {
                // lấy current width của thẻ select
                let width = $(selectElement).parent().width()
                // tao 1 vung để search
                $('.selecjs_option_container').remove()
                $(selectElement).parent().append(`
                     <div class="selecjs_option_container overflow-y-auto">
                         <div class="nice-form-group formSearchOption">
                             <input type="search" autofocus class="searchOption" placeholder="Search">
                         </div>
                         <div class="selecjs_option_render">
                         
                         </div>
                     </div>`)
                $('.selecjs_option_container .formSearchOption').css({
                    'background': '#fff',
                    'position': 'sticky',
                    'top': '0',
                    'padding': '3px',
                    'z-index': '100'
                })
                $('.selecjs_option_container').parent().css('position', 'relative')
                $('.selecjs_option_container').css({
                    'width': width,
                    'min-width':'250px',
                    'height': 'auto',
                    'max-height': '250px',
                    'background': '#fff',
                    'z-index': 100,
                    "border-radius": '5px',
                    'padding': '5px 20px',
                    'over-flow-y': 'auto',
                    'position': 'absolute',
                    'box-shadow': '5px 5px 20px',
                    'color': '#000'

                })
            }

            function addResultOption(selectElement, values, view) {
                $(selectElement).children('option.resultSelected').remove()
                $(selectElement).append(`<option class="resultSelected" value="${values}">${view.join(', ')}</option>`)
                $(selectElement).val(values.join(','))
                $(selectElement).attr('title', view.join(', '))
            }

            function showOption(selectElement, optionsData, ismultiple, name) {
                // neu multip select
                let optionsShow = ''
                if (optionsData.length == 0) {
                    optionsShow = "Not found!"
                }
                let checkedValues = $(selectElement).val()

                if (ismultiple) {
                    optionsData.forEach(op => {
                        let checked = checkedValues.includes(op.value) ? "checked" : ""
                        if (checkedValues.length > 0 && op.value == '') {
                            checked = ''
                        }
                        let rundomID = generateRandomString(5)
                        optionsShow += ` <label style="margin:2px; padding:10px; display: block" for="${rundomID}"><input type="checkbox" ${checked} name="${name}" id="${rundomID}" value="${op.value}"/> ${op.name}</label> <hr style="margin:0" />`
                    })
                } else {
                    optionsData.forEach(op => {
                        let rundomID = generateRandomString(5)
                        let checked = checkedValues.includes(op.value) ? "checked" : ""
                        optionsShow += ` <label style="margin:2px; padding:10px; display: block" for="${rundomID}"><input type="radio" ${checked} name="${name}" id="${rundomID}" value="${op.value}"/> ${op.name}</label><hr style="margin:0" />`
                    })
                }
                $('.selecjs_option_render').empty().append(optionsShow)
            }

            function generateRandomString(length) {
                let result = '';
                const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
                const charactersLength = characters.length;

                for (let i = 0; i < length; i++) {
                    result += characters.charAt(Math.floor(Math.random() * charactersLength));
                }
                return result;
            }

            function debounce(func, timeout = 300) {

                let timer;
                return (...args) => {
                    clearTimeout(timer);
                    timer = setTimeout(() => {
                        func.apply(this, args);
                    }, timeout);
                };
            }

        })
    }

}
