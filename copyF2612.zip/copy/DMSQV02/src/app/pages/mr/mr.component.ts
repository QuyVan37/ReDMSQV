import { Component, AfterViewInit, OnDestroy, Renderer2, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Config } from 'datatables.net';
import { AuthenService } from '../../API-Services/authen.service';
import { Router } from '@angular/router';
import { DOMServiceService } from '../../common-services/dom-service.service';
import { AppAPIService } from '../../API-Services/app-api.service';
import { Subject } from 'rxjs';

import moment from 'moment';
const apexChart = import('apexcharts');
declare var $: any;
declare var bootstrap: any;
declare var Validator: any;
declare var DataTable: any;


@Component({
  selector: 'app-mr',
  templateUrl: './mr.component.html',
  styleUrl: './mr.component.css',
  host: { ngSkipHydration: 'true' },
})
export class MrComponent {
  private eventListener!: () => void;

  constructor(
    private authen: AuthenService,
    private router: Router,
    private DOMService: DOMServiceService,
    private APIservices: AppAPIService,
    private renderer: Renderer2,


  ) { }


  APIHost = 'http://localhost:5019'
  dept: string = JSON.parse(localStorage.getItem('user') ?? '[]').map((x: any) => x.dept_name)

  mr_role_id: number = 0;
  admin = false;
  searchParameter = {
    page: 1,
    search: '',
  }

  dtOptions: any = {
    serverSide: false,
    paging: false,
    ordering: false,
    select: true, keys: true,
    scrollY: '300',
    scrollX: true,
    fixedColumns: {
      left: 3,
      right: 0
    },
    rowId: 'mr_id',
    searching: false,
    createdRow: (row: any, data: any, index: any) => {
      // if (data[5].replace(/[\$,]/g, '') * 1 > 150000) {
      //     row.querySelector(':nth-child(6)').classList.add('highlight');
      // }

    },
    columns: [
      {
        title: `<label for='selectAll'>Select All </label><input class="selectAll" id='selectAll' type='checkbox'/>`,
        data: 'mr_id',
        render: function (data: any, type: any, row: any) {
          return `<input type='checkbox' value='${data}' name='row_mr_id'/> `
        }
      },
      {
        title: 'MRNo',
        data: 'mr_no',
        render: function (data: any, type: any, row: any) {
          return `<a title='click to download MR form' class='cursor text-primary download-mr'  data-mr-id = '${row.mr_id}'>${data}</a>`
        }
      },
      {
        title: 'Part No',
        data: 'part_no',
      },
      {
        title: 'Dim',
        data: 'clasification'
      },
      {
        title: 'DieID',
        data: 'die_no'
      },
      {
        title: 'Status',
        data: 'status',
        render: function (data: any, type: any, row: any) {
          return `<button style="min-width:150px" class="btn btn-sm btn-primary btn_show_modal_MR_detail" data-mr-id='${row.mr_id}'>${data}</button>`
        }
      },
      {
        title: 'Order To',
        data: 'order_to'
      },
      {
        title: 'vendor',
        data: 'supplier_code'
      },
      {
        title: 'Model',
        data: 'model_name'
      },
      {
        title: 'Process Code',
        data: 'process_code'
      },
      {
        title: 'Reason',
        data: 'reason'
      },
      {
        title: 'ECN No',
        data: 'ecn_no'
      },
      {
        title: 'His',
        data: 'draw_his'
      },
      {
        title: 'PDD',
        data: 'pdd',
        render: function (data: any, type: any, row: any) {
          return moment(data).format('YYYY/MM/DD')
        }
      },
      {
        title: 'Request',
        data: 'request_by'
      },
      {
        title: 'Date',
        data: 'request_date',
        render: function (data: any, type: any, row: any) {
          return moment(data).format('YYYY/MM/DD hh:mm A')
        }
      },
    ]
  };
  dtTrigger: Subject<any> = new Subject();
  ngOnInit(): void {
    this.authen.checkLoginAndHandle()
    this.mr_role_id = this.authen.getRoleForFucntion('mr_role_id')
    this.renderChartMR()
    let _that = this
    // start render
    //render search areas
    this.createMRtypeOptionElement()
    this.createSupplierListOptionElement()
    this.createModelOptionElement()
    this.createProcesCodeOptionElement()
    this.createOrderToListOptionElement()
    //rendertable
    // user nào thì lấy pending item của user đó
    let renderTableByUserResponse = this.APIservices.getSumarizeMRPending().subscribe(res => {
      let users = this.authen.isLogined().user
      res.data.forEach((status: any) => {
        users.forEach((u: any) => {
          if (status.dept_res.includes(u.dept_name) && status.mr_role_id_res == u.mr_role_id && u.factory == "QV" && status.qty > 0) {
            this.searchParameter.search = status.status
            return
          }
        })
      })
      this.renderTable(this.searchParameter)
    })




    // Handle sự kiện click ngoài angular
    this.eventListener = this.renderer.listen(document, "click", function (e) {
      //trường hợp user click vào page
      // => add page vào object searchParameter => render lại table
      let page = $(e.target).attr('data-page')
      if (page) {
        let isnewpage = _that.searchParameter.page != page
        if (isnewpage) {
          _that.searchParameter.page = page
          _that.renderTable(_that.searchParameter)
        }
      }

      //trường hợp user click vào Downloard MR form
      let isClickDownloadMR = $(e.target).hasClass('download-mr')
      if (isClickDownloadMR) {
        let mr_id = $(e.target).attr('data-mr-id')
        _that.downloadMRformByID(mr_id)
      }

      //trường hợp user click vào Show MR detail
      let isClickShowMR = $(e.target).hasClass('btn_show_modal_MR_detail')
      if (isClickShowMR) {
        let mr_id = $(e.target).attr('data-mr-id')
        _that.showMRDetail(mr_id)
      }

      //trường hợp user click vào btn_check_MR
      let isClickApprovekMR = $(e.target).hasClass('btn_Approve_MR')
      if (isClickApprovekMR) {
        let mr_id = $(e.target).attr('data-mr-id')
        let isPAETurn = $(e.target).attr('data-is-pae-turn')
        isPAETurn = isPAETurn === "true" ? true : false
        _that.approveMR(mr_id, isPAETurn)
      }

      //trường hợp user click vào btn_check_MR
      let isClickCheckMR = $(e.target).hasClass('btn_check_MR')
      if (isClickCheckMR) {
        let mr_id = $(e.target).attr('data-mr-id')
        let isPAETurn = $(e.target).attr('data-is-pae-turn')
        isPAETurn = isPAETurn === "true" ? true : false
        _that.checkMR(mr_id, isPAETurn)
      }

      //trường hợp user click vào btn_check_MR
      let isClickRejectMR = $(e.target).hasClass('btn_reject_MR')
      if (isClickRejectMR) {
        let mr_id = $(e.target).attr('data-mr-id')
        _that.rejectMR(mr_id)
      }

      //trường hợp user click vào selectAll
      let isClickSelectAll = $(e.target).hasClass('selectAll')
      if (isClickSelectAll) {

        let isSelectAll = $(e.target).prop('checked')
        _that.selectAll(isSelectAll)
      }

      //trường hợp user click vào class download-attach
      let isClickDownloadAtt = $(e.target).hasClass('download-attach')
      if (isClickDownloadAtt) {

        let path = $(e.target).attr('data-att-path')
        _that.downloadAttach(path)
      }
    })






  }



  ngOnDestroy() {
    if (this.eventListener) {
      this.eventListener();
    }
  }

  async renderTable(searchParameter: any) {
    this.DOMService.onloading('.btn_search')
    let _that = this
    this.dtOptions.destroy = true,
      this.dtOptions.processing = true;
    let dataResult = await this.APIservices.getMRList(searchParameter).toPromise()
    if (dataResult?.status == false) {
      this.DOMService.showAlertMassage(dataResult.msg, false)
      return
    }
    this.dtOptions.data = dataResult?.data
    this.DOMService.pagination(dataResult?.page, dataResult?.pageSize, dataResult?.recordsTotal, '.render_paganation')
    this.dtTrigger.next(null)
    _that.DOMService.onloaded('.btn_search')
  }

  async createMRtypeOptionElement() {
    let mrTypeCategory = await this.APIservices.getMRTypeCategory().toPromise()
    let result = this.DOMService.createOptionElement(mrTypeCategory?.data, ["type"], "mr_type_id", "")
    this.DOMService.appendToElement("select[name=mr_type_id]", result)
  }

  async createProcesCodeOptionElement() {
    let mrTypeCategory = await this.APIservices.getProcessCodeCategory().toPromise()
    let result = this.DOMService.createOptionElement(mrTypeCategory?.data, ["type"], "proces_id", "")
    this.DOMService.appendToElement("select[name=process_code_id]", result)
  }

  async createModelOptionElement() {
    let modelList = await this.APIservices.getModelList().toPromise()
    let result = this.DOMService.createOptionElement(modelList?.data, ["model_name"], "model_id", "")
    this.DOMService.appendToElement("select[name=model_id]", result)
  }

  async createSupplierListOptionElement() {
    let suppliers = await this.APIservices.getSupplierList().toPromise()
    let result = this.DOMService.createOptionElement(suppliers?.data, ["supplier_code", 'supplier_name'], "supplier_id", "")
    this.DOMService.appendToElement("select[name=supplier_id]", result)
  }

  async createOrderToListOptionElement() {
    let suppliers = await this.APIservices.getSupplierList().toPromise()
    let result = this.DOMService.createOptionElement(suppliers?.data, ["supplier_code", 'supplier_name'], "supplier_code", "")
    this.DOMService.appendToElement("select[name=order_to]", result)
  }

  showAll() {
    this.searchParameter = {
      page: 1,
      search: '',
    }
    this.renderTable(this.searchParameter)
  }

  searchMR() {
    let _that = this
    Validator({
      form: '#form_Search',
      formGroupSelector: '.nice-form-group',
      rules: [

      ],
      onSubmit: async function (data: any) {
        _that.searchParameter = { ..._that.searchParameter, ...data }
        _that.renderTable(data)

      }
    })
  }


  showModelIsueMR() {
    $('#form_issue_MR')[0].reset()
    $('#form_issue_MR').find('small').text('')
    const modalMassage = new bootstrap.Modal('#modal_issueMR', {
      keyboard: true
    })
    modalMassage.show()
  }

  clearInput() {
    $('input[name=die_no]').val('')
    $('input[name=his]').val('')
    $('input[name=ecn_no]').val('')
    $('input[name=part_name]').val('')
    $('select[name=process_code_id]').val('')
    $('select[name=model_id]').val('')
    $('select[name=supplier_id]').val('')
    $('input[name=mc_size]').val('')
    $('input[name=cav_qty]').val('')
    $('input[name=common_part]').val('')
    $('input[name=family_part]').val('')
  }

  async handleInputFormIssueMR() {
    defaulInputDieNoProperty()
    let partNo = $('input[name=part_no]').val().trim().toUpperCase()
    let dim = $('input[name=dim]').val().trim().toUpperCase()
    let his = $('input[name=his]').val().trim().toUpperCase()
    let last2leterOfDim = dim.substring(1, 3)
    let dieNo = $('input[name=die_no]').val().trim().toUpperCase()
    let mr_type_id = 0;
    let reason = ""
    // new
    if (dim == '11A') {
      dieNo = partNo + '-' + dim + '-001';
      mr_type_id = 1
      reason = "New Die"
    }
    // addi
    if (dim[0] != '1' && last2leterOfDim == '1A') {
      dieNo = partNo + '-' + dim + '-001';
      mr_type_id = 2
      reason = "Additional Die"
    }
    //renew ECN
    if (last2leterOfDim == '2A') {
      dieNo = partNo + '-' + dim + '-001';
      mr_type_id = 3
      reason = "Renewal base on ECN"
    }
    //renew factory
    if (last2leterOfDim == '3A') {
      dieNo = partNo + '-' + dim + '-001';
      mr_type_id = 4
      reason = "Renewal base on ECN"
    }
    //renew die life
    if (dim[1] == '4') {
      dieNo = partNo + '-' + dim + '-001';
      mr_type_id = 5
      reason = "Renewal base on die life"
    }
    //ECN
    if (dim[1] == '5') {
      changeInputDieNoProperty()
      mr_type_id = 6
    }
    //Modify
    if (dim[1] == '6') {
      changeInputDieNoProperty()
      mr_type_id = 7
    }
    //Repair
    if (dim[1] == '7') {
      changeInputDieNoProperty()
      mr_type_id = 8
    }

    //Renew for Overseas die
    if (dim[1] == '8') {
      mr_type_id = 9
      dieNo = partNo + '-' + dim + '-001';
      reason = "Renew for Overse die (make Domastic)"
    }

    //modify Overseas
    if (dim[1] == '9') {
      changeInputDieNoProperty()
      mr_type_id = 10
    }


    function changeInputDieNoProperty() {
      $('input[name=die_no]').prop('placeholder', 'Which die modify/ Repair?')
      $('input[name=die_no]').prop('disabled', false)

      let a = $('input[name=die_no]').parent().children('label').text('Modify/Repair for Die ID')
    }
    function defaulInputDieNoProperty() {
      $('input[name=die_no]').prop('placeholder', '')
      $('input[name=die_no]').prop('disabled', true)
      let a = $('input[name=die_no]').parent().children('label').text('Die ID')
    }



    // Link ECN & Die
    if (partNo.length === 12 && dieNo.length === 20) {
      this.DOMService.onloading('.loading')
      // Link to ECN
      {
        let linkToECN: any = await this.APIservices.linkToECN(partNo).toPromise()
        let oBjProcesCode: any = {
          MO: 1,
          PX: 2,
          AL: 3,
          AS: 4,
          PG: 5,
          FC: 6
        }

        $('input[name=part_name]').val(linkToECN[0]?.part_name)
        $('select[name=process_code_id]').val(oBjProcesCode[linkToECN[0]?.process])
        $('input[name=ecn_no]').val(linkToECN[0]?.ecn_no)
        $('input[name=his]').val(linkToECN[0]?.history)
      }
      // Link to DIE
      {
        let dieInfoRaw = await this.APIservices.getDieInforForIssueMR({ dieNo: dieNo }).toPromise()
        let dieInfo = dieInfoRaw?.data.data[0]
        $('input[name=common_part]').val(dieInfo?.common_part_with)
        $('input[name=family_part]').val(dieInfo?.family_die_with)
        $('select[name=model_id]').val(dieInfo?.model_id)
        $('select[name=supplier_id]').val(dieInfo?.supplier_id)
        $('input[name=mc_size]').val(dieInfo?.mc_size)
        $('input[name=cav_qty]').val(dieInfo?.cav_quantity)
      }
      this.DOMService.onloaded('.loading')
    }



    $('input[name=die_no]').val(dieNo)
    $('input[name=mr_type_id]').val(mr_type_id)
    $('input[name=reason]').val(reason)

  }

  async renderTPIAnDFMreasonForMR() {

    let dieNo = $('input[name=die_no]').val()
    let mr_type_id = $('input[name=mr_type_id]').val()
    let renderContent = "";
    if ([6, 7, 8, 10].includes(parseInt(mr_type_id)) && dieNo.length === 20) { // cần TPI or DFM
      $('input[name=reason]').val('')
      let listTPI = await this.APIservices.getTPIRelatedDieNo({ dieNo: dieNo }).toPromise()
      let dsum = await this.APIservices.getDFMRelatedDieNo({ dieNo: dieNo }).toPromise()

      $('#areaRenderTPI').empty()

      if (listTPI?.data.length != 0 || dsum?.data.length != 0) {
        if (listTPI?.data.length != 0) {
          listTPI?.data.forEach((tpi: any) => {
            var renderAreasi = `
              <tr> +
                <td class ='text-nowrap'> <input type='checkbox' name='selectTPI' id="${tpi.tpi_id}" data-tpi-id='${tpi.tpi_id}' value =' ${tpi.tpi_no}' /> </td>
                <td class ='text-nowrap'> ${tpi.tpi_no} </td>
                <td class ='text-nowrap'> ${tpi.trouble_name} </td>
                <td class ='text-nowrap'> ${tpi.po_code}  </td>
                <td class ='text-nowrap'>${tpi.status} </td>
                <td class ='text-nowrap'> <span class='download-attach cursor text-primary' data-att-path="${tpi.report}"> Report </span> </td>
                <td class ='text-nowrap'> ${moment(tpi.submit_date).format("YYYY/MM/DD")} </td>
              </tr>`
            renderContent = renderContent + renderAreasi;
          })
        }
        // render DSUM
        if (dsum?.data.length != 0) {
          dsum?.data.forEach((dfm: any) => {
            var renderAreasi = `<tr><td colspan='7'>DSUM</td></td> 
              <tr> 
                <td class ='text-nowrap'>  <input type='checkbox' name='selectDFM' data-dfm-id='${dfm.dfm_id}' value =' ${dfm.dsum_no}' /> </td>
                <td class ='text-nowrap'> ${dfm.dsum_no} </td>
                <td class ='text-nowrap'> DFM docement </td>
                <td class ='text-nowrap'>  </td>
                <td class ='text-nowrap'>${dfm.status} </td>
                <td class ='text-nowrap'> <a href="${this.APIHost}/DSUM/${dfm.dfm_id} " > Detail </a> </td>
                <td class ='text-nowrap'> ${moment(dfm.submit_date).format("YYYY/MM/DD")} </td>
              </tr>`
            renderContent = renderContent + renderAreasi;
          })
        }



      } else {
        renderContent = `<tr><td colspan='7'>Do not have any trouble report for this die, Please check again!</td></tr>`
      }


      $('#areaRenderTPI').append(renderContent)
      const modalMassage = new bootstrap.Modal('#modal_select_TPI', {
        keyboard: true
      })
      modalMassage.show()
    }
  }


  selectTPIAndDSUM() {
    let selectedTPI = this.DOMService.getSelectedID('selectTPI')
    let selectedDFM = this.DOMService.getSelectedID('selectDFM')
    var tpiID: any = [];
    $(`input[name=selectTPI]:checkbox:checked`).each(function (this: HTMLElement) {
      tpiID.push($(this).attr('data-tpi-id'));
    });

    var dfmID: any = [];
    $(`input[name=selectDFM]:checkbox:checked`).each(function (this: HTMLElement) {
      dfmID.push($(this).attr('data-dfm-id'));
    });
    $('input[name=reason]').val(selectedTPI.concat(selectedDFM))
    $('input[name=tpi_id]').val(tpiID)
    $('input[name=dfm_id]').val(dfmID)

    const modal = bootstrap.Modal.getInstance($('#modal_select_TPI')).hide()

  }





  issueMR() {

    let _that = this

    Validator({
      form: '#form_issue_MR',
      formGroupSelector: '.nice-form-group',
      rules: [
        Validator.isRequired('input[name=belong]'),
        Validator.isRequired('input[name=part_no]'),
        Validator.isLength('input[name=part_no]', 12),
        Validator.isRequired('input[name=dim]'),
        Validator.isLength('input[name=dim]', 3),
        Validator.isRequired('input[name=die_no]'),
        Validator.isLength('input[name=die_no]', 20),
        Validator.isRequired('input[name=part_name]'),
        Validator.isRequired('select[name=process_code_id]'),
        Validator.isRequired('input[name=ecn_no]'),
        Validator.isLength('input[name=ecn_no]', 13),
        Validator.isRequired('input[name=his]'),
        Validator.isLength('input[name=his]', 3),
        Validator.isRequired('select[name=model_id]'),
        Validator.isRequired('select[name=supplier_id]'),
        Validator.isRequired('select[name=order_to]'),
        Validator.isRequired('input[name=pdd]'),
        Validator.isRequired('input[name=estmate_cost]'),
        Validator.isNumber('input[name=estmate_cost]'),
        Validator.isRequired('select[name=unit]'),
        Validator.isRequired('input[name=mc_size]'),
        Validator.isNumber('input[name=mc_size]'),
        Validator.min('input[name=mc_size]', 20),
        Validator.isRequired('input[name=cav_qty]'),
        Validator.isNumber('input[name=cav_qty]'),
        Validator.min('input[name=cav_qty]', 1),
        Validator.isRequired('input[name=reason]'),

      ],
      onSubmit: async function (data: any) {
        _that.DOMService.onloading(".btn_submit_MR")

        data.pur_att_file = data.pur_att_file[0]
        //Start check MR exists or not?

        if (data.part_no.trim().length == 12 && data.dim.trim().length == 3 && data.his.trim().length == 3) {
          let checkExistMR = await _that.APIservices.isExistMR({ part_no: data.part_no, dim: data.dim, his: data.his }).toPromise()
          if (checkExistMR?.status) {
            $('#issue_MR_Warning').text('Systen Warning: ' + checkExistMR.msg)
            _that.DOMService.onloaded(".btn_submit_MR")
            return
          }
        } else {
          $('#issue_MR_Warning').text('')
        }
        // Finished check MR exists or not?

        // Start check Die exist/dispose or not when issue MR for modify
        if ([6, 7, 8, 10].includes(parseInt(data.mr_type_id)) && data.die_no.length === 20) { // cần TPI or DFM
          let checkDieExistORDisposeORCancel = await _that.APIservices.checkDieExist({ dieNo: data.die_no }).toPromise()
          if (checkDieExistORDisposeORCancel?.status == false) {
            $('#issue_MR_Warning').text('Systen Warning: ' + checkDieExistORDisposeORCancel.msg)
            _that.DOMService.onloaded(".btn_submit_MR")
            return
          }
        } else {
          $('#issue_MR_Warning').text('')
        }
        // End check Die exist/dispose or not when issue MR for modify F

        // Start check Tiền USD nhưng lớn hơn 1 triệu
        if (data.unit.includes("USD") && data.estmate_cost >= 1000000) {
          $('#issue_MR_Warning').text('Systen Warning: ' + "May be you select wrong unit" + `[${data.estmate_cost + data.unit}]`)
          _that.DOMService.onloaded(".btn_submit_MR")
          return
        }

        let result = await _that.APIservices.issueMR(data).toPromise()
        if (result?.status) {
          $('#issue_MR_Warning').text('Result: ' + result.msg)
          _that.renderChartMR()
        } else {
          _that.DOMService.showAlertMassage(result?.msg, false)
        }
        _that.DOMService.onloaded(".btn_submit_MR")
      }
    });

  }

  async issueMRByExcel() {
    this.DOMService.onloading(".btn_issueMR_excel")
    let file = $('input[name=file_issue_MR_Excel]')[0].files[0]
    let formData = new FormData()
    formData.append('file', file)
    let dataResult = await this.APIservices.issueMRByExcel(formData).toPromise();

    let detailFaileItem = ""
    dataResult?.listFail.forEach((e: any) => detailFaileItem += "</br>" + e)
    let contentResult = `
        Message: ${dataResult?.msg} </br>
        Success: ${dataResult?.success} </br>
        Fail: ${dataResult?.fail} </br>
        Detail fail: ${detailFaileItem}
      `

    $('#issue_MR_Warning').empty().append(contentResult)
    this.renderChartMR()
    this.DOMService.onloaded(".btn_issueMR_excel")
  }

  async checkMR(mr_id: number | undefined, isPAETurn: boolean | undefined) {
    let _that = this
    if (mr_id) { //check one by one
      let users = this.authen.isLogined().user
      if (isPAETurn) {
        Validator({
          form: '#form_PAE_Check_MR',
          formGroupSelector: '.nice-form-group',
          rules: [
            Validator.isRequired('select[name=check_is_de_die]'),
            Validator.isRequired('input[name=check_no_of_die_component]'),
            Validator.isNumber('input[name=check_no_of_die_component]'),
            Validator.isRequired('input[name=check_die_maker]'),
            Validator.isRequired('input[name=check_make_location]'),
          ],
          onSubmit: async function (data: any) {

            data.mRIDs = mr_id
            _that.DOMService.onloading(".btn_check_MR")

            // PAE duoc phep sua vai thong tin khac cua dept issue
            let pdd = $('#form_mr_information input[name=pdd]').val()
            let model_id = $('#form_mr_information select[name=model_id]').val()
            let cav_qty = $('#form_mr_information input[name=cav_qty]').val()
            let mc_size = $('#form_mr_information input[name=mc_size]').val()
            let supplier_id = $('#form_mr_information select[name=supplier_id]').val()
            let common_part = $('#form_mr_information input[name=common_part]').val()
            let family_part = $('#form_mr_information input[name=family_part]').val()
            if (!(pdd && model_id && cav_qty && mc_size && supplier_id)) {
              _that.DOMService.showAlertMassage('Yellow cell "PDD, Model,Cav,MC Size, Supplier" can not empty!', false)
              _that.DOMService.onloaded(".btn_check_MR")
              return
            }

            data.pdd = pdd
            data.model_id = model_id
            data.cav_qty = cav_qty
            data.mc_size = mc_size
            data.supplier_id = supplier_id
            data.common_part = common_part
            data.family_part = family_part

            let result = await _that.APIservices.checkAndApproveAndRejectMR(data).toPromise()

            if (result?.success.length !== 0) {
              result?.success.forEach((mr_id: any) => {
                $(`#${mr_id}`).css('display', 'none')
              })
              const modal = bootstrap.Modal.getInstance($('#showModalMRDetail')).hide()
              _that.renderChartMR()
            }

            if (result?.fail.length !== 0) {
              _that.DOMService.showAlertMassage(result?.fail[0], false)
            }

            _that.DOMService.onloaded(".btn_check_MR")
          }
        })
      } else {
        _that.DOMService.onloading(".btn_check_MR")
        let data = {
          mRIDs: mr_id,
          check_comment: $('textarea[name=check_comment]').val(),
          budget_code: $('select[name=budget_code]').val()
        }
        let result = await _that.APIservices.checkAndApproveAndRejectMR(data).toPromise()
        if (result?.success.length !== 0) {
          result?.success.forEach((mr_id: any) => {
            $(`#${mr_id}`).css('display', 'none')
          })
          const modal = bootstrap.Modal.getInstance($('#showModalMRDetail')).hide()
          _that.renderChartMR()
        }
        if (result?.fail.length !== 0) {
          _that.DOMService.showAlertMassage(result?.fail[0], false)
        }
        _that.DOMService.onloaded(".btn_check_MR")
      }

    } else { // mutipli check
      // function này show modal confirm trước khi approve
      let mrSelected: any = this.getSelectedIDs()
      if (!mrSelected.length) {
        this.DOMService.showAlertMassage("You need select MR which you one to take action", false)
        return
      }
      if (this.authen.isLogined().user[0].dept_name.includes("PAE")) {
        this.DOMService.showAlertMassage("PAE need check MR one by one", false)
        return
      }
      $('#label_confirming').text('You are checking for ' + mrSelected.length + ' MR(s)')
      const modalMassage = new bootstrap.Modal('#modal_approve_confirm', {
        keyboard: true
      })
      modalMassage.show()
    }
  }

  async approveMR(mr_id: number | undefined, isPAETurn: boolean | undefined) {
    let _that = this
    if (mr_id) { // one by one approve
      let users = this.authen.isLogined().user

      if (isPAETurn) {
        Validator({
          form: '#form_PAE_Check_MR',
          formGroupSelector: '.nice-form-group',
          rules: [
            Validator.isRequired('select[name=check_is_de_die]'),
            Validator.isRequired('input[name=check_no_of_die_component]'),
            Validator.isNumber('input[name=check_no_of_die_component]'),
            Validator.isRequired('input[name=check_die_maker]'),
            Validator.isRequired('input[name=check_make_location]'),
          ],
          onSubmit: async function (data: any) {
            data.mRIDs = mr_id
            _that.DOMService.onloading(".btn_check_MR")
            let result = await _that.APIservices.checkAndApproveAndRejectMR(data).toPromise()

            if (result?.success.length !== 0) {
              // hide MR seccess
              result?.success.forEach((mr_id: any) => {
                $(`#${mr_id}`).css('display', 'none')
              })
              //hide modal
              const modal = bootstrap.Modal.getInstance($('#showModalMRDetail')).hide()
              //render lai chart
              _that.renderChartMR()
            }
            if (result?.fail.length !== 0) {
              _that.DOMService.showAlertMassage(result?.fail[0], false)
            }
            _that.DOMService.onloaded(".btn_check_MR")
          }
        })
      } else {
        _that.DOMService.onloading(".btn_Approve_MR")
        let data = {
          mRIDs: mr_id,
          check_comment: $('textarea[name=check_comment]').val()
        }
        let result = await _that.APIservices.checkAndApproveAndRejectMR(data).toPromise()
        if (result?.success.length !== 0) {
          //hide MR success
          result?.success.forEach((mr_id: any) => {
            $(`#${mr_id}`).css('display', 'none')
          })
          // hide model
          const modal = bootstrap.Modal.getInstance($('#showModalMRDetail')).hide()
          // render chart
          _that.renderChartMR()
        }
        if (result?.fail.length !== 0) {
          _that.DOMService.showAlertMassage(result?.fail[0], false)
        }
        _that.DOMService.onloaded(".btn_Approve_MR")
      }
    } else { // muitipli Approve
      // function này show modal confirm trước khi approve
      let mrSelected: any = this.getSelectedIDs()
      $('#label_confirming').text('You are approving for ' + mrSelected.length + ' MR(s)')
      const modalMassage = new bootstrap.Modal('#modal_approve_confirm', {
        keyboard: true
      })
      modalMassage.show()
    }

  }


  async confirmApproveMR() {
    let _that = this
    this.DOMService.onloading('.btn_confirm_approve')
    let mrSelected: any = this.getSelectedIDs()
    let comment = $('#approver_comment').val()
    if (mrSelected.length == 0) {
      this.DOMService.showAlertMassage('Please select MR which you want to approve!', false)
      this.DOMService.onloaded('.btn_confirm_approve')
      return
    }

    let approveResult = await this.APIservices.checkAndApproveAndRejectMR({ mRIDs: mrSelected, check_comment: comment }).toPromise()
    if (approveResult?.success.length != 0) {
      // load lai chart 
      _that.renderChartMR()
      // hide MR success
      approveResult?.success.forEach((mr_id: any) => {
        $(`#${mr_id}`).css('display', 'none')
      })
    }

    if (approveResult?.fail.length != 0) {
      // show massage
      let msg = ''
      approveResult?.fail.forEach((e: any, index: any) => {
        msg += (index + 1) + ". " + e + "</br>"
      })
      _that.DOMService.showAlertMassage(msg, false)
    }

    this.DOMService.onloaded('.btn_confirm_approve')
    const modal = bootstrap.Modal.getInstance($('#modal_approve_confirm')).hide()
  }


  async rejectMR(mr_id: number | undefined) {
    let _that = this
    if (mr_id) { // one by on reject
      let comment = $('textarea[name=check_comment]').val()
      if (!comment) {
        _that.DOMService.showAlertMassage('Please commemt reason reject this MR!', false)
        return
      }
      let rejectResult = await this.APIservices.checkAndApproveAndRejectMR({ mRIDs: mr_id, check_comment: comment, isReject: true }).toPromise()
      if (rejectResult?.success.length !== 0) {
        rejectResult?.success.forEach((mr_id: any) => {
          $(`#${mr_id}`).css('display', 'none')
        })
        const modal = bootstrap.Modal.getInstance($('#showModalMRDetail')).hide()
        _that.renderChartMR()
      }

      if (rejectResult?.fail.length !== 0) {
        _that.DOMService.showAlertMassage(rejectResult?.fail[0], false)
      }
    } else { // mutipli reject
      // function này show modal confirm trước khi approve
      let mrSelected: any = this.getSelectedIDs()
      $('#label_reject_confirming').text('You are rejecting for ' + mrSelected.length + ' MR(s)')
      const modalMassage = new bootstrap.Modal('#modal_reject_confirm', {
        keyboard: true
      })
      modalMassage.show()
    }
  }

  async confirmRejectMR() {
    let _that = this
    this.DOMService.onloading('.btn_confirm_reject')
    let mrSelected: any[] = this.getSelectedIDs()
    let comment = $('#reject_comment').val()
    if (mrSelected.length == 0) {
      this.DOMService.showAlertMassage('Please select MR which you want to approve!', false)
      this.DOMService.onloaded('.btn_confirm_reject')
      return
    }

    let rejectResult = await this.APIservices.checkAndApproveAndRejectMR({ mRIDs: mrSelected, check_comment: comment, isReject: true }).toPromise()
    if (rejectResult?.success.length != 0) {
      // load lai chart 
      _that.renderChartMR()
      // hide MR success
      rejectResult?.success.forEach((mr_id: any) => {
        $(`#${mr_id}`).css('display', 'none')
      })
    }

    if (rejectResult?.fail.length != 0) {
      // show massage
      let msg = ''
      rejectResult?.fail.forEach((e: any, index: any) => {
        msg += (index + 1) + ". " + e + "</br>"
      })
      _that.DOMService.showAlertMassage(msg, false)
    }




    this.DOMService.onloaded('.btn_confirm_reject')
    const modal = bootstrap.Modal.getInstance($('#modal_reject_confirm')).hide()
  }

  chartOptions = {
    series: [],
    annotations: {
      points: [{
        x: 'Oranges',
        seriesIndex: 0,
        label: {
          borderColor: '#775DD0',
          offsetY: 0,
          style: {
            color: '#fff',
            background: '#775DD0',
          },
          text: 'Bananas are good',
        }
      }]
    },
    chart: {
      height: 200,
      type: 'bar',
      events: {
        dataPointSelection: async (event: any, chartContext: any, opts: any) => {
          let index = opts.dataPointIndex
          let data = await opts.w.config.xaxis.categories[index]
          let qty = opts.w.config.series[0].data[index]
          this.searchParameter = {
            search: data,
            page: 1
          }
          this.renderTable(this.searchParameter)
        }
      },
    },
    plotOptions: {
      bar: {
        columnWidth: '60%',
      }
    },
    dataLabels: {
      enabled: true,
      textAnchor: 'middle',
      offsetY: 0,
      style: {
        fontFamily: 'Helvetica, Arial, sans-serif',
        fontWeight: 'bold',
        colors: ['#000']
      }
    },
    stroke: {
      width: 0
    },
    grid: {
      row: {
        colors: ['#fff', '#f2f2f2']
      }
    },
    xaxis: {
      labels: {
        rotate: -25
      },
      categories: []
    },
    yaxis: {
      title: {
        text: 'MR',
      },
    },
    fill: {
      type: 'gradient',
      gradient: {
        shade: 'light',
        type: "horizontal",
        shadeIntensity: 0.25,
        gradientToColors: undefined,
        inverseColors: true,
        opacityFrom: 0.85,
        opacityTo: 0.85,
        stops: [50, 0, 100]
      },
    },

  };


  async renderChartMR() {
    let mrPending = await this.APIservices.getSumarizeMRPending().toPromise()

    let data: any = [];
    let category: any = []
    mrPending?.data.forEach((e: any) => {
      data.push(e.qty)
      category.push(e.status)
    });

    let series: any = [{
      name: 'MR',
      data: data
    }]
    //let category:any = ['W-PAE', 'W-PE1', 'W-PUR', 'W-ddd']
    var options = this.chartOptions
    options.series = series
    options.xaxis.categories = category

    $('#render_chart_box').empty()
    var chart = new ApexCharts(document.querySelector("#render_chart_box"), options);
    chart.render();
  }

  async downloadAttach(pathFull: string) {
    let a = await this.APIservices.downloadAttachment(pathFull)
  }


  async downloadMRformByID(mr_id: number) {
    let dowloadResult = await this.APIservices.downloadMRFormById(mr_id).toPromise();
    if (dowloadResult?.status) {
      window.location.href = this.APIHost + '/Download/FileDownload?fileGuid=' + dowloadResult.linkdowload.fileGuid + '&fileName=' + dowloadResult.linkdowload.fileName + '&contentType=' + dowloadResult.linkdowload.contentType;
    } else {
      this.DOMService.showAlertMassage(dowloadResult?.msg, false)
    }
  }

  async dowloadListMR(){
    let dowloadResult = await this.APIservices.downloadMRList(this.searchParameter).toPromise();
    if (dowloadResult?.data) {
      window.location.href = this.APIHost + '/Download/FileDownload?fileGuid=' + dowloadResult.data.fileGuid + '&fileName=' + dowloadResult.data.fileName + '&contentType=' + dowloadResult.data.contentType;
    } else {
      this.DOMService.showAlertMassage("System Erorr!", false)
    }
  }

  showMRDetail(mr_id: number) {
    this.DOMService.renderModalMRDetail(mr_id)
  }

  selectAll(isSelectAll: boolean) {
    this.DOMService.selectAll('row_mr_id', isSelectAll)
  }

  getSelectedIDs() {

    return this.DOMService.getSelectedID('row_mr_id')
  }

}
