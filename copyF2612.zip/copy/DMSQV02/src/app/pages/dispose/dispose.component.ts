import { Component } from '@angular/core';

@Component({
  selector: 'app-dispose',
  templateUrl: './dispose.component.html',
  styleUrl: './dispose.component.css'
})
export class DisposeComponent {

}
