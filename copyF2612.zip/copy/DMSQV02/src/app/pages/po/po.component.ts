import { Component, AfterViewInit, OnDestroy, Renderer2, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Config } from 'datatables.net';
import { AuthenService } from '../../API-Services/authen.service';
import { Router } from '@angular/router';
import { DOMServiceService } from '../../common-services/dom-service.service';
import { AppAPIService } from '../../API-Services/app-api.service';
import { Subject } from 'rxjs';

import moment from 'moment';
import { Action } from 'rxjs/internal/scheduler/Action';
const apexChart = import('apexcharts');
declare var $: any;
declare var bootstrap: any;
declare var Validator: any;
declare var DataTable: any;
@Component({
  selector: 'app-po',
  templateUrl: './po.component.html',
  styleUrl: './po.component.css'
})
export class PoComponent {
  private eventListener!: () => void;

  constructor(
    private authen: AuthenService,
    private router: Router,
    private DOMService: DOMServiceService,
    private APIservices: AppAPIService,
    private renderer: Renderer2,


  ) { }


  APIHost = 'http://localhost:5019'
  //depts: string = JSON.parse(localStorage.getItem('user') ?? '[]').map((x: any) => x.dept_name)
  depts = 'PUR'
  po_role_id: number = 3;
  admin = false;
  searchParameter: any = {
    page: 1,
    search: '',
  }

  // Done 
  dtOptions: any = {
    serverSide: false,
    paging: false,
    ordering: false,
    select: true, keys: true,
    scrollY: '300',
    scrollX: true,
    fixedColumns: {
      left: 3,
      right: 0
    },
    rowId: 'po_id',
    searching: false,
    createdRow: (row: any, data: any, index: any) => {

      if (data.temp_po == true) {
        $(row).classList.add('bg-warning');
      }

    },
    columns: [
      {
        title: `<label for='selectAll'>Select All </label><input class="selectAll" id='selectAll' type='checkbox'/>`,
        data: 'po_id',
        render: function (data: any, type: any, row: any) {
          return `<input type='checkbox' value='${data}' name='row_po_id'/> `
        }
      },
      {
        title: 'Status',
        data: 'status',
        render: function (data: any, type: any, row: any) {
          return `<button style="min-width:150px" class="btn btn-sm btn-primary btn_show_modal_PO_detail" data-po-id='${row.po_id}'>${data}</button>`
        }
      },
      {
        title: 'MR No',
        data: 'mr_no',
        render: function (data: any, type: any, row: any) {
          return `<a title='click to download MR form' class='cursor text-primary download-mr'  data-mr-id = '${row.mr_id}'>${data}</a>`
        }
      },
      {
        title: 'PO Issue No',
        data: 'po_issue_no',
      },
      {
        title: 'DieID',
        data: 'die_no'
      },
      {
        title: 'Part No',
        data: 'part_no',
      },
      {
        title: 'Dim',
        data: 'clasification'
      },
      {
        title: 'Type PO',
        data: 'mr_type'
      },
      {
        title: 'Part No',
        data: 'part_name',
      },
      {
        title: 'Temp(Y/N)',
        data: 'part_name',
      },
      {
        title: 'Reason Temp PO',
        data: 'reason_issue_po',
      },
      {
        title: 'Vendor Code',
        data: 'supplier_code'
      },
      {
        title: 'Vendor Name',
        data: 'supplier_name'
      },
      {
        title: 'Order To',
        data: 'order_to'
      },

      {
        title: 'Model',
        data: 'model_name'
      },
      {
        title: 'Process Code',
        data: 'process_code'
      },

      {
        title: 'ECN No',
        data: 'ecn_no'
      },
      {
        title: 'His',
        data: 'draw_his'
      },
      {
        title: 'Delivery Date',
        data: 'delivery_date',
        render: function (data: any, type: any, row: any) {
          return moment(data).format('YYYY/MM/DD')
        }
      },
      {
        title: 'Request',
        data: 'issue_by'
      },
      {
        title: 'Date',
        data: 'issue_date',
        render: function (data: any, type: any, row: any) {
          return moment(data).format('YYYY/MM/DD hh:mm A')
        }
      },
    ]
  };
  dtTrigger: Subject<any> = new Subject();
  ngOnInit(): void {
    this.authen.checkLoginAndHandle()
    // this.po_role_id = this.authen.getRoleForFucntion('po_role_id')
    this.renderChartPO()
    let _that = this
    // start render
    //render search areas
    this.createMRtypeOptionElement()
    this.createSupplierListOptionElement()
    //this.createModelOptionElement()
    //this.createProcesCodeOptionElement()
    //this.createOrderToListOptionElement()
    //rendertable
    // user nào thì lấy pending item của user đó

    let users = this.authen.isLogined().user

    users.forEach((u: any) => {

      if (u.po_role_id >= 3 && u.factory == "QV") {
        this.searchParameter.dept = u.dept_name;
        this.searchParameter.po_role_id = u.po_role_id;
        return
      }
    })

    this.renderTable(this.searchParameter)





    // Handle sự kiện click ngoài angular
    this.eventListener = this.renderer.listen(document, "click", function (e) {
      //trường hợp user click vào page
      // => add page vào object searchParameter => render lại table
      let page = $(e.target).attr('data-page')
      if (page) {
        console.log(_that.searchParameter)
        let isnewpage = _that.searchParameter.page != page
        if (isnewpage) {
          _that.searchParameter.page = page
          _that.renderTable(_that.searchParameter)
        }
      }

      //trường hợp user click vào Downloard MR form
      let isClickDownloadMR = $(e.target).hasClass('download-mr')
      if (isClickDownloadMR) {
        let mr_id = $(e.target).attr('data-mr-id')
        _that.downloadMRformByID(mr_id)
      }

      //trường hợp user click vào Show MR detail
      let isClickShowPO = $(e.target).hasClass('btn_show_modal_PO_detail')
      if (isClickShowPO) {
        let po_id = $(e.target).attr('data-po-id')
        _that.showPODetail(po_id)
      }

      //trường hợp user click vào btn_check_MR
      let isClickApprovekMR = $(e.target).hasClass('btn_Approve_MR')
      if (isClickApprovekMR) {
        let mr_id = $(e.target).attr('data-mr-id')
        let isPAETurn = $(e.target).attr('data-is-pae-turn')
        isPAETurn = isPAETurn === "true" ? true : false
        _that.approveMR(mr_id, isPAETurn)
      }

      //trường hợp user click vào btn_check_MR
      let isClickCheckMR = $(e.target).hasClass('btn_check_MR')
      if (isClickCheckMR) {
        let mr_id = $(e.target).attr('data-mr-id')
        let isPAETurn = $(e.target).attr('data-is-pae-turn')
        isPAETurn = isPAETurn === "true" ? true : false
        _that.checkMR(mr_id, isPAETurn)
      }

      //trường hợp user click vào btn_check_MR
      let isClickRejectMR = $(e.target).hasClass('btn_reject_MR')
      if (isClickRejectMR) {
        let mr_id = $(e.target).attr('data-mr-id')
        _that.rejectMR(mr_id)
      }

      //trường hợp user click vào selectAll
      let isClickSelectAll = $(e.target).hasClass('selectAll')
      if (isClickSelectAll) {

        let isSelectAll = $(e.target).prop('checked')
        _that.selectAll(isSelectAll)
      }

      // click btn_submit_change_po
      let isSubmitChangePO = $(e.target).hasClass('btn_submit_change_po')
      if (isSubmitChangePO) {
        let po_id = $(e.target).attr('data-po_id')
        _that.submitChangePO(po_id)
      }

      // click btn_submit_cancel_po
      let isCancelChangePO = $(e.target).hasClass('btn_submit_cancel_po')
      if (isCancelChangePO) {
        let po_id = $(e.target).attr('data-po_id')
        let isReissue = $(e.target).attr('data-reissue')
        _that.submitCancelPO(po_id, isReissue)
      }


    })






  }


  // Done
  ngOnDestroy() {
    if (this.eventListener) {
      this.eventListener();
    }
  }

  // Done
  async renderTable(searchParameter: any) {
    this.DOMService.onloading('.btn_search')
    let _that = this
    this.dtOptions.destroy = true,
      this.dtOptions.processing = true;
    let dataResult = await this.APIservices.getPOList(searchParameter).toPromise()
    if (dataResult?.status == false) {
      this.DOMService.showAlertMassage(dataResult.msg, false)
      return
    }
    this.dtOptions.data = dataResult?.data
    this.DOMService.pagination(dataResult?.page, dataResult?.pageSize, dataResult?.recordsTotal, '.render_paganation')
    this.dtTrigger.next(null)
    _that.DOMService.onloaded('.btn_search')
  }
  // Done
  async createMRtypeOptionElement() {
    let mrTypeCategory = await this.APIservices.getMRTypeCategory().toPromise()
    let result = this.DOMService.createOptionElement(mrTypeCategory?.data, ["type"], "mr_type_id", "")
    this.DOMService.appendToElement("select[name=mr_type_id]", result)
  }

  // // No need
  // async createProcesCodeOptionElement() {
  //   let mrTypeCategory = await this.APIservices.getProcessCodeCategory().toPromise()
  //   let result = this.DOMService.createOptionElement(mrTypeCategory?.data, ["type"], "proces_id", "")
  //   this.DOMService.appendToElement("select[name=process_code_id]", result)
  // }
  // // No need
  // async createModelOptionElement() {
  //   let modelList = await this.APIservices.getModelList().toPromise()
  //   let result = this.DOMService.createOptionElement(modelList?.data, ["model_name"], "model_id", "")
  //   this.DOMService.appendToElement("select[name=model_id]", result)
  // }

  async createSupplierListOptionElement() {
    let suppliers = await this.APIservices.getSupplierList().toPromise()
    let result = this.DOMService.createOptionElement(suppliers?.data, ["supplier_code", 'supplier_name'], "supplier_id", "")
    this.DOMService.appendToElement("select[name=supplier_id]", result)
  }

  // // No need
  // async createOrderToListOptionElement() {
  //   let suppliers = await this.APIservices.getSupplierList().toPromise()
  //   let result = this.DOMService.createOptionElement(suppliers?.data, ["supplier_code", 'supplier_name'], "supplier_code", "")
  //   this.DOMService.appendToElement("select[name=order_to]", result)
  // }

  //Done
  showAll() {
    this.searchParameter = {
      page: 1,
      search: '',
    }
    this.renderTable(this.searchParameter)
  }


  //Done
  searchPO() {
    let _that = this
    Validator({
      form: '#form_Search',
      formGroupSelector: '.nice-form-group',
      rules: [

      ],
      onSubmit: async function (data: any) {
        _that.searchParameter = { ..._that.searchParameter, ...data }
        _that.renderTable(data)

      }
    })
  }

  // Done
  async showModelIsuePO() {
    let listSelectedIDs = this.getSelectedIDs()
    if (listSelectedIDs.length == 0) {
      this.DOMService.showAlertMassage('Please select items need issue PO!', false)
      return
    }

    let checkListCanAction = await this.APIservices.checkItemsCanIssuePO_new_change_cancel({ listPO_ID: listSelectedIDs, action: 'new' }).toPromise()
    if (checkListCanAction?.data.length == 0) {
      this.DOMService.showAlertMassage('The Items you selected already issued!', false)
      return
    }
    let contentListPO = ''
    checkListCanAction?.data.forEach((po: any) => {
      contentListPO +=
        `<tr>
          <td><input disabled type="checkbox" name="po_id_can_issue_po" checked value="${po.po_id}"/></td>
          <td>${po.part_no}</td>
          <td>${po.clasification}</td>
          <td>${po.supplier_code}</td>
          <td>${po.order_to}</td>
          <td>${moment(po.delivery_date).format("YYYY/MM/DD")}</td>
      </tr>`
    });
    $('#issue_po_qty').empty().text(checkListCanAction?.data.length)
    $('#render_list_PO_Issue').empty().append(contentListPO)

    $('#form_issue_PO')[0].reset()
    $('#form_issue_PO').find('small').text('')
    const modalMassage = new bootstrap.Modal('#modal_issuePO', {
      keyboard: true
    })
    modalMassage.show()
  }

  // Done
  async showModelChangePO() {
    let listSelectedIDs = this.getSelectedIDs()
    if (listSelectedIDs.length == 0) {
      this.DOMService.showAlertMassage('Please select items need change PO!', false)
      return
    }

    let checkListCanAction = await this.APIservices.checkItemsCanIssuePO_new_change_cancel({ listPO_ID: listSelectedIDs, action: 'change' }).toPromise()
    if (checkListCanAction?.data.length == 0) {
      this.DOMService.showAlertMassage('The Items you selected can not request change PO!', false)
      return
    }
    let contentListPO = ''
    checkListCanAction?.data.forEach((po: any) => {
      contentListPO += `
         <form id="form_change_po_${po.po_id}">
                        <table class="table table-sm table-bordered border-secondary text-center mt-1"
                            style="font-size:0.75rem">
                            <thead>
                                <tr>
                                    <th colspan="2">PO INFORMATION</th>
                                    <th colspan="3">RESQUEST CHANGE</th>
                                   
                                </tr>
                                <tr>
                                    <td>Supplier</td>
                                    <td>${po.supplier_code}</td>
                                    <th width="20%">Change for</th>
                                    <th width="20%">Current</th>
                                    <th width="20%">Change to</th>
                                </tr>
                            </thead>
                            <tbody class="">
                                <tr>
                                    <td>Buyer</td>
                                    <td>${po.buyercode}</td>
                                    <td>Delivery date</td>
                                    <td>${moment(po.delivery_date).format('YYYY/MM/DD')}</td>
                                    <td class="nice-form"><input name="change_delivery_date" type="date" class="" style="background-color: #cfffff; width: 100%; line-height: 16px;"></td>
                                </tr>
                                <tr>
                                    <td>Part No</td>
                                    <td>${po.part_no}</td>
                                    <td>Order Qty</td>
                                    <td>${po.order_qty}</td>
                                    <td class="nice-form"><input disabled placeholder="Unavailable" type="text" name="change_order_qty" class="" style="background-color: #cfffff; width: 100%; line-height: 16px;"></td>
                                </tr>
                                <tr>
                                    <td>Dim</td>
                                    <td>${po.clasification}</td>
                                    <td>Block Code</td>
                                    <td>${po.use_block_code}</td>
                                    <td class="nice-form"><input disabled placeholder="Unavailable" type="text" name="change_use_block_code" class="" style="background-color: #cfffff; width: 100%; line-height: 16px;"></td>
                                </tr>
                               
                                <tr>
                                   <td>Evident</td>
                                   <td class="nice-form"><input type="file" name="evident" class="" style="background-color: #cfffff; width: 100%; line-height: 16px;"></td>
                                    <td>Delivery Location</td>
                                    <td>${po.delivery_location}</td>
                                    <td class="nice-form"><input disabled placeholder="Unavailable" type="text" name="change_delivery_location" class="" style="background-color: #cfffff; width: 100%; line-height: 16px;"></td>
                                </tr>
                                <tr>
                                    <td>Delivery Key No</td>
                                          
                                    <td class="nice-form"> 
                                        <input type="text" name="change_delivery_key_no" class="" style="background-color: #cfffff; width: 100%; line-height: 16px;">
                                    </td>
                                    <td>Drawing his</td>
                                    <td>003</td>
                                    <td class="nice-form"><input disabled placeholder="Unavailable" type="text" class="" style="background-color: #cfffff; width: 100%; line-height: 16px;"></td>
                                </tr>
                                <tr>
                                    <td>Reason</td>
                                    <td colspan="3" class="nice-form" >
                                      <input type="text" name="change_reason" class="" style="background-color: #cfffff; width: 100%; line-height: 24px;">
                                    </td>
                                    <td>
                                        <div class="d-grid gap-2">
                                            <button class="btn btn-primary btn-sm btn_submit_change_po" data-po_id=${po.po_id} type="button">Change PO</button>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </form>
      
      
      
      `
    });
    $('#change_po_qty').empty().text(checkListCanAction?.data.length)
    $('#render_list_PO_Change').empty().append(contentListPO)

    const modalMassage = new bootstrap.Modal('#modal_changePO', {
      keyboard: true
    })
    modalMassage.show()
  }

  // Done
  async showModelCancel(isReissue: boolean) {
    let listSelectedIDs = this.getSelectedIDs()
    if (listSelectedIDs.length == 0) {
      this.DOMService.showAlertMassage('Please select items need cancel PO!', false)
      return
    }

    let checkListCanAction = await this.APIservices.checkItemsCanIssuePO_new_change_cancel({ listPO_ID: listSelectedIDs, action: 'cancel' }).toPromise()
    if (checkListCanAction?.data.length == 0) {
      this.DOMService.showAlertMassage('The Items you selected can not request cancel PO!', false)
      return
    }
    let contentListPO = ''
    checkListCanAction?.data.forEach((po: any) => {
      contentListPO += `
       <form id="form_cancel_po_${po.po_id}">
                      <table class="table table-sm table-bordered border-secondary text-center mt-1"
                          style="font-size:0.75rem">
                          <thead>
                              <tr>
                                  <th colspan="4">RESQUEST CANCEL PO</th>
                              </tr>
                             
                          </thead>
                          <tbody class="">
                              <tr>
                                  <td>Supplier</td>
                                  <td>${po.supplier_code}</td>
                                  <td>Delivery date</td>
                                  <td>${moment(po.delivery_date).format('YYYY/MM/DD')}</td>
                              </tr>
                              <tr>
                                  <td>Buyer</td>
                                  <td>${po.buyercode}</td>
                                  <td>Order Qty</td>
                                  <td>${po.order_qty}</td>
                              </tr>
                              <tr>
                                  <td>Part No</td>
                                  <td>${po.part_no}</td>
                                  <td>Block Code</td>
                                  <td>${po.use_block_code}</td>
                              </tr>
                             
                              <tr>
                                  <td>Dim</td>
                                  <td>${po.clasification}</td>
                                  <td>Delivery Location</td>
                                  <td>${po.delivery_location}</td>
                              </tr>
                              <tr>
                                  <td>Delivery Key No</td>
                                  <td class="nice-form"> 
                                      <input type="text" name="cancel_delivery_key_no" class="" style="background-color: #cfffff; width: 100%; line-height: 16px;">
                                  </td>
                                  <td>Drawing his</td>
                                  <td>003</td>
                              </tr>
                              <tr>
                                  <td>Reason</td>
                                  <td colspan="3" class="nice-form" >
                                    <input type="text" name="cancel_reason" class="" style="background-color: #cfffff; width: 100%; line-height: 16px;">
                                  </td>
                                  
                              </tr>
                              <tr>
                                   <td>Evident</td>
                                   <td colspan="2" class="nice-form"><input type="file" name="evident" class="" style="background-color: #cfffff; width: 100%; line-height: 16px;"></td>
                                   <td>
                                      <div class="d-grid gap-2">
                                          <button class="btn btn-primary btn-sm btn_submit_cancel_po" data-reissue="${isReissue}" data-po_id=${po.po_id} type="button"> ${isReissue ? "Cancel & Re-Issue PO": "Cancel PO"}</button>
                                      </div>
                                  </td>
                              </tr>
                          </tbody>
                      </table>
                  </form>
    
    
    
    `
    });
    let warning = isReissue ? "Chú ý: chức năng này sẽ chỉ cancel PO, MR sẽ được giữ lại!" : "Chú ý: Chức năng này sẽ cancel cả PO và MR, Nếu muốn keep MR chọn chức năng cancel & re-issue!"
    $('.cancel_warning').empty().text(warning)
    $('#cancel_po_qty').empty().text(checkListCanAction?.data.length)
    $('#render_list_PO_cancel').empty().append(contentListPO)

    const modalMassage = new bootstrap.Modal('#modal_cancelPO', {
      keyboard: true
    })
    modalMassage.show()
  }

  // Done
  submitChangePO(po_id: number) {
    let _that = this

    Validator({
      form: `#form_change_po_${po_id}`,
      formGroupSelector: '.nice-form',
      rules: [
        Validator.isRequired('input[name=change_delivery_key_no]'),
        Validator.isRequired('input[name=change_reason]'),
      ],
      onSubmit: async function (data: any) {
        _that.DOMService.onloading(".btn_submit_change_po")
        data.po_id = po_id
        if (data.change_delivery_date || data.change_delivery_location || data.change_order_qty || data.change_use_block_code) {
          let changeResult = await _that.APIservices.changePORequest(data).toPromise()
          if (changeResult) {
            // remove item change khỏi bảng list po change request
            $(`#form_change_po_${po_id}`).remove();
            // Remove po này khỏi list po total
            $(`#${po_id}`).hide()
            // close table if done all
            let isDoneAll = $('#render_list_PO_Change').find('table').length == 0
            if (isDoneAll) {
              const modal = bootstrap.Modal.getInstance($('#modal_changePO')).hide()
            }
            _that.renderChartPO()

          } else {
            _that.DOMService.showAlertMassage("System Error! Plz Refresh page", false)
          }

        } else {
          _that.DOMService.showAlertMassage("You need to change at least 1 item", false)
        }
        _that.DOMService.onloaded(".btn_submit_change_po")
      }
    });
  }

  // Doing
  submitCancelPO(po_id: number, isReissue: boolean) {
    let _that = this

    Validator({
      form: `#form_cancel_po_${po_id}`,
      formGroupSelector: '.nice-form',
      rules: [
        Validator.isRequired('input[name=cancel_delivery_key_no]'),
        Validator.isRequired('input[name=cancel_reason]'),
      ],
      onSubmit: async function (data: any) {
        _that.DOMService.onloading(".btn_submit_cancel_po")
        data.po_id = po_id
        data.is_reIssue = isReissue
        let cancelResult = await _that.APIservices.cancelPORequest(data).toPromise()
        if (cancelResult) {
          // remove item change khỏi bảng list po cancel request
          $(`#form_cancel_po_${po_id}`).remove();
          // Remove po này khỏi list po total
          $(`#${po_id}`).hide()
          // close table if done all
          let isDoneAll = $('#render_list_PO_cancel').find('table').length == 0
          if (isDoneAll) {
            const modal = bootstrap.Modal.getInstance($('#modal_cancelPO')).hide()
          }
          _that.renderChartPO()

        } else {
          _that.DOMService.showAlertMassage("System Error! Plz Refresh page", false)
        }
        _that.DOMService.onloaded(".btn_submit_cancel_po")
      }
    });
  }

  //Done
  issuePO() {

    let _that = this

    Validator({
      form: '#form_issue_PO',
      formGroupSelector: '.nice-form-group',
      rules: [
        Validator.isRequired('select[name=vendor_fctry]'),
        Validator.isRequired('select[name=need_register_rate_table_by_part]'),
        Validator.isNumber('input[name=order_qty]'),
        Validator.isRequired('input[name=delivery_location]'),
        Validator.isNumber('input[name=warranty_shot]'),
        Validator.isRequired('input[name=trade_condition_p_name]'),
        Validator.isRequired('input[name=use_block_code]'),
        Validator.isRequired('input[name=item_category]'),
        Validator.isRequired('select[name=transport_method]'),
        Validator.isRequired('textarea[name=temp_reason]', 'Input "-" if normal PO'),
      ],
      onSubmit: async function (data: any) {

        data.po_ids = _that.getSelectedIDs()
        console.log(data)
        _that.DOMService.onloading(".btn_submit_issue_PO")
        let issueResult = await _that.APIservices.IssuePO(data).toPromise()
        if (issueResult?.status) {
          _that.renderChartPO()
          const modal = bootstrap.Modal.getInstance($('#modal_issuePO')).hide()
        } else {
          _that.DOMService.showAlertMassage("System Error! Plz Refresh page", false)
        }

        _that.DOMService.onloaded(".btn_submit_issue_PO")
      }
    });

  }


  async checkMR(mr_id: number | undefined, isPAETurn: boolean | undefined) {
    let _that = this
    if (mr_id) { //check one by one
      let users = this.authen.isLogined().user
      if (isPAETurn) {
        Validator({
          form: '#form_PAE_Check_MR',
          formGroupSelector: '.nice-form-group',
          rules: [
            Validator.isRequired('select[name=check_is_de_die]'),
            Validator.isRequired('input[name=check_no_of_die_component]'),
            Validator.isNumber('input[name=check_no_of_die_component]'),
            Validator.isRequired('input[name=check_die_maker]'),
            Validator.isRequired('input[name=check_make_location]'),
          ],
          onSubmit: async function (data: any) {

            data.mRIDs = mr_id
            _that.DOMService.onloading(".btn_check_MR")

            // PAE duoc phep sua vai thong tin khac cua dept issue
            let pdd = $('#form_mr_information input[name=pdd]').val()
            let model_id = $('#form_mr_information select[name=model_id]').val()
            let cav_qty = $('#form_mr_information input[name=cav_qty]').val()
            let mc_size = $('#form_mr_information input[name=mc_size]').val()
            let supplier_id = $('#form_mr_information select[name=supplier_id]').val()
            let common_part = $('#form_mr_information input[name=common_part]').val()
            let family_part = $('#form_mr_information input[name=family_part]').val()
            if (!(pdd && model_id && cav_qty && mc_size && supplier_id)) {
              _that.DOMService.showAlertMassage('Yellow cell "PDD, Model,Cav,MC Size, Supplier" can not empty!', false)
              _that.DOMService.onloaded(".btn_check_MR")
              return
            }

            data.pdd = pdd
            data.model_id = model_id
            data.cav_qty = cav_qty
            data.mc_size = mc_size
            data.supplier_id = supplier_id
            data.common_part = common_part
            data.family_part = family_part

            let result = await _that.APIservices.checkAndApproveAndRejectMR(data).toPromise()

            if (result?.success.length !== 0) {
              result?.success.forEach((mr_id: any) => {
                $(`#${mr_id}`).css('display', 'none')
              })
              const modal = bootstrap.Modal.getInstance($('#showModalMRDetail')).hide()
              _that.renderChartPO()
            }

            if (result?.fail.length !== 0) {
              _that.DOMService.showAlertMassage(result?.fail[0], false)
            }

            _that.DOMService.onloaded(".btn_check_MR")
          }
        })
      } else {
        _that.DOMService.onloading(".btn_check_MR")
        let data = {
          mRIDs: mr_id,
          check_comment: $('textarea[name=check_comment]').val(),
          budget_code: $('select[name=budget_code]').val()
        }
        let result = await _that.APIservices.checkAndApproveAndRejectMR(data).toPromise()
        if (result?.success.length !== 0) {
          result?.success.forEach((mr_id: any) => {
            $(`#${mr_id}`).css('display', 'none')
          })
          const modal = bootstrap.Modal.getInstance($('#showModalMRDetail')).hide()
          _that.renderChartPO()
        }
        if (result?.fail.length !== 0) {
          _that.DOMService.showAlertMassage(result?.fail[0], false)
        }
        _that.DOMService.onloaded(".btn_check_MR")
      }

    } else { // mutipli check
      // function này show modal confirm trước khi approve
      let mrSelected: any = this.getSelectedIDs()
      if (!mrSelected.length) {
        this.DOMService.showAlertMassage("You need select MR which you one to take action", false)
        return
      }
      if (this.authen.isLogined().user[0].dept_name.includes("PAE")) {
        this.DOMService.showAlertMassage("PAE need check MR one by one", false)
        return
      }
      $('#label_confirming').text('You are checking for ' + mrSelected.length + ' MR(s)')
      const modalMassage = new bootstrap.Modal('#modal_approve_confirm', {
        keyboard: true
      })
      modalMassage.show()
    }
  }

  async approveMR(mr_id: number | undefined, isPAETurn: boolean | undefined) {
    let _that = this
    if (mr_id) { // one by one approve
      let users = this.authen.isLogined().user

      if (isPAETurn) {
        Validator({
          form: '#form_PAE_Check_MR',
          formGroupSelector: '.nice-form-group',
          rules: [
            Validator.isRequired('select[name=check_is_de_die]'),
            Validator.isRequired('input[name=check_no_of_die_component]'),
            Validator.isNumber('input[name=check_no_of_die_component]'),
            Validator.isRequired('input[name=check_die_maker]'),
            Validator.isRequired('input[name=check_make_location]'),
          ],
          onSubmit: async function (data: any) {
            data.mRIDs = mr_id
            _that.DOMService.onloading(".btn_check_MR")
            let result = await _that.APIservices.checkAndApproveAndRejectMR(data).toPromise()

            if (result?.success.length !== 0) {
              // hide MR seccess
              result?.success.forEach((mr_id: any) => {
                $(`#${mr_id}`).css('display', 'none')
              })
              //hide modal
              const modal = bootstrap.Modal.getInstance($('#showModalMRDetail')).hide()
              //render lai chart
              _that.renderChartPO()
            }
            if (result?.fail.length !== 0) {
              _that.DOMService.showAlertMassage(result?.fail[0], false)
            }
            _that.DOMService.onloaded(".btn_check_MR")
          }
        })
      } else {
        _that.DOMService.onloading(".btn_Approve_MR")
        let data = {
          mRIDs: mr_id,
          check_comment: $('textarea[name=check_comment]').val()
        }
        let result = await _that.APIservices.checkAndApproveAndRejectMR(data).toPromise()
        if (result?.success.length !== 0) {
          //hide MR success
          result?.success.forEach((mr_id: any) => {
            $(`#${mr_id}`).css('display', 'none')
          })
          // hide model
          const modal = bootstrap.Modal.getInstance($('#showModalMRDetail')).hide()
          // render chart
          _that.renderChartPO()
        }
        if (result?.fail.length !== 0) {
          _that.DOMService.showAlertMassage(result?.fail[0], false)
        }
        _that.DOMService.onloaded(".btn_Approve_MR")
      }
    } else { // muitipli Approve
      // function này show modal confirm trước khi approve
      let mrSelected: any = this.getSelectedIDs()
      $('#label_confirming').text('You are approving for ' + mrSelected.length + ' MR(s)')
      const modalMassage = new bootstrap.Modal('#modal_approve_confirm', {
        keyboard: true
      })
      modalMassage.show()
    }

  }


  async confirmApproveMR() {
    let _that = this
    this.DOMService.onloading('.btn_confirm_approve')
    let mrSelected: any = this.getSelectedIDs()
    let comment = $('#approver_comment').val()
    if (mrSelected.length == 0) {
      this.DOMService.showAlertMassage('Please select MR which you want to approve!', false)
      this.DOMService.onloaded('.btn_confirm_approve')
      return
    }

    let approveResult = await this.APIservices.checkAndApproveAndRejectMR({ mRIDs: mrSelected, check_comment: comment }).toPromise()
    if (approveResult?.success.length != 0) {
      // load lai chart 
      _that.renderChartPO()
      // hide MR success
      approveResult?.success.forEach((mr_id: any) => {
        $(`#${mr_id}`).css('display', 'none')
      })
    }

    if (approveResult?.fail.length != 0) {
      // show massage
      let msg = ''
      approveResult?.fail.forEach((e: any, index: any) => {
        msg += (index + 1) + ". " + e + "</br>"
      })
      _that.DOMService.showAlertMassage(msg, false)
    }

    this.DOMService.onloaded('.btn_confirm_approve')
    const modal = bootstrap.Modal.getInstance($('#modal_approve_confirm')).hide()
  }


  async rejectMR(mr_id: number | undefined) {
    let _that = this
    if (mr_id) { // one by on reject
      let comment = $('textarea[name=check_comment]').val()
      if (!comment) {
        _that.DOMService.showAlertMassage('Please commemt reason reject this MR!', false)
        return
      }
      let rejectResult = await this.APIservices.checkAndApproveAndRejectMR({ mRIDs: mr_id, check_comment: comment, isReject: true }).toPromise()
      if (rejectResult?.success.length !== 0) {
        rejectResult?.success.forEach((mr_id: any) => {
          $(`#${mr_id}`).css('display', 'none')
        })
        const modal = bootstrap.Modal.getInstance($('#showModalMRDetail')).hide()
        _that.renderChartPO()
      }

      if (rejectResult?.fail.length !== 0) {
        _that.DOMService.showAlertMassage(rejectResult?.fail[0], false)
      }
    } else { // mutipli reject
      // function này show modal confirm trước khi approve
      let mrSelected: any = this.getSelectedIDs()
      $('#label_reject_confirming').text('You are rejecting for ' + mrSelected.length + ' MR(s)')
      const modalMassage = new bootstrap.Modal('#modal_reject_confirm', {
        keyboard: true
      })
      modalMassage.show()
    }
  }

  async confirmRejectMR() {
    let _that = this
    this.DOMService.onloading('.btn_confirm_reject')
    let mrSelected: any[] = this.getSelectedIDs()
    let comment = $('#reject_comment').val()
    if (mrSelected.length == 0) {
      this.DOMService.showAlertMassage('Please select MR which you want to approve!', false)
      this.DOMService.onloaded('.btn_confirm_reject')
      return
    }

    let rejectResult = await this.APIservices.checkAndApproveAndRejectMR({ mRIDs: mrSelected, check_comment: comment, isReject: true }).toPromise()
    if (rejectResult?.success.length != 0) {
      // load lai chart 
      _that.renderChartPO()
      // hide MR success
      rejectResult?.success.forEach((mr_id: any) => {
        $(`#${mr_id}`).css('display', 'none')
      })
    }

    if (rejectResult?.fail.length != 0) {
      // show massage
      let msg = ''
      rejectResult?.fail.forEach((e: any, index: any) => {
        msg += (index + 1) + ". " + e + "</br>"
      })
      _that.DOMService.showAlertMassage(msg, false)
    }




    this.DOMService.onloaded('.btn_confirm_reject')
    const modal = bootstrap.Modal.getInstance($('#modal_reject_confirm')).hide()
  }



  // done
  charOptions = {
    series: [],
    annotations: {
      points: [{
        x: 'Bananas',
        seriesIndex: 0,
        label: {
          borderColor: '#775DD0',
          offsetY: 0,
          style: {
            color: '#fff',
            background: '#775DD0',
          },
          text: 'Bananas are good',
        }
      }]
    },
    chart: {
      height: 250,
      type: 'bar',
      events: {
        dataPointSelection: async (event: any, chartContext: any, opts: any) => {
          let index = opts.dataPointIndex
          let data = await opts.w.config.xaxis.categories[index]
          console.log(opts.w.config.xaxis)
          let qty = opts.w.config.series[0].data[index]
          this.searchParameter = {
            search: data,
            page: 1
          }
          this.renderTable(this.searchParameter)
        }
      },
    },
    plotOptions: {
      bar: {
        borderRadius: 0,
        columnWidth: '70%',
      }
    },
    dataLabels: {
      enabled: true,
      textAnchor: 'middle',
      offsetY: 0,
      style: {
        fontFamily: 'Helvetica, Arial, sans-serif',
        fontWeight: 'bold',
        colors: ['#000']
      }
    },
    stroke: {
      width: 0
    },
    grid: {
      row: {
        colors: ['#fff', '#f2f2f2']
      }
    },
    xaxis: {
      labels: {
        rotate: -45,
        style: {
          fontSize: '9px',
        }
      },
      categories: [],

    },
    yaxis: {
      title: {
        text: 'POs',
      },
      logarithmic: true,
      logBase: 10,
      min: 0.1,
      forceNiceScale: true

    },
    fill: {
      type: 'gradient',
      gradient: {
        shade: 'light',
        type: "horizontal",
        shadeIntensity: 0.25,
        gradientToColors: undefined,
        inverseColors: true,
        opacityFrom: 0.85,
        opacityTo: 0.85,
        stops: [50, 0, 100]
      },
    }
  };

  // done
  async renderChartPO() {
    let poPending = await this.APIservices.getSumarizePOPending().toPromise()

    let data: any = [];
    let category: any = []
    poPending?.data.forEach((e: any) => {
      data.push(e.qty)
      category.push(e.status)
    });

    let series: any = [{
      name: 'PO',
      data: data
    }]
    //let category:any = ['W-PAE', 'W-PE1', 'W-PUR', 'W-ddd']
    var options = this.charOptions
    options.series = series
    options.xaxis.categories = category

    $('#render_chart_box').empty()
    var chart = new ApexCharts(document.querySelector("#render_chart_box"), options);
    chart.render();
  }



  // Done (keep same MR)
  async downloadMRformByID(mr_id: number) {
    let dowloadResult = await this.APIservices.downloadMRFormById(mr_id).toPromise();
    if (dowloadResult?.status) {
      window.location.href = this.APIHost + '/Download/FileDownload?fileGuid=' + dowloadResult.linkdowload.fileGuid + '&fileName=' + dowloadResult.linkdowload.fileName + '&contentType=' + dowloadResult.linkdowload.contentType;
    } else {
      this.DOMService.showAlertMassage(dowloadResult?.msg, false)
    }
  }

  async dowloadListMR() {
    let dowloadResult = await this.APIservices.downloadMRList(this.searchParameter).toPromise();
    if (dowloadResult?.data) {
      window.location.href = this.APIHost + '/Download/FileDownload?fileGuid=' + dowloadResult.data.fileGuid + '&fileName=' + dowloadResult.data.fileName + '&contentType=' + dowloadResult.data.contentType;
    } else {
      this.DOMService.showAlertMassage("System Erorr!", false)
    }
  }

  showPODetail(po_id: number) {
    this.DOMService.renderModalPODetail(po_id)
  }

  selectAll(isSelectAll: boolean) {
    this.DOMService.selectAll('row_po_id', isSelectAll)
  }

  getSelectedIDs() {

    return this.DOMService.getSelectedID('row_po_id')
  }







}
