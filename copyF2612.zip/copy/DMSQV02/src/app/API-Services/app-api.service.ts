import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { HttpClient, HttpHeaders, HttpParams, HttpErrorResponse } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { Router, UrlTree } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AppAPIService {

  constructor(private http: HttpClient, private router: Router) { }
  private apiCommonUrl = 'http://localhost:5019/commonAPI';
  //private apiCommonUrl = 'http://cqv-veng:9001/commonAPI';
  private apiMRURL = 'http://localhost:5019/MR_API';
  //private apiMRURL = 'http://cqv-veng:9001/MR_API';

  private apiPOURL = 'http://localhost:5019/PO_API';
  //private apiPOURL = 'http://cqv-veng:9001/PO_API';

  private apiDownload = 'http://localhost:5019/Download';
  //private apiDownload = 'http://cqv-veng:9001/Download';

  private handleError(error: HttpErrorResponse) {
    try {

      if (error.status === 0) {
        // Lỗi phía client hoặc lỗi mạng
        console.error('An error occurred:', error.error);
      } else if (error.status === 404) {
        // Lỗi 404 - Không tìm thấy
        console.error('Not Found:', error.message);
      } else {
        // Các lỗi khác từ server
        console.error(`Backend returned code ${error.status}, body was: `, error.error);
      }
    } catch (e) {

    }

    // Trả về một observable với thông báo lỗi thân thiện với người dùng
    //location.href = '/error'
    return throwError(() => new Error('Something bad happened; please try again later.'));

  }

  private convertToFormData(data: any): FormData {
    let formData = new FormData()
    for (let key in data) {

      if (data.hasOwnProperty(key)) {
        formData.append(key, data[key]);
      }
    }
    return formData
  }

  getGradeCategory(): Observable<{ rowEffected: number, data: any[] }> {
    return this.http.get<{ rowEffected: number, data: any[] }>(this.apiCommonUrl + '/api_DMSGradeCategory', { withCredentials: true })
  }

  getRolesCategory(): Observable<{ rowEffected: number, data: any[] }> {
    return this.http.get<{ rowEffected: number, data: any[] }>(this.apiCommonUrl + '/api_DMSRoleCategory', { withCredentials: true })
  }

  getListDept(): Observable<{ rowEffected: number, data: any[] }> {
    return this.http.get<{ rowEffected: number, data: any[] }>(this.apiCommonUrl + '/api_GetListDept', { withCredentials: true })
  }

  getMRTypeCategory(): Observable<{ rowEffected: number, data: any[] }> {
    return this.http.get<{ rowEffected: number, data: any[] }>(this.apiCommonUrl + '/api_GetMRTypeCategory', { withCredentials: true })
  }

  getSupplierList(): Observable<{ rowEffected: number, data: any[] }> {
    return this.http.get<{ rowEffected: number, data: any[] }>(this.apiCommonUrl + '/api_GetSupplierList', { withCredentials: true })
  }

  getProcessCodeCategory(): Observable<{ rowEffected: number, data: any[] }> {
    return this.http.get<{ rowEffected: number, data: any[] }>(this.apiCommonUrl + '/api_GetProcessCodeCategory', { withCredentials: true })
  }
  getModelList(): Observable<{ rowEffected: number, data: any[] }> {
    return this.http.get<{ rowEffected: number, data: any[] }>(this.apiCommonUrl + '/api_GetModelList', { withCredentials: true })
  }


  getBudgetCodeList(): Observable<{ rowEffected: number, data: any[] }> {
    return this.http.get<{ rowEffected: number, data: any[] }>(this.apiCommonUrl + '/api_GetBudgetCodeList', { withCredentials: true })
  }


  getMRList(data: any): Observable<{ status: boolean, msg: string, page: number, pageSize: number, recordsTotal: number, recordsFiltered: number, data: any }> {
    let formData = this.convertToFormData(data);
    return this.http.post<any>(this.apiMRURL + '/api_getMRList', formData, { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }

  getSumarizeMRPending(): Observable<{ rowEffected: number, data: any[] }> {
    return this.http.get<any>(this.apiMRURL + '/api_getSumarizeMRPending', { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }

  isExistMR(data: any): Observable<{ status: boolean, msg: string }> {
    let formData = this.convertToFormData(data);
    return this.http.post<any>(this.apiMRURL + '/api_isExistMR', formData, { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }

  getDieInforForIssueMR(data: any): Observable<{ status: boolean, msg: string, data: any }> {
    let formData = this.convertToFormData(data);
    return this.http.post<any>(this.apiMRURL + '/api_getDieInforToIssueMR', formData, { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }

  linkToECN(partNo: string): Observable<[]> {
    return this.http.get<any>('http://cqv-vspis:5000/api/PE1/ecn_pae_new/' + partNo).pipe(
      catchError(this.handleError)
    )
  }

  issueMR(data: any): Observable<{ status: boolean, msg: string }> {
    let formData = this.convertToFormData(data);
    return this.http.post<any>(this.apiMRURL + '/api_issueMR', formData, { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }
  issueMRByExcel(data: any): Observable<{ fail: number, success: number, msg: string, listFail: any[] }> {

    return this.http.post<any>(this.apiMRURL + '/api_issueMRByExcel', data, { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }

  checkAndApproveAndRejectMR(data: any): Observable<{ status: boolean, msg: string, success: any[], fail: any[] }> {
    let formData = this.convertToFormData(data);
    return this.http.post<any>(this.apiMRURL + '/api_checkAndApproveAndRejectMR', formData, { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }

  downloadMRFormById(mr_id: number): Observable<{ status: boolean, msg: string, linkdowload: any }> {

    return this.http.get<any>(this.apiDownload + '/MRFORM/' + mr_id, { withCredentials: true })
  }

  downloadMRList(data: any): Observable<{ data: any }> {
    let formData = this.convertToFormData(data);
    return this.http.post<any>(this.apiDownload + '/ListMR', formData, { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }

  downloadAttachment(pathFull: string) {
    window.location.href = this.apiDownload + '/FileDownload?pathFullFile=' + pathFull
  }

  getMRById(mr_id: number): Observable<{ status: boolean, msg: string, data: any[] }> {
    return this.http.get<any>(this.apiMRURL + '/api_getMRByID/' + mr_id, { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }

  getMRStatusRespon(statusID: number): Observable<{ status: boolean, msg: string, data: any[] }> {
    return this.http.get<any>(this.apiMRURL + '/api_getMRStatusResponByID/' + statusID, { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }

  getTPIRelatedDieNo(data: any): Observable<{ status: boolean, msg: string, data: any[] }> {
    let formData = this.convertToFormData(data);
    return this.http.post<any>(this.apiCommonUrl + '/api_getTPIRelatedDieNo', formData, { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }

  getDFMRelatedDieNo(data: any): Observable<{ status: boolean, msg: string, data: any[] }> {
    let formData = this.convertToFormData(data);
    return this.http.post<any>(this.apiCommonUrl + '/api_getDFMRelatedDieNo', formData, { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }

  checkDieExist(data: any): Observable<{ status: boolean, msg: string }> {
    let formData = this.convertToFormData(data);
    return this.http.post<any>(this.apiCommonUrl + '/api_checkDieExist', formData, { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }


  // PHẦN PO

  getPOList(data: any): Observable<{ status: boolean, msg: string, page: number, pageSize: number, recordsTotal: number, recordsFiltered: number, data: any }> {
    let formData = this.convertToFormData(data);
    return this.http.post<any>(this.apiPOURL + '/api_getPOList', formData, { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }

  checkItemsCanIssuePO_new_change_cancel(data: any): Observable<{ data: any }> {
    let formData = this.convertToFormData(data);
    return this.http.post<any>(this.apiPOURL + '/api_checkItemCanIssue_change_cancel', formData, { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }


 

  getPOById(po_id: number): Observable<{ status: boolean, msg: string, data: any[] }> {
    return this.http.get<any>(this.apiPOURL + '/api_getPOByID/' + po_id, { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }
  getSumarizePOPending(): Observable<{ rowEffected: number, data: any[] }> {
    return this.http.get<any>(this.apiPOURL + '/api_getSumarizePOPending', { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }

  IssuePO(data: any): Observable<{status: boolean, msg: string, success:number, fail: number}> {
    let formData = this.convertToFormData(data);
    return this.http.post<any>(this.apiPOURL + '/api_issuePO', formData, { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }

  changePORequest(data: any): Observable<boolean> {
    let formData = this.convertToFormData(data);
    return this.http.post<any>(this.apiPOURL + '/api_changePORequest', formData, { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }

  cancelPORequest(data: any): Observable<boolean> {
    let formData = this.convertToFormData(data);
    return this.http.post<any>(this.apiPOURL + '/api_cancelPORequest', formData, { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }













}
