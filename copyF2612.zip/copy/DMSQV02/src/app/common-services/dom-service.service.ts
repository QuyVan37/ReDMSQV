import { Injectable } from '@angular/core';

import moment from 'moment';
import { AppAPIService } from '../API-Services/app-api.service';
import { AuthenService } from '../API-Services/authen.service';
declare var $: any;
declare var bootstrap: any;
declare function selectjs(): any
@Injectable({
  providedIn: 'root'
})
export class DOMServiceService {

  constructor(
    private APIservices: AppAPIService,
    private Authen: AuthenService

  ) { }
  onloading(selector: string) {
    $(document).find(selector).addClass('disabled')
    $(document).find(selector).children('.spinner-border').remove()
    $(document).find(selector).append(
      `
        <span class="spinner-border spinner-border-sm" aria-hidden="true"></span>
      `)
  }

  onloaded(selector: string) {
    $(document).find(selector).children('.spinner-border').remove()
    $(document).find(selector).removeClass('disabled')
  }


  createOptionElement(
    listOption: any[] | undefined,
    fields_view: Array<string>,
    Field_value: string,
    selected_Value: string
  ): string {
    let option = '<option value="">---</option>';
    listOption?.forEach(e => {
      let view: Array<string> = [];
      fields_view.forEach(f => {
        view.push(e[f]);
      });
      option += `<option ${e[Field_value] === selected_Value ? 'selected' : ''} value="${e[Field_value]}">${view.join('-')}</option>`;
    });
    return option;
  }

  appendToElement(selector: string, content: string) {
    $(selector).empty().append(content)
  }


  showAlertMassage(massage: string | undefined, isSucces: boolean) {

    // massageType: success or faill
    let bg_color = "danger"
    if (isSucces) bg_color = 'success'
    //1. Loại bỏ modal ra khỏi DOM nếu có
    $(document).find('#modelAlertMassage').remove()
    //2. add modal vào DOM
    $('.content').append(
      `
     <div class="modal fade" id="modelAlertMassage" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
     <div class="modal-dialog">
         <div class="modal-content">
         <div class="modal-header bg-${bg_color} text-white">
             <h1 class="modal-title fs-5" id="exampleModalLabel">System massage</h1>
             <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
         </div>
         <div class="modal-body overflow-auto" style='max-height:300px'>
             ${massage}
         </div>
         <div class="modal-footer">
             <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
         </div>
         </div>
     </div>
     </div>
     `
    )

    // 3. show modal
    const modalMassage = new bootstrap.Modal('#modelAlertMassage', {
      keyboard: false
    })
    modalMassage.show()
  }

  showUserInActiveWaning(msg: string) {
    //1. Loại bỏ modal ra khỏi DOM nếu có
    $(document).find('#modelAlertMassage').remove()

    $('.content').append(
      `
        <div class="modal fade" id="modalWarningUserNotActive" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header bg-danger">
                <h1 class="modal-title fs-5" id="staticBackdropLabel">Waring: You account was not active!</h1>
              </div>
              <div class="modal-body">
                  ${msg}

              </div>
                <div class="modal-footer">
                  <a href="/login">Login other account</a>
                </div>
            </div>
          </div>
        </div>
     `
    )
    // 3. show modal
    const modalMassage = new bootstrap.Modal('#modalWarningUserNotActive', {
      keyboard: false
    })
    modalMassage.show()

  }

  pagination(page: number = 1, pageSize: number = 0, totalRecords: number = 0, selector: string) {

    let previousePage = page - 1;
    let nextPage = page + 1;
    let firstPage = 1;
    let lastPage = Number.isNaN(Math.ceil(totalRecords / pageSize)) ? 1 : Math.ceil(totalRecords / pageSize);
    nextPage = nextPage > lastPage ? lastPage : lastPage == 0 ? 0 : nextPage

    let pagination = `
      <ul class="pagination m-0">
        <li class="page-item ${previousePage == 0 ? "disabled" : ""}">
         <span class="cursor page-link page-data" data-page = ${previousePage} >Previous</span>
        </li>
        ${previousePage >= 1 ?
        `<li class="page-item">
             <span class="cursor page-link page-data" data-page = ${firstPage}  href="#">${firstPage}</span>
          </li>
          <li class="page-item page-link page-data disabled">...</li>
          ` : ''}
         
          ${page > 1 ?
        ` <li class="page-item">
              <span class="cursor page-link page-data" data-page = ${previousePage} href="#">${previousePage}</span>
              </li>
            ` : ''}
        
        <li class="page-item">
         <span class="cursor page-link page-data active" data-page = ${page} href="#">${page}</span>
        </li>
        ${nextPage == page || nextPage == 0 ? "" :
        `
            <li class="page-item">
             <span class="cursor page-link page-data" data-page = ${nextPage} href="#">${nextPage}</span>
            </li>
          `
      }
        ${lastPage - nextPage >= 1 ?
        `
          <li class="page-item page-link page-data disabled">...</li>
          <li class="page-item">
             <span class="cursor page-link page-data" data-page = ${lastPage} href="#">${lastPage}</span>
            </li>
          
          ` : ''}
        
            <li class="page-item">
             <span class="cursor page-link page-data ${nextPage == page || nextPage == 0 ? 'disabled' : ''}"  data-page = ${nextPage} href="#">Next</span>
            </li>
        
      </ul>

    `
    $(selector).empty().append(pagination)

  }


  async renderModalUserDetail(userProfile: any) {
    let listGrade = await this.APIservices.getGradeCategory().toPromise()
    let listDept = await this.APIservices.getListDept().toPromise()
    let listRole = await this.APIservices.getRolesCategory().toPromise()
    let user = userProfile.userProfile;
    let roles = userProfile.roles;
    let depts = roles.map((e: any) => {
      return e.dept_name + '-' + e.factory
    });

    //1. Loại bỏ modal ra khỏi DOM nếu có
    $(document).find('#showmodalDetail').remove()
    $('.content').append(`
        <div class="modal fade" id="showmodalDetail" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">User ${user.user_name}</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <form action="" method="post" id="form_user_information">
                  <div class="row g-2">
                    <div hidden class="nice-form-group col-sm-12 col-md-2">
                      <label>User_id</label>
                      <input type="text" hidden name="user_id" value='${user.user_id}'>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <label>Name</label>
                      <input type="text" name="user_name" value='${user.user_name}'>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <label>Code</label>
                      <input type="text" name="user_code" value='${user.user_code}'>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <label>Buyer code</label>
                      <input type="text" name="buyer_code" value='${user.buyer_code}'>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <label>Grade</label>
                      <select name="grade_id">
                        ${this.createOptionElement(listGrade?.data, ["grade_name"], 'grade_id', user.grade_id)}
                      </select>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <label>Email</label>
                      <input type="email" name="email" value='${user.email}'>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <label>Lock Reason</label>
                      <input type="text" name="lock_reason" value='${user.lock_reason}'>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <label>Last_online</label>
                      <input type="text" disabled name="last_online" value='${moment(user.last_online).format('YYYY/MM/DD HH:mm:ss A')}'>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <label>Create Date</label>
                      <input type="text" disabled name="create_date" value='${moment(user.create_date).format('YYYY/MM/DD HH:mm:ss A')}'>
                    </div>
                  </div>
                  <div class="row">
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <input name="is_admin" type="checkbox" id="isAdmin" ${user.is_admin ? "checked" : ""} class="switch" />
                      <label for="isAdmin">Admin</label>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <input name="is_active" type="checkbox" id="is_Active" ${user.is_active ? "checked" : ""} class="switch" />
                      <label for="is_Active">Active</label>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <input name="is_delete" type="checkbox" id="is_Delete" ${user.is_delete ? "checked" : ""} class="switch" />
                      <label for="is_Delete">Delecte</label>
                    </div>

                  </div>
                 
                </form>
                <hr>
                <div>
                  This user was set roles for 2 depts: <span class="fw-bold">${depts}</span>
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <form action="" method="post" id="form_update_role">
                      <div class="row">

                        <div class="row g-2">
                          <div class="nice-form-group dept_id col-md-12">
                            <label>Department</label>
                            <select name="dept_id" class='selectjs'>
                            ${this.createOptionElement(listDept?.data, ["dept_name", 'factory'], 'dept_id', roles[0].dept_id)}
                            </select>
                          </div>
                          <div class="nice-form-group col-sm-12 col-md-3">
                            <label>MR Role</label>
                            <select name="mr_role_id">
                             ${this.createOptionElement(listRole?.data, ["role_name"], 'role_id', roles[0].mr_role_id)}
                            </select>
                          </div>
                          <div class="nice-form-group col-sm-12 col-md-3">
                            <label>PO Role</label>
                            <select name="po_role_id">
                             ${this.createOptionElement(listRole?.data, ["role_name"], 'role_id', roles[0].po_role_id)}
                            </select>
                          </div>
                          <div class="nice-form-group col-sm-12 col-md-3">
                            <label>TPI Role</label>
                            <select name="tpi_role_id">
                             ${this.createOptionElement(listRole?.data, ["role_name"], 'role_id', roles[0].tpi_role_id)}
                            </select>
                          </div>
                          <div class="nice-form-group col-sm-12 col-md-3">
                            <label>Die Role</label>
                            <select name="die_role_id">
                             ${this.createOptionElement(listRole?.data, ["role_name"], 'role_id', roles[0].die_role_id)}
                            </select>
                          </div>
                          <div class="nice-form-group col-sm-12 col-md-3">
                            <label>Transfer (DTF)</label>
                            <select name="dtf_role_id">
                             ${this.createOptionElement(listRole?.data, ["role_name"], 'role_id', roles[0].dtf_role_id)}
                            </select>
                          </div>
                          <div class="nice-form-group col-sm-12 col-md-3">
                            <label>DSUM (DFM)</label>
                            <select name="dsum_role_id">
                             ${this.createOptionElement(listRole?.data, ["role_name"], 'role_id', roles[0].dsum_role_id)}
                            </select>
                          </div>
                          <div class="nice-form-group col-sm-12 col-md-3">
                            <label>Dispose</label>
                            <select name="dispose_role_id">
                             ${this.createOptionElement(listRole?.data, ["role_name"], 'role_id', roles[0].dispose_role_id)}
                            </select>
                          </div>
                          <div class="nice-form-group col-sm-12 col-md-3">
                            <label>DCF</label>
                            <select name="dcf_role_id">
                             ${this.createOptionElement(listRole?.data, ["role_name"], 'role_id', roles[0].dcf_role_id)}
                              </select>
                          </div>
                        </div>
                      </div>
                      <div class="d-flex justify-content-end mt-2">
                        <span data-user-id="${user.user_id}" class="btn btn-primary btn_admin_change_user_role">Change Role</span>
                      </div>
                    
                    </form>
                  </div>
                </div>

              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" action="save" class="btn btn-primary  btn_admin_verified_users">Save
                  changes</button>
                <button type="button" action="verify" class="btn btn-primary btn_admin_verified_users" ">Verified</button>
                 
              </div>
            </div>
          </div>
        </div>
    
    
    
    `)

    const modalMassage = new bootstrap.Modal('#showmodalDetail', {
      keyboard: false
    })
    modalMassage.show()
  }

  async renderModalMRDetail(mr_id: number) {

    let data = await this.APIservices.getMRById(mr_id).toPromise();
    let mrTypeCategory = await this.APIservices.getMRTypeCategory().toPromise()
    let suppliers = await this.APIservices.getSupplierList().toPromise()
    let budgetCodeList = await this.APIservices.getBudgetCodeList().toPromise()
    let modelList = await this.APIservices.getModelList().toPromise()

    let mr: any = data?.data[0];
    let statusRes = await this.APIservices.getMRStatusRespon(mr.status_id).toPromise()
    let users = this.Authen.isLogined().user
    let isAdmin = users[0].is_admin

    let userDeptsAndRole: { dept_name: any, factory: any, mr_role_id: any, grade_id: number }[] = []

    users.forEach((e: any) => {
      userDeptsAndRole.push({
        dept_name: e.dept_name,
        factory: e.factory,
        mr_role_id: e.mr_role_id,
        grade_id: e.grade_id
      })

    })



    let listTPIattach: any = []
    let listDFM: any = []
    if (mr.tpi_id) {
      let listIDs = mr.tpi_id.split(',')
      listIDs.forEach((e: any, index: number) => {
        listTPIattach.push(`[<a target="_blank" href="/tpi/${e}">TPI ${index + 1}</a>]`)
      })
    }
    if (mr.dfm_id) {
      let listIDs = mr.dfm_id.split(',')
      listIDs.forEach((e: any, index: number) => {
        listDFM.push(`[<a target="_blank" href="/dsum/${e}">DFM ${index + 1}</a>]`)
      })
    }
    // Phân quyền
    let isChecker = userDeptsAndRole.some((e: any) => { return ["PAE", "PE1", "CRG", "PLAN", "PUR"].includes(e.dept_name) && ["QV"].includes(e.factory) && [3].includes(e.mr_role_id) && statusRes?.data[0].dept_res.includes(e.dept_name) })
    let isApprover = userDeptsAndRole.some((e: any) => { return ["PAE", "PE1", "CRG", "PLAN", "PUR"].includes(e.dept_name) && ["QV"].includes(e.factory) && [4, 5].includes(e.mr_role_id) && statusRes?.data[0].dept_res.includes(e.dept_name) })
    let isYourTurn = userDeptsAndRole.some((e: any) => { return statusRes?.data[0].dept_res.includes(e.dept_name) && statusRes?.data[0].mr_role_id_res == e.mr_role_id })
    let isShowPermit = (isChecker || isApprover) && isYourTurn
    let isPAETurn = userDeptsAndRole.some((e: any) => { return ["PAE"].includes(e.dept_name) && statusRes?.data[0].dept_res.includes("PAE") })
    let isPLANTurn = userDeptsAndRole.some((e: any) => { return ["PLAN"].includes(e.dept_name) && statusRes?.data[0].dept_res.includes("PLAN") })
    let permitContentForPAE = `
      <form action="" method="post" id="form_PAE_Check_MR" class="checkMR">
        <div class="responseTitle">${statusRes?.data[0].dept_res} Check</div>
        <div class="row">
            <div class='col-10'>
              <div class="row g-2">
                <div class="nice-form-group col-sm-12 col-md-2">
                  <label>DE Die</label>
                  <select name="check_is_de_die">
                    <option  value="N">No</option>
                    <option ${mr.is_de_die ? "selected" : ""} value="Y">Yes</option>
                  </select>
                </div>
                <div class="nice-form-group col-sm-12 col-md-2">
                  <label>Die Component</label>
                  <input  type='text' name='check_no_of_die_component' value='${mr.no_of_die_component}' />
                </div>
                <div class="nice-form-group col-sm-12 col-md-2">
                  <label>Die Maker</label>
                  <input  type='text' name='check_die_maker' value='${mr.order_to}' />
                </div>
                <div class="nice-form-group col-sm-12 col-md-2">
                  <label>Location</label>
                  <input  type='text' name='check_make_location' placeholder="VN,CN,JP,..." value='${mr.make_location}' />
                </div>
                <div class="nice-form-group col-sm-12 col-md-4">
                  <label> Die_special</label>
                  <input  type='text' name='check_die_special' placeholder="HC,H&C, Printing,..." value='${mr.die_special}' />
                </div>
                <div class="nice-form-group  col-md-12">
                  <label>Comment</label>
                  <textarea type='text' name='check_comment' placeholder=""></textarea>
                </div>
              </div>
            </div>
            <div class='col-2'>
               <div class="d-grid gap-2 mt-4 align-self-end">
               ${isChecker ? ` <button class="btn btn-primary btn_check_MR" data-is-pae-turn='${isPAETurn}' data-mr-id="${mr.mr_id}" type="button">CHECK</button>` : ""}
               ${isApprover ? ` <button class="btn btn-success btn_Approve_MR" data-is-pae-turn='${isPAETurn}'  data-mr-id="${mr.mr_id}" type="button">APPROVE</button>` : ""}
                <button class="btn btn-danger btn_reject_MR" type="button" data-mr-id="${mr.mr_id}" >REJECT</button>
              </div>
            </div>
            
          </div>
            
      </from>
    
    `
    let OtherDeptCheck = `
      <form action="" method="post" id="form_Other_dept_Check_MR" class="checkMR">
        <div class="responseTitle">${statusRes?.data[0].dept_res} Check</div>
        <div class="row">
            <div class='col-10'>
              <div class="row g-2">
                ${isChecker && isPLANTurn ? `
                   <div class="nice-form-group  col-md-12">
                      <label>Budget Code</label>
                      <select class='selectjs' name='budget_code'>
                        ${this.createOptionElement(budgetCodeList?.data, ['budget_code', "segment", 'budget_name'], "budget_code", mr.type_id)}
                      </select>
                    </div>
                  
                  ` : ""}
                
                <div class="nice-form-group  col-md-12">
                  <label>Comment</label>
                  <textarea type='text' name='check_comment' placeholder=""></textarea>
                </div>
              </div>
            </div>
            <div class='col-2'>
               <div class="d-grid gap-2 mt-4">
               
                ${isChecker ? ` <button class="btn btn-primary btn_check_MR" data-is-pae-turn='${isPAETurn}' data-mr-id="${mr.mr_id}" type="button">CHECK</button>` : ""}
                ${isApprover ? ` <button class="btn btn-success btn_Approve_MR" data-is-pae-turn='${isPAETurn}' data-mr-id="${mr.mr_id}" type="button">APPROVE</button>` : ""}
                <button class="btn btn-danger btn_reject_MR" type="button" data-mr-id="${mr.mr_id}" >REJECT</button>
              </div>
            </div>
            
          </div>
            
      </from>
    `
    //1. Loại bỏ modal ra khỏi DOM nếu có
    $(document).find('#showModalMRDetail').remove()
    $('.content').append(`
        <div class="modal fade" id="showModalMRDetail" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-xl">
            <div class="modal-content">
              <div class="modal-header bg-info">
                <h1 class="modal-title fs-5" id="exampleModalLabel">MRNo: <span title='click to download MR form' class='cursor text-primary download-mr' data-mr-id = '${mr.mr_id}'>${mr.mr_no}</span> </h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <form action="" method="post" id="form_mr_information">
                  <div class="row g-2">
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>MR Type</label>
                      <select ${isAdmin ? "" : "disabled"} name='mr_type_id'>
                          ${this.createOptionElement(mrTypeCategory?.data, ["type"], "mr_type_id", mr.type_id)}
                      </select>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Location</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='location' value='${mr.location}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>PDD</label>
                      <input ${isAdmin || (isPAETurn && (isChecker || isApprover)) ? "" : "disabled"} type='date' name='pdd' value='${moment(mr.pdd).format('YYYY-MM-DD')}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>G/L Account</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='gl_account' value='${mr.gl_account}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Budget Code</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='budget_code' value='${mr.budget_code}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Asset No</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='asset_number' value='${mr.asset_number}' />
                    </div>
                    
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Part No</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='part_no' value='${mr.part_no}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Part Name</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='part_name' value='${mr.part_name}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Model</label>
                      <select ${isAdmin || (isPAETurn && (isChecker || isApprover)) ? "" : "disabled"} name='model_id' class='${isAdmin || (isPAETurn && (isChecker || isApprover)) ? "selectjs" : ""}'>
                        ${this.createOptionElement(modelList?.data, ["model_name"], "model_id", mr.model_id)}
                      </select>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Dim</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='clasification' value='${mr.clasification}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>CAV Qty</label>
                      <input ${isAdmin || (isPAETurn && (isChecker || isApprover)) ? "" : "disabled"} type='text' name='cav_qty' value='${mr.cav_qty}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>MC Size</label>
                      <input ${isAdmin || (isPAETurn && (isChecker || isApprover)) ? "" : "disabled"} type='text' name='mc_size' value='${mr.mc_size}' />
                    </div>
                    
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Die_ID</label>
                      <input disabled type='text' name='die_no' value='${mr.die_no}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Supplier</label>
                      <select ${isAdmin || (isPAETurn && (isChecker || isApprover)) ? "" : "disabled"} name='supplier_id' class='${isAdmin || (isPAETurn && (isChecker || isApprover)) ? "selectjs" : ""}'>
                        ${this.createOptionElement(suppliers?.data, ["supplier_code", 'supplier_name'], "supplier_id", mr.supplier_id)}
                      </select>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Order To</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='order_to' value='${mr.order_to}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Draw His</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='draw_his' value='${mr.draw_his}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>ECN No</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='ecn_no' value='${mr.ecn_no}' />
                    </div> 
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>DE-Die</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='is_de_die' value='${mr.is_de_die === '' ? "-" : mr.is_de_die ? "Y" : "N"}' />
                    </div> 
                    <div class="nice-form-group col-sm-12 col-md-4">
                      <label>Reason</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='reason' value='${mr.reason}' />
                    </div>   
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Estimate Cost</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='estimate_cost' value='${mr.estimate_cost}' />
                    </div>  
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Approved Cost</label>
                      <input disabled type='text' name='app_cost' value='${mr.app_cost}' />
                    </div>  
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Unit</label>
                      <input disabled type='text' name='unit' value='${mr.unit}' />
                    </div> 
                    
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Component</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='no_of_die_component' value='${mr.no_of_die_component}' />
                    </div> 
                  </div>
                  <div class="row">
                    <div class="col-md-6 mt-1">
                      <div class="row g-2">
                        <div class="nice-form-group col-sm-12 col-md-4">
                          <label>Sucess Die ID</label>
                          <input ${isAdmin ? "" : "disabled"} type='text' name='sucess_die_id' value='${mr.sucess_die_id}' />
                        </div> 
                        <div class="nice-form-group col-sm-12 col-md-4">
                          <label>Sucess Part No</label>
                          <input ${isAdmin ? "" : "disabled"} type='text' name='sucess_part_no' value='${mr.sucess_part_no}' />
                        </div> 
                        <div class="nice-form-group col-sm-12 col-md-4">
                          <label>Disposed Die ID</label>
                          <input ${isAdmin ? "" : "disabled"} type='text' name='dispose_die_id' value='${mr.dispose_die_id}' />
                        </div>
                        <div class="nice-form-group col-sm-12 col-md-12">
                          <label>Common parts</label>
                          <input ${isAdmin || (isPAETurn && (isChecker || isApprover)) ? "" : "disabled"} type='text' name='common_part' value='${mr.common_part}' title='separate by [,]' placeholder="RC5-1234-000,RC53456-000,...." />
                        </div>
                        <div class="nice-form-group col-sm-12 col-md-12">
                          <label>Family parts</label>
                          <input ${isAdmin || (isPAETurn && (isChecker || isApprover)) ? "" : "disabled"} type='text' name='family_part' value='${mr.family_part}' title='separate by [,]' placeholder="RC5-1234-000,RC53456-000,...." />
                        </div>
                      </div>
                    </div>
                      <div class="col-md-6">
                        <div class="nice-form-group">
                          <label>Remark</label>
                          <textarea ${isAdmin ? "" : "disabled"}  rows="5" name='note'>${mr.note}</textarea>
                        </div> 
                        <div>
                          Attachments/ References
                        </div>
                        <span>
                          ${mr.pur_attach ? `[<span title="click to download" class='cursor text-primary download-attach' data-att-path="${mr.pur_attach}">PUR Attach</span>]` : ""}
                        </span>
                        <span>
                          ${listTPIattach ? listTPIattach : ""}
                        </span>
                      </div>
                    </div>
                 
                </form>
                <table class="table table-sm table-bordered border-primary text-center mt-1" style="font-size:0.75rem">
                  <thead>
                    <tr>
                      <th colspan="8"> PROGRESS</th>
                    </tr>
                    <tr>
                      <th colspan="2" width="25%">Requested</th>
                      <th colspan="2" width="25%">${mr.belong.includes("CRG") ? "CRG" : mr.belong.includes("LBP") ? "PAE" : "PE"}</th>
                      <th colspan="2" width="25%">PLAN</th>
                      <th colspan="2" width="25%">PUR</th>
                    </tr>
                  <thead>
                  <tbody class="text-left">
                      <tr>
                        <td>Issued/Requested</td>
                        <td>${mr.request_by}</td>
                        <td>Checked</td>
                        <td>${mr.pae_check_by}</td>
                        <td>Checked</td>
                        <td>${mr.plan_check_by}</td>
                         <td>Checked</td>
                        <td>${mr.pur_check_by}</td>
                      </tr>
                      <tr>
                        <td>Date</td>
                        <td> ${mr.request_date ? moment(mr.request_date).format("MM/DD/YYYY") : ""}</td>
                        <td>Date</td>
                        <td> ${mr.pae_check_date ? moment(mr.pae_check_date).format("MM/DD/YYYY") : ""}</td>
                        <td>Date</td>
                        <td> ${mr.plan_check_date ? moment(mr.plan_check_date).format("MM/DD/YYYY") : ""}</td>
                        <td>Date</td>
                        <td> ${mr.pur_check_date ? moment(mr.pur_check_date).format("MM/DD/YYYY") : ""}</td>
                      </tr>
                       <tr>
                        <td></td>
                        <td></td>
                        <td>Approved</td>
                        <td>${mr.pae_app_by}</td>
                        <td>Approved</td>
                        <td>${mr.plan_app_by}</td>
                         <td>Approved</td>
                        <td>${mr.pur_app_by}</td>
                      </tr>
                       <tr>
                        <td></td>
                        <td></td>
                        <td>Date</td>
                        <td> ${mr.pae_check_date ? moment(mr.pae_app_date).format("MM/DD/YYYY") : ""}</td>
                        <td>Date</td>
                        <td> ${mr.plan_check_date ? moment(mr.plan_app_date).format("MM/DD/YYYY") : ""}</td>
                         <td>Date</td>
                        <td> ${mr.pur_check_date ? moment(mr.pur_app_date).format("MM/DD/YYYY") : ""}</td>
                      </tr>
                  </tbody>
                </table>
                ${isShowPermit ? isPAETurn ? permitContentForPAE : OtherDeptCheck : ""}
              </div>
            </div>
          </div>
        </div>
    
    `)



    const modalMassage = new bootstrap.Modal('#showModalMRDetail', {
      keyboard: false
    })
    modalMassage.show()
    selectjs()
  }

  async renderModalPODetail(po_id: number) {
    let data = await this.APIservices.getPOById(po_id).toPromise();
    let po: any = data?.data[0];

    //1. Loại bỏ modal ra khỏi DOM nếu có
    $(document).find('#showModalPODetail').remove()

    let newPO = `
      <div class="modal-dialog modal-xl">
        <div class="modal-content">
          <div class="modal-header bg-info">
            <h1 class="modal-title fs-5" id="exampleModalLabel">REQUEST NEW ISSUE PO No: <span  class='cursor text-primary' data-po-id = '${po.po_issue_no}'>${po.po_issue_no}</span> </h1>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
              <div class="modal-body">
                <form action="" method="post" id="form_mr_information">
                  <div class="row g-2">
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Temporary PO</label>
                      <input disabled  type='text' name='temp_po' value='${po.temp_po == true ? "Y" : "N"}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>MR No</label>
                      <span title='click to download MR form' class='cursor text-primary download-mr' data-mr-id = '${po.mr_id}'>${po.mr_no}</span> 
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Vendor Code</label>
                      <input disabled  type='text' name='supplier_code' value='${po.supplier_code}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Vendor Name</label>
                      <input disabled  type='text' name='supplier_name' value='${po.supplier_name}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Order To</label>
                      <input disabled  type='text' name='order_to' value='${po.order_to}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Die ID</label>
                      <input disabled  type='text' name='die_no' value='${po.die_no}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Part No</label>
                      <input disabled  type='text' name='part_no' value='${po.part_no}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Part Name</label>
                      <input disabled  type='text' name='part_name' value='${po.part_name}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Delivery Key</label>
                      <input disabled  type='text' name='cancel_delivery_key' value='${po.status.includes('cancel') ? po.cancel_delivery_key : (po.status.includes('change') ? po.change_delivery_key : '')}' />
                    </div>
                     <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Estimate Cost</label>
                      <input disabled  type='text' name='estimate_cost' value='${po.estimate_cost}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Price</label>
                      <input disabled  type='text' name='price' value='${po.price}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>PO Date</label>
                      <input disabled  type='text' name='podate' value='${po.podate}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Dim</label>
                      <input disabled  type='text' name='clasification' value='${po.clasification}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>PR</label>
                      <input disabled  type='text' name='pr' value='${po.pr}' />
                    </div>
                     <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Drawing His</label>
                      <input disabled  type='text' name='draw_his' value='${po.draw_his}' />
                    </div>
                     <div class="nice-form-group col-sm-12 col-md-2">
                      <label>ECN No</label>
                      <input disabled  type='text' name='ecn_no' value='${po.ecn_no}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Cavity No</label>
                      <input disabled  type='text' name='cav_qty' value='${po.cav_qty}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Delevery Date</label>
                      <input disabled  type='text' name='delivery_date' value='${moment( po.delivery_date).format("YYYY/MM/DD")}' />
                    </div>
                     <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Delevery Location</label>
                      <input disabled  type='text' name='delivery_location' value='${po.delivery_location}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Warranty Shot</label>
                      <input disabled  type='text' name='warranty_shot' value='${po.warranty_shot}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Trade Condition P Name</label>
                      <input disabled  type='text' name='trade_condition_p_name' value='${po.trade_condition_p_name}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Product Abbr Name</label>
                      <input disabled  type='text' name='model_name' value='${po.model_name}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Use Block Code</label>
                      <input disabled  type='text' name='use_block_code' value='${po.use_block_code}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Transport Method</label>
                      <input disabled  type='text' name='transport_method' value='${po.transport_method}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Vendor Fctry</label>
                      <input disabled  type='text' name='vendor_fctry' value='${po.vendor_fctry}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Register Rate Table By Part</label>
                      <input disabled  type='text' name='need_register_rate_table_by_part' value='${po.need_register_rate_table_by_part}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Order Qty</label>
                      <input disabled  type='text' name='order_qty' value='${po.order_qty}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Item Category</label>
                      <input disabled  type='text' name='item_category' value='${po.item_category}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Container Loading Code</label>
                      <input disabled  type='text' name='container_loading_code' value='${po.container_loading_code}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Buyer</label>
                      <input disabled  type='text' name='buyercode' value='${po.buyercode}' />
                    </div>
                    
                  </div>
                  <div class="row">
                    <div class="col-md-2 mt-1">
                      <div class="row g-2">
                        <div class="nice-form-group col-sm-12 col-md-12">
                          <label>Procudure</label>
                          <input disabled  type='text' name='procedure_no' value='${po.procedure_no}' />
                        </div> 
                         <div class="nice-form-group col-sm-12 col-md-12">
                          <label>Attachment</label>
                          <input disabled  type='text' name='attach_no_new' value='${po.attach_no_new}' />
                        </div> 
                        
                      </div>
                    </div>
                    <div class="col-md-4">
                        <div class="nice-form-group">
                          <label>Reason for PO</label>
                          <textarea disabled  rows="5" name='note'>${po.reason_issue_po}</textarea>
                        </div> 
                    </div>
                    <div class="col-md-6">
                        <div class="nice-form-group">
                          <label>Remark</label>
                          <textarea disabled  rows="5" name='remark'>${po.remark}</textarea>
                        </div> 
                      </div>
                    </div>
                 
                </form>
                <table class="table table-sm table-bordered border-primary text-center mt-1" style="font-size:0.75rem">
                  <thead>
                    <tr>
                      <th colspan="6"> PROGRESS</th>
                    </tr>
                    <tr>
                      <th width="16.7%">Requested by</th>
                      <th width="16.7%">PUR Approved By</th>
                      <th width="16.7%">PUC Input NPIS By</th>
                      <th width="16.7%">PUC Double Check By</th>
                      <th width="16.7%">PUS Input By</th>
                      <th width="16.7%">PUS Approve By</th>
                    </tr>
                  <thead>
                  <tbody class="">
                     <tr>
                         <td>${po.issue_by} <br/> ${po.issue_date ? moment(po.issue_date).format("MM/DD/YYYY") : ""}</td>
                         <td>${po.gm_pur_app_by ? po.gm_pur_app_by : po.pur_app_by} <br/> ${po.gm_pur_app_by ? moment(po.gm_pur_app_date).format("MM/DD/YYYY") : (po.pur_app_date ? moment(po.pur_app_date).format("MM/DD/YYYY") : "")}</td>
                         <td>${po.puc_check_by} <br/> ${po.puc_check_date ? moment(po.puc_check_date).format("MM/DD/YYYY") : ""}</td>
                         <td>${po.puc_double_check_by} <br/> ${po.puc_double_check_date ? moment(po.puc_double_check_date).format("MM/DD/YYYY") : ""}</td>
                         <td>${po.pus_check_by} <br/> ${po.pus_check_date ? moment(po.pus_check_date).format("MM/DD/YYYY") : ""}</td>
                         <td>${po.pus_app_by} <br/> ${po.pus_app_date ? moment(po.pus_app_date).format("MM/DD/YYYY") : ""}</td>
                     </tr>
                  </tbody>
                </table>
              </div>
    
        </div>
      </div>
    
    `

    let ChangePO = `
      <div class="modal-dialog modal-xl">
      <div class="modal-content">
        <div class="modal-header bg-info">
          <h1 class="modal-title fs-5" id="exampleModalLabel">REQUEST CHANGE PO No: <span  class='cursor text-primary' data-po-id = '${po.po_issue_no}'>${po.po_issue_no}</span> </h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
          
        <div class="modal-body" id="form_mr_information">
            <div class="row g-2">
              <div class="nice-form-group col-sm-12 col-md-2">
                <label>Part No</label>
                <input disabled  type='text'  value='${po.part_no}' />
              </div>
              <div class="nice-form-group col-sm-12 col-md-2">
                <label>Dim</label>
                <input disabled  type='text'  value='${po.clasification}' />
              </div>
              <div class="nice-form-group col-sm-12 col-md-2">
                <label>Vendor</label>
                <input disabled  type='text'  value='${po.supplier_code}' />
              </div>
             
              <div class="nice-form-group col-sm-12 col-md-2">
                <label>Buyer</label>
                <input disabled  type='text'  value='${po.buyercode}' />
              </div>
              <div class="nice-form-group col-sm-12 col-md-2">
                <label>Procudure </label>
                <input disabled  type='text'  value='${po.procedure_no}' />
              </div>
              <div class="nice-form-group col-sm-12 col-md-2">
                <label>Attachment No </label>
                <input disabled  type='text'  value='${po.attach_no_change}' />
              </div>
               <div class="nice-form-group col-sm-12 col-md-2">
                <label>Delivery Key No</label>
                <input disabled  type='text'  value='${po.change_delivery_key}' />
              </div>
              <div class="nice-form-group col-sm-12 col-md-10">
                <label>Change Reason </label>
                <input disabled  type='text'  value='${po.change_reason}' />
              </div>
              <div class="nice-form-group col-sm-12 col-md-12">
                <label>Remark</label>
                <textarea disabled  name='remark'>${po.remark}</textarea>
              </div> 
            </div>
            <table class="table table-sm table-bordered border-secondary text-center mt-1" style="font-size:0.75rem">
              <thead>
                <tr>
                  <th colspan="6"> Request Change</th>
                </tr>
                <tr>
                  <th width="33%">Request change</th>
                  <th width="33%">Current</th>
                  <th width="33%">Change To</th>
                </tr>
              <thead>
              <tbody class="">
                  <tr>
                      <td>Delivery Date</td>
                      <td >${po.delivery_date ? moment(po.delivery_date).format("MM/DD/YYYY") : ""}</td>
                      <td class="text-success">${po.change_delivery_date ? moment(po.change_delivery_date).format("MM/DD/YYYY") : ""}</td>
                  </tr>
                  <tr>
                      <td>Order Qty</td>
                      <td>${po.order_qty}</td>
                      <td></td>
                  </tr>
                  <tr>
                      <td>Block Code</td>
                      <td>${po.use_block_code}</td>
                      <td></td>
                  </tr>
                  <tr>
                      <td>Delivery Location</td>
                      <td>${po.delivery_location}</td>
                      <td></td>
                  </tr>
                  <tr>
                      <td>Drawing</td>
                      <td>${po.draw_his}</td>
                      <td></td>
                  </tr>
              </tbody>
            </table>
            <hr>
          <table class="table table-sm table-bordered border-primary text-center mt-1" style="font-size:0.75rem">
              <thead>
                <tr>
                  <th colspan="6"> PROGRESS</th>
                </tr>
                <tr>
                  <th width="25%">Requested by</th>
                  <th width="25%">PUR Approved By</th>
                  <th width="25%">PUC Input NPIS By</th>
                  <th width="25%">PUC Double Check By</th>
                </tr>
              <thead>
              <tbody class="">
                  <tr>
                      <td>${po.change_request_by} <br/> ${po.change_request_date ? moment(po.change_request_date).format("MM/DD/YYYY") : ""}</td>
                      <td>${po.change_pur_app_by} <br/> ${po.change_pur_app_date ? moment(po.change_pur_app_date).format("MM/DD/YYYY") : ''}</td>
                      <td>${po.change_puc_check_by} <br/> ${po.change_puc_check_date ? moment(po.change_puc_check_date).format("MM/DD/YYYY") : ""}</td>
                      <td>${po.change_puc_double_check_by} <br/> ${po.change_puc_double_check_date ? moment(po.change_puc_double_check_date).format("MM/DD/YYYY") : ""}</td>
                  </tr>
              </tbody>
            </table>
        </div>
    
    
      </div>
      </div>
    
    `

    let cancelPO = `
    <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header bg-info">
        <h1 class="modal-title fs-5" id="exampleModalLabel">REQUEST CANCEL PO No: <span  class='cursor text-primary' data-po-id = '${po.po_issue_no}'>${po.po_issue_no}</span> </h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
        
      <div class="modal-body" id="form_mr_information">
          <div class="row g-2">
            <div class="nice-form-group col-sm-12 col-md-2">
              <label>Part No</label>
              <input disabled  type='text'  value='${po.part_no}' />
            </div>
            <div class="nice-form-group col-sm-12 col-md-2">
              <label>Dim</label>
              <input disabled  type='text'  value='${po.clasification}' />
            </div>
            <div class="nice-form-group col-sm-12 col-md-2">
              <label>Vendor</label>
              <input disabled  type='text'  value='${po.supplier_code}' />
            </div>
            <div class="nice-form-group col-sm-12 col-md-2">
              <label>Delivery Key No</label>
              <input disabled  type='text'  value='${po.cancel_delivery_key}' />
            </div>
            <div class="nice-form-group col-sm-12 col-md-2">
              <label>Buyer</label>
              <input disabled  type='text'  value='${po.buyercode}' />
            </div>
            <div class="nice-form-group col-sm-12 col-md-2">
              <label>Procudure </label>
              <input disabled  type='text'  value='${po.procedure_no}' />
            </div>
            <div class="nice-form-group col-sm-12 col-md-2">
              <label>Attachment No </label>
              <input disabled  type='text'  value='${po.attach_no_cancel}' />
            </div>
            <div class="nice-form-group col-sm-12 col-md-10">
              <label>Cancel Reason </label>
              <input disabled  type='text'  value='${po.cancel_reason}' />
            </div>
            <div class="nice-form-group col-sm-12 col-md-12">
                <label>Remark</label>
                <textarea disabled  name='remark'>${po.remark}</textarea>
              </div> 
          </div>
          <table class="table table-sm table-bordered border-secondary text-center mt-1" style="font-size:0.75rem">
            <thead>
              <tr>
                <th colspan="6"> Information</th>
              </tr>
            <thead>
            <tbody class="">
                <tr>
                    <td>Delivery Date</td>
                    <td class="text-success">${po.pus_app_date ? moment(po.delivery_date).format("MM/DD/YYYY") : ""}</td>
                </tr>
                <tr>
                    <td>Order Qty</td>
                    <td>${po.order_qty}</td>
                </tr>
                <tr>
                    <td>Block Code</td>
                    <td>${po.use_block_code}</td>
                </tr>
                <tr>
                    <td>Delivery Location</td>
                    <td>${po.delivery_location}</td>
                </tr>
                <tr>
                    <td>Drawing</td>
                    <td>${po.draw_his}</td>
                </tr>
            </tbody>
          </table>
          <hr>
        <table class="table table-sm table-bordered border-primary text-center mt-1" style="font-size:0.75rem">
            <thead>
              <tr>
                <th colspan="6"> PROGRESS</th>
              </tr>
              <tr>
                <th width="25%">Requested by</th>
                <th width="25%">PUR Approved By</th>
                <th width="25%">PUC Input NPIS By</th>
                <th width="25%">PUC Double Check By</th>
              </tr>
            <thead>
            <tbody class="">
                <tr>
                    <td>${po.cancel_request_by} <br/> ${po.cancel_request_date ? moment(po.cancel_request_date).format("MM/DD/YYYY") : ""}</td>
                    <td>${po.cancel_pur_app_by} <br/> ${po.cancel_pur_app_date ? moment(po.cancel_pur_app_date).format("MM/DD/YYYY") : ''}</td>
                    <td>${po.cancel_puc_check_by} <br/> ${po.cancel_puc_check_date ? moment(po.cancel_puc_check_date).format("MM/DD/YYYY") : ""}</td>
                    <td>${po.cancel_puc_double_check_by} <br/> ${po.cancel_puc_double_check_date ? moment(po.cancel_puc_double_check_date).format("MM/DD/YYYY") : ""}</td>
                </tr>
            </tbody>
          </table>
      </div>
  
  
    </div>
    </div>
  
  `
    let content = po.status.toUpperCase().includes('CANCEL') ? cancelPO : (po.status.toUpperCase().includes('CHANGE') ? ChangePO : newPO)
    $('.content').append(
      `
        <div class="modal fade" id="showModalPODetail" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              ${content}
        </div>

      `
    )


    const modalMassage = new bootstrap.Modal('#showModalPODetail', {
      keyboard: true
    })
    modalMassage.show()
    selectjs()
  }


  selectAll(checkboxName: string, isSelectAll: boolean) {
    if (isSelectAll) {
      $(`input[name=${checkboxName}]:checkbox`).each(function (this: HTMLInputElement) {
        $(this).prop('checked', true);
      });
    } else {
      $(`input[name=${checkboxName}]:checkbox`).each(function (this: HTMLInputElement) {
        $(this).prop('checked', false);
      });
    }
  };

  getSelectedID(checkboxName: string) {
    var selectedIDs: any = [];
    $(`input[name=${checkboxName}]:checkbox:checked`).each(function (this: HTMLElement) {
      selectedIDs.push($(this).val());
    });
    return selectedIDs
  }








}