import { AfterViewInit, Component,  ViewChild } from '@angular/core';
import { Injectable } from '@angular/core';
import { AppAPIService } from '../API-Services/app-api.service';
import { MrComponent } from '../pages/mr/mr.component';
const apexChart = import('apexcharts');
@Injectable({
  providedIn: 'root'
})
export class ChartApexService  {
 
  constructor(
    private APIservices: AppAPIService,
    
  ) { }

  

  // options = {
  //   series : [],
  //   annotations: {
  //     points: [{
  //       x: 'Oranges',
  //       seriesIndex: 0,
  //       label: {
  //         borderColor: '#775DD0',
  //         offsetY: 0,
  //         style: {
  //           color: '#fff',
  //           background: '#775DD0',
  //         },
  //         text: 'Bananas are good',
  //       }
  //     }]
  //   },
  //   chart: {
  //     height: 200,
  //     type: 'bar',
  //     events: { dataPointSelection: async (event: any, chartContext: any, opts: any) => {
  //       let index = opts.dataPointIndex
  //       let data = await opts.w.config.xaxis.categories[index]
  //       let qty = opts.w.config.series[0].data[index]
  //       return data
  //     }},
  //   },
  //   plotOptions: {
  //     bar: {
  //       columnWidth: '60%',
  //     }
  //   },
  //   dataLabels: {
  //     enabled: true,
  //     textAnchor: 'middle',
  //     offsetY: 0,
  //     style: {
  //       fontFamily: 'Helvetica, Arial, sans-serif',
  //       fontWeight: 'bold',
  //       colors: ['#000']
  //     }
  //   },
  //   stroke: {
  //     width: 0
  //   },
  //   grid: {
  //     row: {
  //       colors: ['#fff', '#f2f2f2']
  //     }
  //   },
  //   xaxis: {
  //     labels: {
  //       rotate: -25
  //     },
  //     categories: []
  //   },
  //   yaxis: {
  //     title: {
  //       text: 'MR',
  //     },
  //   },
  //   fill: {
  //     type: 'gradient',
  //     gradient: {
  //       shade: 'light',
  //       type: "horizontal",
  //       shadeIntensity: 0.25,
  //       gradientToColors: undefined,
  //       inverseColors: true,
  //       opacityFrom: 0.85,
  //       opacityTo: 0.85,
  //       stops: [50, 0, 100]
  //     },
  //   },

  // };


  // async renderChartMR() {
  //   let mrPending = await this.APIservices.getSumarizeMRPending().toPromise()
    
  //   let data:any = [];
  //   let category :any = []
  //   mrPending?.data.forEach((e:any) => {
  //     data.push(e.qty)
  //     category.push(e.status)
  //   });
  //   console.log(data)
  //   let series : any = [{
  //     name: 'MR',
  //     data: data
  //   }]
  //   //let category:any = ['W-PAE', 'W-PE1', 'W-PUR', 'W-ddd']
  //   var options = this.options
  //   options.series = series,
  //   options.xaxis.categories = category
  //   var chart = new ApexCharts(document.querySelector("#render_chart_box"), options);
  //   chart.render();
  // }

}
