﻿namespace DMSQV_API.Models
{
    public class CheckUserLogin
    {
        public bool status {  get; set; }
        public List<user>? dataUsers {  get; set; }
    }
}
