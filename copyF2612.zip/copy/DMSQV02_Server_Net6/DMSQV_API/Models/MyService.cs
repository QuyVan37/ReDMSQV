﻿namespace DMSQV_API.Models
{
    public class MyService
    {
        public readonly IWebHostEnvironment _env;

        public MyService(IWebHostEnvironment env)
        {
            _env = env;
        }

        public string GetFullPathToFile(string relativePath)
        {
            return Path.Combine(_env.WebRootPath, relativePath);
        }
    }
}
