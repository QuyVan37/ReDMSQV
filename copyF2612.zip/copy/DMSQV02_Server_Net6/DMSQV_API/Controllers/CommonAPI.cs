﻿using DMSQV_API.Data;
using Microsoft.AspNetCore.Mvc;

namespace DMSQV_API.Controllers
{
    public class CommonAPI : Controller
    {
        DBConnector db = new DBConnector();
        public JsonResult api_DMSGradeCategory()
        {
            var result = db.getDMSGradeCatergory();
            return Json(result);
        }

        public JsonResult api_DMSRoleCategory()
        {
            var result = db.getDMSRoleCatergory();
            return Json(result);
        }

        public JsonResult api_GetListDept()
        {
            var result = db.getListDept();
            return Json(result);
        }

        public JsonResult api_GetMRTypeCategory()
        {
            var result = db.getMRTypeCategory();
            return Json(result);
        }

        public JsonResult api_GetSupplierList()
        {
            var result = db.getSupplierList();
            return Json(result);
        }

        public JsonResult api_GetProcessCodeCategory()
        {
            var result = db.getProcessCodeCategỏy();
            return Json(result);
        }

        public JsonResult api_GetModelList()
        {
            var result = db.getModelList();
            return Json(result);
        }

        public JsonResult api_GetBudgetCodeList()
        {
            var result = db.getBudgetCodeList();
            return Json(result);
        }

        public JsonResult api_getTPIRelatedDieNo(string dieNo)
        {
            var result = db.getTPIRelatedDieNo(dieNo);
            return Json(result);
        }

        public JsonResult api_getDFMRelatedDieNo(string dieNo)
        {
            var result = db.getDFMRelatedDieNo(dieNo);
            return Json(result);
        }

        public JsonResult api_checkDieExist(string dieNo)
        {
            bool isExist = db.isExistDie(dieNo).data.Count() > 0;
            var result = new
            {
                status = isExist,
                msg = isExist == false ? $"Die {dieNo} is not yet issue PO or Disposed or Cancel or Not Exist" : ""
            };
            return Json(result);
        }

    }
}
