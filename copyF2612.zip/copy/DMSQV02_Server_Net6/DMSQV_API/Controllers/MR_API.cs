﻿using DMSQV_API.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Npgsql.PostgresTypes;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.Net.WebSockets;
using static DMSQV_API.Controllers.CommonFunction;
using static DMSQV_API.Data.DBConnector;

namespace DMSQV_API.Controllers
{
    public class MR_API : Controller
    {
        DBConnector db = new DBConnector();
        Authen authen = new Authen();
        CommonFunction commonFunction = new CommonFunction();
        WorkInExcel workInExcel = new WorkInExcel();
        public int[] flowProgressLBP = { 2, 3, 4, 5, 6, 7, 8, 13, 14 };
        public int[] flowProgressCRG = { 16, 4, 5, 6, 7, 8, 13, 14 };
        public int[] flowProgressINHOUSE = { 2, 3, 4, 5, 8, 13, 14 };
        public int[] flowProgressPE1 = { 15, 4, 5, 6, 7, 8, 13, 14 };
        public JsonResult api_getMRList(string search, string? supplier_id, string? mr_type_id, int? page = 1, int? pageSize = 50)
        {
            search = search?.Trim();
            bool status = false;
            string msg = "";
            var islogin = authen.isLoginAndReturnUserProfile(HttpContext);

            dataReturn data = new dataReturn();
            if (islogin.status)
            {
                data = db.getMRList(search, supplier_id, mr_type_id, page, pageSize);
                status = true;
            }
            else
            {
                msg = "Please login!";
                status = false;
            }


        exit:
            var output = new
            {
                status = status,
                msg = msg,
                recordsTotal = data.totalCount,
                recordsFiltered = data.totalCount,
                page = page,
                pageSize = pageSize,
                Data = data.data,
            };
            return Json(output);
        }

        public JsonResult api_getSumarizeMRPending()
        {
            var result = db.getSumarizeMRPending();
            return Json(result);
        }

        public JsonResult api_isExistMR(string part_no, string dim, string his)
        {
            // return true if exist other else
            bool status = false;
            string msg = "";
            var data = db.isExistMR(part_no, dim, his).data;
            if (data.Count() == 0)
            {
                status = false;
                msg = "This MR not issue yet!";
            }
            else
            {
                status = true;
                msg = $"This MR was issued by {data[0]["request_by"].ToString()} on {data[0]["request_date"]} [{data[0]["mr_no"]}]";
            }
            var result = new
            {
                status = status,
                msg = msg
            };
            return Json(result);
        }

        public JsonResult api_getDieInforToIssueMR(string dieNo)
        {
            bool status = false;
            string msg = "";
            string sql = $"SELECT common_part_with, family_die_with, model_id,supplier_id, mc_size, cav_quantity, pxno_of_component, die_maker, die_make_location FROM dies " +
                $"WHERE dieno = '{dieNo}'";
            var data = db.ExcuteQueryAndGetData(sql);
            if (data.data.Count() > 0) status = true;
            var output = new
            {
                status = status,
                msg = "",
                data = data
            };
            return Json(output);
        }

        public jsonResult api_issueMR(string belong, int mr_type_id, string tpi_id, string dfm_id, string part_no, string dim, string die_no, string his, string ecn_no
                                     , string part_name, string process_code_id, string model_id, string supplier_id, string order_to, string pdd
                                     , string estmate_cost, string unit, string mc_size, string cav_qty, string reason, string success_part_no
                                     , string success_die_no, string dispose_die_no, string common_part, string family_part, string remark, IFormFile? pur_att_file)
        {
            bool status = false;
            string msg = "";
            var userLogin = authen.isLoginAndReturnUserProfile(HttpContext);
            if (!userLogin.status)
            {
                status = false;
                msg = "Please login in!";
                goto exit;
            }

            // kiem tra đầu vào
            part_no = part_no?.Replace(" ", "").Trim().ToUpper();
            dim = dim?.Replace(" ", "").Trim().ToUpper();
            die_no = die_no?.Replace(" ", "").Trim().ToUpper();
            if (part_no?.Length != 12 || dim?.Length != 3 || die_no?.Length != 20)
            {
                status = false;
                msg = "Part No, Dim, Die ID must not has space charactor and enough length!";
                goto exit;
            }

            bool isChecker = userLogin.dataUsers.Any(e => new[] { "CRG", "DMT", "PUR" }.Contains(e.dept_name) && new[] { "QV" }.Contains(e.factory) && new[] { 3, 4 }.Contains(e.mr_role_id));
            if (isChecker)
            {
                // get Status ID
                int nextStatusID = new[] { "LBP", "INHOUSE" }.Contains(belong) ? flowProgressLBP[0] : (new[] { "CRG" }.Contains(belong) ? flowProgressCRG[0] : flowProgressPE1[0]);

                // Kiem tra MR co thuoc Modify va va co selct TPI/DMF ko?
                bool isNeedTPIorDFM = new[] { 6, 7, 8, 10 }.Contains(mr_type_id);
                bool isTPIorDFMSelected = tpi_id != null || dfm_id != null;
                if (isNeedTPIorDFM == true && isTPIorDFMSelected == false)
                {
                    // NHUNG LAI KO CO TPI HOAC DFM
                    status = false;
                    msg = "Please select TPI/ DFM for reason of this MR!";
                    goto exit;
                }

                // Kiểm tra MR Type is modify thì đã tồn tại die chưa
                if (isNeedTPIorDFM == true)
                {
                    bool isExistDies = db.isExistDie(die_no).data.Count() > 0;
                    if (isExistDies == false)
                    {
                        status = false;
                        msg = $"Die {die_no} is not yet issue PO or Disposed or Cancel or Not Exist";
                        goto exit;
                    }
                }
                //Kiem tra MR exist chua

                var data = db.isExistMR(part_no, dim, his).data;
                if (data.Count() > 0)
                {
                    status = false;
                    msg = $"This MR was issued by {data[0]["request_by"].ToString()} on {data[0]["request_date"]} [{data[0]["mr_no"]}]";
                    goto exit;
                }

                // Supplier 
                string sqlGetSupplierInfo = $"Select * from Suppliers WHERE supplier_id = {supplier_id}";
                var supplier = db.ExcuteQueryAndGetData(sqlGetSupplierInfo).data[0];
                // Model
                string sqlGetModelInfo = $"select * from models where model_id = {model_id}";
                var models = db.ExcuteQueryAndGetData(sqlGetModelInfo).data[0];
                // Genarate MRNo
                string sqlCountMRInYear = $"SELECT count(mr_id) FROM mr WHERE Extract (year from request_date) = {DateTime.Now.Year}";
                string totalMRInYear = (int.Parse(db.ExcuteQueryAndGetData(sqlCountMRInYear).data[0]["count"].ToString()) + 1).ToString();
                string mRNO = $"MR{DateTime.Now.ToString("yyMMdd")}-{totalMRInYear.PadLeft(4, '0')}-00";
                // Genarate ACC information for LBP và CRG
                var ACC = commonFunction.genarateACCInfo(mr_type_id, double.Parse(estmate_cost), unit, belong, models["model_type"].ToString(), supplier["supplier_code"].ToString(), part_no);
                // Exchange cost
                var exchangeValue = commonFunction.ExchangeVNDandJPYUSD(double.Parse(estmate_cost), unit);
                // Tempo PO
                bool isTempo = int.Parse(estmate_cost) == 10 ? true : false;
                // Note
                remark = String.IsNullOrWhiteSpace(remark) ? "" : $"{userLogin.dataUsers[0].user_name}: {remark}";
                dfm_id = String.IsNullOrEmpty(dfm_id) ? "null" : dfm_id;

                // Luu file vat li
                string fullPathPurAtt = commonFunction.savePhysicalFileOnServer(pur_att_file, "\\File\\Attachment\\MR", "MR_PUR_Attachment");
                string sql = $"INSERT INTO mr (phase, mr_no, status_id, tempo_po, belong, type_id, model_id, die_no, part_no, part_name, process_code_id, clasification, reason, supplier_id, order_to,draw_his, ecn_no, mc_size, cav_qty , pdd, estimate_cost, unit, estimate_cost_exchange_usd,exchange_rate,gl_account, asset_number, location, common_part, family_part,note,sucess_die_id, sucess_part_no , dispose_die_id, request_by, request_date, is_Active, no_of_die_component,tpi_id,dfm_id,is_de_die, pur_attach)  " +
                             $"VALUES ('{models["phase"]}', '{mRNO}', '{nextStatusID}' , '{isTempo}', '{belong}', '{mr_type_id}', '{model_id}', '{die_no}', '{part_no}', '{part_name}', '{process_code_id}', '{dim}', '{reason}','{supplier_id}', '{order_to}', '{his}', '{ecn_no}', '{mc_size}','{cav_qty}', '{pdd}', '{estmate_cost}', '{unit}', '{exchangeValue.USD}', '{exchangeValue.rateVNDtoUSD}', '{ACC.G_L}', '{ACC.assetNumber}', '{ACC.location}', '{common_part}', '{family_part}', '{remark}', '{success_die_no}', '{success_part_no}', '{dispose_die_no}', '{userLogin.dataUsers[0].user_name}', '{DateTime.Now}', '{true}', '1', '{tpi_id}', {dfm_id}, '{false}', '{fullPathPurAtt}'); ";

                try
                {
                    db.ExcuteQueryAndGetData(sql);
                    status = true;
                    msg = "Success issue MR!";
                }
                catch
                {
                    status = false;
                    msg = "Eror, Can not save data";
                }
            }
            else
            {
                status = false;
                msg = "You do not has permision";
                goto exit;
            }

        exit:
            jsonResult result = new jsonResult
            {
                status = status,
                msg = msg
            };
            return result;
        }
        public JsonResult api_issueMRByExcel(IFormCollection file)
        {

            string msg = "";
            List<string> listFail = new List<string>();
            int success = 0;
            int fail = 0;
            var userLogin = authen.isLoginAndReturnUserProfile(HttpContext);
            //if (!userLogin.status)
            //{
            //    status = false;
            //    msg = "Please login in!";
            //    goto exit;
            //}
            if (file == null)
            {

                msg = "No file upload!";
                goto exit;
            }
            var data = workInExcel.readListExcelFile(file.Files[0], 2, 4).data;
            foreach (var MR in data)
            {
                string dieNo = "";
                List<string> tpi_ids = new List<string>();
                List<string> dfm_ids = new List<string>();


                string belong = MR["Belong"].ToString();

                string modelName = MR["Model"].ToString();
                string dim = MR["Dim"].ToString().ToUpper().Trim();
                string part_no = MR["PartNo"].ToString();
                string part_name = MR["PartName"].ToString();
                string his = MR["His"].ToString();
                string ecn_no = MR["ECNNo"].ToString();
                string SupplierCode = MR["SupplierCode"].ToString().Trim().ToUpper();
                string order_to = MR["OrderTo"].ToString();
                string cav_qty = MR["CavQty"].ToString();
                string mc_size = MR["MCSize"].ToString();
                string ProcessCode = MR["ProcessCode"].ToString();
                string pdd = MR["PDD"].ToString();
                string reason = MR["Reason"].ToString();
                string estimatecode = MR["EstmateCost"].ToString();
                string unit = MR["Unit"].ToString().Trim().ToUpper();
                string commontPart = MR["CommontPart"].ToString();
                string familyDie = MR["FamilyDie"].ToString();
                string remark = MR["Remark"].ToString();


                // xu li du lieu


                // Model
                int model_id = commonFunction.createModel(modelName);
                if (model_id == 0)
                {
                    listFail.Add($"{part_no} - {dim}: can not add model {modelName}");
                    fail++;
                    goto exitLoop;
                }

                // MR type
                int mr_type_id = commonFunction.genarateMRtypeID(dim);
                if (new int[] { 6, 7, 8, 10 }.Contains(mr_type_id))
                {
                    // reason can TPI
                    var tpiLists = reason.Split(',');


                    if (tpiLists.Length > 0)
                    {
                        foreach (var tpi_no in tpiLists)
                        {

                            string sqlCheckTPINo = $"SELECT d.dieno, tpi_id FROM tpi " +
                                $"INNER JOIN dies d ON d.die_id = tpi.die_id  " +
                                $"WHERE tpi_no='{tpi_no.Trim()}' ";
                            string sqlCheckDFM = $"SELECT d.dieno, dfm_id FROM dsum " +
                                $"INNER JOIN dies d ON d.die_id = dsum.die_id  " +
                                $"WHERE dsum_no='{tpi_no.Trim()}' ";
                            var tpi = db.ExcuteQueryAndGetData(sqlCheckTPINo).data;
                            var dfm = db.ExcuteQueryAndGetData(sqlCheckDFM).data;
                            if (tpi.Count > 0)
                            {
                                tpi_ids.Add(tpi[0]["tpi_id"].ToString());
                                dieNo = tpi[0]["dieno"].ToString();
                            }
                            if (dfm.Count > 0)
                            {
                                dfm_ids.Add(dfm[0]["tpi_id"].ToString());
                                dieNo = dfm[0]["dieno"].ToString();
                            }
                        }
                        if (String.IsNullOrEmpty(dieNo))
                        {
                            listFail.Add($"{part_no} - {dim}: Reason {reason} not contain any TPI No");
                            fail++;
                            goto exitLoop;
                        }
                    }
                    else
                    {
                        listFail.Add($"{part_no} - {dim}: Must have TPINo");
                        fail++;
                        goto exitLoop;
                    }

                }
                else
                {
                    dieNo = $"{part_no}-{dim}-001";
                }


                string sqlGetProcessID = $"SELECT proces_id FROM die_process_code_category  " +
                                         $"WHERE type ILIKE '%{ProcessCode.Trim()}%' ";
                //Process code
                int process_id = 0;
                var process = db.ExcuteQueryAndGetData(sqlGetProcessID).data;
                if (process.Count > 0)
                {
                    process_id = int.Parse(process[0]["proces_id"].ToString());
                }
                if (process_id == 0)
                {
                    listFail.Add($"{part_no} - {dim}: Process code {ProcessCode} is not register in DMS");
                    fail++;
                    goto exitLoop;
                }

                // Supplier
                int supplier_id = 0;
                string sqlGetSupplierID = $"SELECT supplier_id FROM suppliers WHERE supplier_code Ilike '{SupplierCode}'";
                var supplier = db.ExcuteQueryAndGetData(sqlGetSupplierID).data;
                if (supplier.Count > 0)
                {
                    supplier_id = int.Parse(supplier[0]["supplier_id"].ToString());
                }
                if (supplier_id == 0)
                {
                    listFail.Add($"{part_no} - {dim}: Supplier code {SupplierCode} is not register in DMS");
                    fail++;
                    goto exitLoop;
                }

                // PDD
                DateTime newDatePPD;
                bool testDate = DateTime.TryParse(pdd, out newDatePPD);
                if (testDate == false)
                {
                    listFail.Add($"{part_no} - {dim}: PDD {pdd} is not corrent date format!");
                    fail++;
                    goto exitLoop;
                }

                // Estimate code
                double newEstCode = 0;
                bool testDouble = double.TryParse(estimatecode, out newEstCode);
                if (testDouble == false)
                {
                    listFail.Add($"{part_no} - {dim}: Eestimate cost {estimatecode} is not corrent number");
                    fail++;
                    goto exitLoop;
                }

                //MC size
                int newMCsize = 0;
                bool testInt = int.TryParse(mc_size, out newMCsize);
                if (testInt == false)
                {
                    listFail.Add($"{part_no} - {dim}: MC size {mc_size} is not corrent number");
                    fail++;
                    goto exitLoop;
                }

                //Cav qty
                int newCavQty = 0;
                bool testIntCav = int.TryParse(cav_qty, out newCavQty);
                if (testIntCav == false)
                {
                    listFail.Add($"{part_no} - {dim}: Cav qty {mc_size} is not corrent number");
                    fail++;
                    goto exitLoop;
                }
                // Belong
                string newBelong = belong.Contains("CRG") ? "CRG" : (belong.Contains("LBP") ? "LBP" : (belong.Contains("INHOUSE") ? "INHOUSE" : (belong.Contains("OTHER") ? "OTHER" : "")));
                if (String.IsNullOrEmpty(newBelong))
                {
                    listFail.Add($"{part_no} - {dim}: Belong column is not input");
                    fail++;
                    goto exitLoop;
                }

                //His
                string newHis = his.Trim().PadLeft(3, '0');
                if (newHis.Length != 3)
                {
                    listFail.Add($"{part_no} - {dim}: His {his} is need 3 character");
                    fail++;
                    goto exitLoop;
                }

                // ECN No

                if (ecn_no.Length != 13)
                {
                    listFail.Add($"{part_no} - {dim}: ECN No {ecn_no} is need 13 character");
                    fail++;
                    goto exitLoop;
                }

                var issueResult = api_issueMR(newBelong, mr_type_id, String.Join(',', tpi_ids), String.Join(',', dfm_ids), part_no, dim, dieNo, newHis, ecn_no, part_name, process_id.ToString(), model_id.ToString(), supplier_id.ToString(), order_to, newDatePPD.ToString(), newEstCode.ToString(), unit,
                             mc_size, cav_qty, reason, null, null, null, commontPart, familyDie, remark, null);

                if (issueResult.status == false)
                {
                    listFail.Add($"{part_no} - {dim}:Issue fail: {issueResult.msg}");
                    fail++;
                    goto exitLoop;
                }
                else
                {
                    success++;
                }
            exitLoop:
                ViewBag.exitLoop = "Just exit loop ";
            }
        exit:
            var result = new
            {

                fail = fail,
                success = success,
                listFail = listFail,
                msg = msg
            };
            return Json(result);
        }

        public JsonResult api_checkAndApproveAndRejectMR(string mRIDs, string check_comment, string budget_code,
                                                        string check_is_de_die, string check_no_of_die_component, string check_die_maker, string check_make_location,
                                                        string check_die_special, string pdd, string model_id, string cav_qty, string mc_size, string supplier_id,
                                                        string common_part, string family_part, bool? isReject)
        {
            string msg = "";
            bool status = false;
            List<int> success = new List<int>();
            List<string> fail = new List<string>();
            var userLogin = authen.isLoginAndReturnUserProfile(HttpContext);
            if (!userLogin.status)
            {
                status = false;
                msg = "Please login in!";
                goto exit;
            }
            int[] progressConfig = { };
            int nextStatusID = 0;
            string sql = "";
            string[] arrayMRIDs = mRIDs.Split(',');
            string comment = String.IsNullOrWhiteSpace(check_comment) ? "" : DateTime.Now.ToString("yyyy/MM/dd ") + userLogin.dataUsers[0].user_name + ": " + check_comment + System.Environment.NewLine;
            string reject_comment = String.IsNullOrWhiteSpace(check_comment) ? "" : DateTime.Now.ToString("yyyy/MM/dd ") + userLogin.dataUsers[0].user_name + " Rejected: " + check_comment + System.Environment.NewLine;
            foreach (var id in arrayMRIDs)
            {
                var currentStatusRespose = db.getCurrentMRStatus(int.Parse(id));
                bool isChecker = userLogin.dataUsers.Any(e => new[] { "PAE", "PE1", "CRG", "PLAN", "PUR" }.Contains(e.dept_name) && new[] { "QV" }.Contains(e.factory) && new[] { 3 }.Contains(e.mr_role_id) && currentStatusRespose.dept_res.Contains(e.dept_name));
                bool isApprover = userLogin.dataUsers.Any(e => new[] { "PAE", "PE1", "CRG", "PLAN", "PUR" }.Contains(e.dept_name) && new[] { "QV" }.Contains(e.factory) && new[] { 4 }.Contains(e.mr_role_id) && currentStatusRespose.dept_res.Contains(e.dept_name));
                bool isYourTurn = userLogin.dataUsers.Any(e => currentStatusRespose.dept_res.Contains(e.dept_name) && currentStatusRespose.mr_role_id_res <= e.mr_role_id);
                bool isPAETurn = userLogin.dataUsers.Any(e => new[] { "PAE" }.Contains(e.dept_name) && currentStatusRespose.dept_res.Contains(e.dept_name) && currentStatusRespose.mr_role_id_res.Equals(e.mr_role_id));
                bool isOtherDeptTurn = userLogin.dataUsers.Any(e => new[] { "PE1", "CRG", "PLAN", "PUR" }.Contains(e.dept_name) && currentStatusRespose.dept_res.Contains(e.dept_name) && currentStatusRespose.mr_role_id_res.Equals(e.mr_role_id));
                if (isChecker || isApprover)
                {
                    //nếu Reject
                    if (isReject == true)
                    {
                        progressConfig = flowProgressLBP;
                        if (isYourTurn)
                        {
                            nextStatusID = 11;
                            sql = $"note = CONCAT('{reject_comment}' , mr.note ) ";

                            //sql = $"UPDATE mr " +
                            //                   $"SET  " +
                            //                   $"status_id= {nextStatusID}," +
                            //                   $"note = CONCAT('{reject_comment}' , mr.note ) " +
                            //                   $"WHERE mr_id = {int.Parse(id)}";

                        }
                        else
                        {
                            status = false;
                            fail.Add("MRNo: " + currentStatusRespose.MRNo + " It's not your turn!");
                        }
                        goto saveData;
                    }

                    if (isPAETurn)
                    {

                        if (currentStatusRespose.belong.Contains("INHOUSE"))
                        {
                            progressConfig = flowProgressINHOUSE;
                            nextStatusID = flowProgressINHOUSE[Array.IndexOf(flowProgressINHOUSE, currentStatusRespose.statusID) + 1];
                        }
                        else
                        {
                            progressConfig = flowProgressLBP;
                            nextStatusID = flowProgressLBP[Array.IndexOf(flowProgressLBP, currentStatusRespose.statusID) + 1];
                        }

                        var arrayParameter = new[] { check_is_de_die, check_no_of_die_component, check_die_maker, check_make_location, pdd, model_id, cav_qty, mc_size, supplier_id };
                        bool isPass = commonFunction.checkArrayHasAnyElementNullOrEmpty(arrayParameter);
                        if (!isPass)
                        {
                            string subSQL = "";
                            if (isChecker)
                            {
                                subSQL = $"pae_check_by='{userLogin.dataUsers[0].user_name}'," +
                                              $"pae_check_date = '{DateTime.Now}',";
                            }
                            if (isApprover)
                            {
                                subSQL = $"pae_app_by='{userLogin.dataUsers[0].user_name}'," +
                                              $"pae_app_date = '{DateTime.Now}',";
                            }
                            sql = $"is_de_die = '{check_is_de_die}'," +
                                  $"no_of_die_component = '{int.Parse(check_no_of_die_component)}'," +
                                  $"die_maker = '{check_die_maker}'," +
                                  $"make_location= '{check_make_location}'," +
                                  $"pdd = '{pdd}', " +
                                  $"model_id = '{model_id}', " +
                                  $"cav_qty = '{cav_qty}', " +
                                  $"mc_size = '{mc_size}', " +
                                  $"supplier_id = '{supplier_id}', " +
                                  $"family_part = '{family_part}', " +
                                  $"common_part = '{common_part}', " +
                                  $"die_special = '{check_die_special}'," +
                                                subSQL +
                                  $"note = CONCAT('{comment}' , mr.note ) ";
                            //sql = $"UPDATE mr " +
                            //                 $"SET  " +
                            //                 $"status_id= {nextStatusID}," +
                            //                 $"is_de_die = '{check_is_de_die}'," +
                            //                 $"no_of_die_component = '{int.Parse(check_no_of_die_component)}'," +
                            //                 $"die_maker = '{check_die_maker}'," +
                            //                 $"make_location= '{check_make_location}'," +
                            //                 $"die_special = '{check_die_special}'," +
                            //                    subSQL +
                            //                 $"note = CONCAT('{comment}' , mr.note ) " +
                            //                 $"WHERE mr_id = {int.Parse(id)}";


                        }
                        else
                        {
                            status = false;
                            msg = "Please input enough information!";
                            goto exit;
                        }
                    }
                    if (isOtherDeptTurn)
                    {

                        string subSQL = "";
                        bool isPETurn = userLogin.dataUsers.Any(e => new[] { "PE1" }.Contains(e.dept_name) && currentStatusRespose.dept_res.Contains(e.dept_name));
                        bool isCRGTurn = userLogin.dataUsers.Any(e => new[] { "CRG" }.Contains(e.dept_name) && currentStatusRespose.dept_res.Contains(e.dept_name));
                        bool isPLANTurn = userLogin.dataUsers.Any(e => new[] { "PLAN" }.Contains(e.dept_name) && currentStatusRespose.dept_res.Contains(e.dept_name));
                        bool isPURTurn = userLogin.dataUsers.Any(e => new[] { "PUR" }.Contains(e.dept_name) && currentStatusRespose.dept_res.Contains(e.dept_name));

                        if (isPETurn)
                        {
                            progressConfig = flowProgressPE1;
                            nextStatusID = flowProgressPE1[Array.IndexOf(flowProgressPE1, currentStatusRespose.statusID) + 1];
                            if (isChecker)
                            {
                                subSQL = $"pae_check_by='{userLogin.dataUsers[0].user_name}'," +
                                  $"pae_check_date = '{DateTime.Now}',";
                            }
                            if (isApprover)
                            {
                                subSQL = $"pae_app_by='{userLogin.dataUsers[0].user_name}'," +
                                   $"pae_app_date = '{DateTime.Now}',";
                            }
                        }

                        if (isCRGTurn)
                        {
                            progressConfig = flowProgressCRG;
                            nextStatusID = flowProgressCRG[Array.IndexOf(flowProgressCRG, currentStatusRespose.statusID) + 1];
                            if (isChecker)
                            {
                                subSQL = $"pae_check_by='{userLogin.dataUsers[0].user_name}'," +
                                  $"pae_check_date = '{DateTime.Now}',";
                            }
                            if (isApprover)
                            {
                                subSQL = $"pae_app_by='{userLogin.dataUsers[0].user_name}'," +
                                   $"pae_app_date = '{DateTime.Now}',";
                            }
                        }


                        if (isPLANTurn)
                        {
                            if (currentStatusRespose.belong.Contains("INHOUSE"))
                            {
                                progressConfig = flowProgressINHOUSE;
                                nextStatusID = flowProgressINHOUSE[Array.IndexOf(flowProgressINHOUSE, currentStatusRespose.statusID) + 1];
                            }
                            else
                            {
                                progressConfig = flowProgressLBP;
                                nextStatusID = flowProgressLBP[Array.IndexOf(flowProgressLBP, currentStatusRespose.statusID) + 1];
                            }

                            if (isChecker)
                            {
                                if (budget_code == null)
                                {
                                    status = false;
                                    msg = "Please input budget code!";
                                    fail.Add("MRNo: " + currentStatusRespose.MRNo + " Plz input budget code");
                                    goto exit;
                                }
                                subSQL = $"budget_code='{budget_code}'," +
                                    $"plan_check_by='{userLogin.dataUsers[0].user_name}'," +
                                  $"plan_check_date = '{DateTime.Now}',";
                            }
                            if (isApprover)
                            {
                                subSQL = $"plan_app_by='{userLogin.dataUsers[0].user_name}'," +
                                   $"plan_app_date = '{DateTime.Now}',";
                            }
                        }

                        if (isPURTurn)
                        {
                            nextStatusID = flowProgressLBP[Array.IndexOf(flowProgressLBP, currentStatusRespose.statusID) + 1];
                            if (isChecker)
                            {
                                subSQL = $"pur_check_by='{userLogin.dataUsers[0].user_name}'," +
                                  $"pur_check_date = '{DateTime.Now}',";
                            }
                            if (isApprover)
                            {
                                subSQL = $"pur_app_by='{userLogin.dataUsers[0].user_name}'," +
                                   $"pur_app_date = '{DateTime.Now}',";
                            }
                        }

                        sql = subSQL + $"note = CONCAT('{comment}', mr.note ) ";


                        //sql = $"UPDATE mr " +
                        //                     $"SET  " +
                        //                     $"status_id= {nextStatusID}," +
                        //                     subSQL +
                        //                      $"note = CONCAT('{comment}', mr.note ) " +
                        //                     $"WHERE mr_id = {int.Parse(id)}";


                    }
                    if (isPAETurn == false && isOtherDeptTurn == false)
                    {
                        status = false;
                        fail.Add("MRNo: " + currentStatusRespose.MRNo + " is not your turn CHECK/APPROVE");
                    }
                // lưu data
                saveData:
                  
                    if (!String.IsNullOrWhiteSpace(sql))
                    {
                        string sqlGetMRByID = $"SELECT * FROM mr WHERE mr_id = {int.Parse(id)} ";
                        var MR = db.ExcuteQueryAndGetData(sqlGetMRByID).data[0];
                        if (nextStatusID == 4) // đến PLAN
                        {
                            bool isNeedCapital = commonFunction.isNeedCapitalBugdet(int.Parse(MR["type_id"].ToString()), double.Parse(MR["estimate_cost"].ToString()), MR["unit"].ToString());
                            if (!isNeedCapital) // Bỏ qua Plan
                            {
                                nextStatusID = progressConfig[Array.IndexOf(progressConfig, nextStatusID) + 2];
                            }
                        }

                        string finalSQL = $"UPDATE mr " +
                                                $"SET  " +
                                                $"status_id= {nextStatusID}," +
                                                sql +
                                                 $"WHERE mr_id = {int.Parse(id)}";
                        db.ExcuteQueryAndGetData(finalSQL);
                        status = true;
                        success.Add(int.Parse(id));

                        // Link sang PO
                        if (nextStatusID == 8 && !currentStatusRespose.belong.Contains("INHOUSE")) 
                        {
                            string PR = (commonFunction.getNummberInString(MR["clasification"].ToString()))?.ToString().PadLeft(2, '0');
                            float estimateCost = float.Parse(MR["estimate_cost"].ToString());
                            bool isTempPO = false;
                            if(estimateCost == 10)
                            {
                                isTempPO = true;
                            }

                            string sqlADDPO = $"INSERT INTO public.po_dies (mr_id, po_status_id,temp_po, pr, delivery_date,is_active, create_date, is_reissue)  " +
                                              $"VALUES({id},{1}, '{isTempPO}', '{PR}', '{MR["pdd"].ToString()}', {true}, {DateTime.Now}, 'false')";
                            db.ExcuteQueryAndGetData(sqlADDPO);
                        }

                    }

                }
                else
                {
                    status = false;
                    fail.Add("MRNo: " + currentStatusRespose.MRNo + " You do not have permision!");

                }
            exitLoop:
                var a = "exit loop";
            }


        exit:
            var result = new
            {
                status = status,
                msg = msg,
                success = success,
                fail = fail,
            };
            return Json(result);
        }

        public JsonResult api_getMRByID(int id)
        {

            bool status = false;
            string msg = "";
            var islogin = authen.isLoginAndReturnUserProfile(HttpContext);

            dataReturn data = new dataReturn();
            if (islogin.status)
            {
                data = db.getMRByID(id);
                status = true;
            }
            else
            {
                msg = "Please login!";
                status = false;
            }


        exit:
            var output = new
            {
                status = status,
                msg = msg,
                Data = data.data,
            };
            return Json(output);
        }

        public JsonResult api_getMRStatusResponByID(int id)
        {

            bool status = false;
            string msg = "";
            var islogin = authen.isLoginAndReturnUserProfile(HttpContext);

            dataReturn data = new dataReturn();
            if (islogin.status)
            {
                data = db.getMRStatusResponByID(id);
                status = true;
            }
            else
            {
                msg = "Please login!";
                status = false;
            }


        exit:
            var output = new
            {
                status = status,
                msg = msg,
                Data = data.data,
            };
            return Json(output);
        }






    }
}
