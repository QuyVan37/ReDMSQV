﻿using DMSQV_API.Data;
using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml.Style;
using static DMSQV_API.Data.DBConnector;

namespace DMSQV_API.Controllers
{
    public class PO_API : Controller
    {
        DBConnector db = new DBConnector();
        Authen authen = new Authen();
        CommonFunction commonFunction = new CommonFunction();
        WorkInExcel workInExcel = new WorkInExcel();
        public int[] issueNew = { 2, 3, 4, 5, 6, 7, 8, 23 };
        public int[] issueNewTemPOneedGMPUR = { 10, 3, 4, 5, 6, 7, 24, 8, 23 };
        public int[] changeRequest = { 11, 12, 13, 14 };
        public int[] cancelRequest = { 16, 17, 18, 19, 20 };

        public JsonResult api_getPOList(string search, string? supplier_id, string? mr_type_id, string dept, string po_role_id, int? page = 1, int? pageSize = 50)
        {
            search = search?.Trim();
            bool status = false;
            string msg = "";
            var islogin = authen.isLoginAndReturnUserProfile(HttpContext);

            dataReturn data = new dataReturn();
            if (islogin.status)
            {
                data = db.getPOList(search, supplier_id, mr_type_id, dept, po_role_id, page, pageSize);
                status = true;
            }
            else
            {
                msg = "Please login!";
                status = false;
            }


        exit:
            var output = new
            {
                status = status,
                msg = msg,
                recordsTotal = data.totalCount,
                recordsFiltered = data.totalCount,
                page = page,
                pageSize = pageSize,
                Data = data.data,
            };
            return Json(output);
        }

        public JsonResult api_checkItemCanIssue_change_cancel(string listPO_ID, string action)
        {
            //Action new / change/ cancel
            string[] listID = listPO_ID.Split(',');
            List<object> output = new List<object>();
            foreach (string po_id in listID)
            {
                string sql = "";
                string sqlCheckNew = $"SELECT po.po_id, mr.part_no, mr.clasification, spl.supplier_code, mr.order_to, po.delivery_date FROM po_dies po  " +
                    $"INNER JOIN mr ON mr.mr_id = po.mr_id  " +
                    $"INNER JOIN suppliers spl ON spl.supplier_id = mr.supplier_id  " +
                    $"WHERE po.po_id ={po_id}  AND po.po_status_id IN (1,9,21) AND (po.is_active is null OR po.is_active = true) ";

                string sqlCheckChange = $"SELECT po.po_id, mr.part_no, mr.clasification, spl.supplier_code, mr.order_to, po.delivery_date,po.buyercode, po.order_qty, po.use_block_code, po.delivery_location  FROM po_dies po  " +
                    $"INNER JOIN mr ON mr.mr_id = po.mr_id   " +
                    $"INNER JOIN suppliers spl ON spl.supplier_id = mr.supplier_id  " +
                    $"INNER JOIN po_status_category s ON s.po_status_id = po.po_status_id  " +
                    $"WHERE po.po_id ={po_id} AND s.is_can_change_po = true AND (po.is_active is null OR po.is_active = true)";

                string sqlCheckCancel = $"SELECT po.po_id, mr.part_no, mr.clasification, spl.supplier_code, mr.order_to, po.delivery_date,po.buyercode, po.order_qty, po.use_block_code, po.delivery_location, s.is_can_cancel_without_puc  FROM po_dies po  " +
                    $"INNER JOIN mr ON mr.mr_id = po.mr_id   " +
                    $"INNER JOIN suppliers spl ON spl.supplier_id = mr.supplier_id  " +
                    $"INNER JOIN po_status_category s ON s.po_status_id = po.po_status_id  " +
                    $"WHERE po.po_id ={po_id} AND s.is_can_cancel_po = true AND (po.is_active is null OR po.is_active = true)";


                sql = action == "new" ? sqlCheckNew : (action == "change" ? sqlCheckChange : (action == "cancel" ? sqlCheckCancel : ""));
                var data = db.ExcuteQueryAndGetData(sql).data;
                if (data.Count > 0)
                {
                    output.Add(data[0]);
                }
            }
            var resutl = new
            {
                data = output
            };

            return Json(resutl);
        }


        public JsonResult api_issuePO(string po_ids, string vendor_fctry, string need_register_rate_table_by_part, string order_qty, string delivery_location,
            string warranty_shot, string trade_condition_p_name, string use_block_code, string item_category, string transport_method, string container_loading_code,
            string delivery_date, string temp_reason)
        {
            bool status = false;
            string msg = "";
            int success = 0;
            int fail = 0;
            var userLogin = authen.isLoginAndReturnUserProfile(HttpContext);
            if (userLogin.status)
            {
                bool isPermit = userLogin.dataUsers.Any(e => new[] { "PUR" }.Contains(e.dept_name) && new[] { "QV" }.Contains(e.factory) && new[] { 3 }.Contains(e.po_role_id));
                if (!isPermit)
                {
                    status = false;
                    msg = "You dont not has permision!";
                    goto exit;
                }
                //2. Lấy procudure
                string sqlGetProcudure = $"SELECT * FROM procedure_control  WHERE pro_name ilike '%Issue PO%' and is_active = true and affective_date::date < CURRENT_DATE";
                var lastPOprocudure = db.ExcuteQueryAndGetData(sqlGetProcudure).data[0];

                var listPO = po_ids.Split(',');
                foreach (var id in listPO)
                {
                    var PO = db.ExcuteQueryAndGetData($"SELECT * FROM po_dies WHERE po_id = {id}").data[0];
                    bool isCanIssue = new[] { 1, 9, 21 }.Contains(int.Parse(PO["po_status_id"].ToString()));
                    if (!isCanIssue)
                    {
                        fail++;
                        goto exitLoop;
                    }
                    var isReissue = bool.Parse(PO["is_reissue"].ToString());
                    //1. Tạo số
                    var PONO = createPOIssueNo(PO["po_issue_no"].ToString(), !isReissue, false, false, isReissue);
                    //3. Delivery được input và deliveryOriginal
                    var pdd = String.IsNullOrWhiteSpace(delivery_date) ? PO["delivery_date"] : delivery_date;
                    var pddOrigin = pdd;
                    if (isReissue)
                    {
                        pddOrigin = PO["original_delivery_date"].ToString();
                    }
                    string sqlUpdate = $"UPDATE public.po_dies po   " +
                                       $"SET po_status_id =  CASE WHEN po.temp_po = true THEN 10 ELSE 2 END , " +
                                       $"po_issue_no= '{PONO}', " +
                                       $"delivery_date='{pdd}',  " +
                                       $"original_delivery_date='{pddOrigin}', " +
                                       $"delivery_location= '{delivery_location}', " +
                                       $"warranty_shot='{warranty_shot}',  " +
                                       $"trade_condition_p_name= '{trade_condition_p_name}',  " +
                                       $"use_block_code= '{use_block_code}', " +
                                       $"vendor_fctry= '{use_block_code}',  " +
                                       $"need_register_rate_table_by_part='{need_register_rate_table_by_part}', " +
                                       $"order_qty= '{order_qty}'," +
                                       $" item_category= '{item_category}',  " +
                                       $"transport_method= '{transport_method}', " +
                                       $"container_loading_code= '{container_loading_code}',  " +
                                       $"buyercode= '{userLogin.dataUsers[0].buyer_code}',  " +
                                       $"issue_by= '{userLogin.dataUsers[0].user_name}', " +
                                       $"issue_date= '{DateTime.Now}', " +
                                       $"procedure_no= '{lastPOprocudure["pro_no"]}', " +
                                       $"attach_no_new= '{lastPOprocudure["att_no"]}', " +
                                       $"reason_issue_po= '{temp_reason}' " +
                                       $"WHERE po_id = {id};";

                    try
                    {
                        db.ExcuteQueryAndGetData(sqlUpdate);
                        success++;
                        status = true;
                    }
                    catch
                    {
                        fail++;
                    }
                exitLoop:
                    var a = "Just exit loop";
                }
            }
            else
            {
                status = false;
                msg = "Please login!";

            }

        exit:
            var result = new
            {
                status = status,
                msg = msg,
                success = success,
                fail = fail
            };
            return Json(result);
        }

        public bool api_changePORequest(int po_id, string change_delivery_date, string change_delivery_key_no, string change_delivery_location, string change_order_qty, string change_reason, string change_use_block_code IFormFile evident)
        {
            bool status = false;
            string msg = "";

            var userLogin = authen.isLoginAndReturnUserProfile(HttpContext);
            if (userLogin.status)
            {
                bool isPermit = userLogin.dataUsers.Any(e => new[] { "PUR" }.Contains(e.dept_name) && new[] { "QV" }.Contains(e.factory) && new[] { 3 }.Contains(e.po_role_id));
                if (!isPermit)
                {
                    status = false;
                    msg = "You dont not has permision!";
                    goto exit;
                }
                //2. Lấy procudure
                string sqlGetProcudure = $"SELECT * FROM procedure_control  WHERE pro_name ilike '%change PO%' and is_active = true and affective_date::date < CURRENT_DATE";
                var lastPOprocudure = db.ExcuteQueryAndGetData(sqlGetProcudure).data[0];
                string sqlCheckChange = $"SELECT po.* FROM po_dies po  " +
                                        $"INNER JOIN po_status_category s ON s.po_status_id = po.po_status_id  " +
                                        $"WHERE po.po_id ={po_id} AND s.is_can_change_po = true";
                var PO = db.ExcuteQueryAndGetData(sqlCheckChange).data;

                if (PO.Count() == 0)
                {
                    status = false;
                    goto exit;
                }

                // Lấy status before request change
                var currentStatusID = int.Parse(PO[0]["po_status_id"].ToString());
                var oldStatus = currentStatusID;
                if (currentStatusID == 15)
                {
                    oldStatus = int.Parse(PO[0]["po_status_id_before_change_or_cancel"].ToString());
                }
                //1. Tạo số
                var PONO = createPOIssueNo(PO[0]["po_issue_no"].ToString(), false, true, false, false);

                // Luu evident
                
                 string pathEvendent = commonFunction.savePhysicalFileOnServer(evident, "/File/Attachment/PO/", "Change_evident_");
                
                string sqlUpdate = $"UPDATE public.po_dies po   " +
                                      $"SET " +
                                      $"po_status_id = 11 , " +
                                      $"po_status_id_before_change_or_cancel = '{oldStatus}' , " +
                                      $"po_issue_no= '{PONO}', " +
                                      $"change_delivery_date= '{change_delivery_date}', " +
                                      $"change_delivery_key= '{change_delivery_key_no}', " +
                                      $"change_reason= '{change_reason}', " +
                                      $"change_evidential= '{pathEvendent}', " +
                                      $"change_request_by= '{userLogin.dataUsers[0].user_name}', " +
                                      $"change_request_date= '{DateTime.Now}' ," +
                                      $"procedure_no= '{lastPOprocudure["pro_no"]}', " +
                                      $"attach_no_change= '{lastPOprocudure["att_no"]}' " +
                                      $"WHERE po_id = {po_id};";
                db.ExcuteQueryAndGetData(sqlUpdate);
                status = true;
            }
            else
            {
                status = false;
                msg = "Please login";
            }

        exit:
            return status;
        }

        public bool api_cancelPORequest(int po_id, string cancel_delivery_key_no, string cancel_reason, string is_reIssue, IFormFile evident)
        {
            bool status = false;
            string msg = "";

            var userLogin = authen.isLoginAndReturnUserProfile(HttpContext);
            if (userLogin.status)
            {
                bool isPermit = userLogin.dataUsers.Any(e => new[] { "PUR" }.Contains(e.dept_name) && new[] { "QV" }.Contains(e.factory) && new[] { 3 }.Contains(e.po_role_id));
                if (!isPermit)
                {
                    status = false;
                    msg = "You dont not has permision!";
                    goto exit;
                }
                //2. Lấy procudure
                string sqlGetProcudure = $"SELECT * FROM procedure_control  WHERE pro_name ilike '%cancel PO%' and is_active = true and affective_date::date < CURRENT_DATE";
                var lastPOprocudure = db.ExcuteQueryAndGetData(sqlGetProcudure).data[0];
                string sqlCheckCancel = $"SELECT po.*, s.is_can_cancel_without_puc FROM po_dies po  " +
                                        $"INNER JOIN po_status_category s ON s.po_status_id = po.po_status_id  " +
                                        $"WHERE po.po_id ={po_id} AND is_can_cancel_po = true ";
                var PO = db.ExcuteQueryAndGetData(sqlCheckCancel).data;

                if (PO.Count() == 0)
                {
                    status = false;
                    goto exit;
                }

                // Lấy status before request cancel
                var currentStatusID = int.Parse(PO[0]["po_status_id"].ToString());
                var oldStatus = currentStatusID;
                if (currentStatusID == 22)
                {
                    oldStatus = int.Parse(PO[0]["po_status_id_before_change_or_cancel"].ToString());
                }
                //1. Tạo số
                var PONO = createPOIssueNo(PO[0]["po_issue_no"].ToString(), false, false, true, false);
                // Luu Evendent
                string pathEvendent = commonFunction.savePhysicalFileOnServer(evident, "/File/Attachment/PO/", "Change_evident_");
                // Next statusID
                var po_status_id = 16;
                if (PO[0]["is_can_cancel_without_puc"].Equals(true))
                {
                    po_status_id = 20;
                }

                string sqlUpdate = $"UPDATE public.po_dies po   " +
                                      $"SET " +
                                      $"po_status_id = {po_status_id} , " +
                                      $"po_status_id_before_change_or_cancel = '{oldStatus}' , " +
                                      $"po_issue_no= '{PONO}', " +
                                      $"is_reissue= '{is_reIssue}', " +
                                      $"cancel_delivery_key= '{cancel_delivery_key_no}', " +
                                      $"cancel_reason= '{cancel_reason}', " +
                                      $"cancel_evidential= '{pathEvendent}', " +
                                      $"cancel_request_by= '{userLogin.dataUsers[0].user_name}', " +
                                      $"cancel_request_date= '{DateTime.Now}' " +
                                      $"WHERE po_id = {po_id};";
                db.ExcuteQueryAndGetData(sqlUpdate);
                status = true;
            }
            else
            {
                status = false;
                msg = "Please login";
            }

        exit:
            return status;
        }


        public JsonResult api_getSumarizePOPending()
        {
            var result = db.getSumarizePOPending();
            return Json(result);
        }
        public JsonResult api_getPOByID(int id)
        {

            bool status = false;
            string msg = "";
            var islogin = authen.isLoginAndReturnUserProfile(HttpContext);

            dataReturn data = new dataReturn();
            if (islogin.status)
            {
                data = db.getPOByID(id);
                status = true;
            }
            else
            {
                msg = "Please login!";
                status = false;
            }


        exit:
            var output = new
            {
                status = status,
                msg = msg,
                Data = data.data,
            };
            return Json(output);
        }

        public string createPOIssueNo(string poIssueNo, bool isNew, bool isChange, bool isCancel, bool isReIsuse)
        {
            var today = DateTime.Now;
            string SucPOIssueNo = "";

            // Genarate MRNo
            string sqlCountPOInYear = $"SELECT count(po_id) FROM po_dies WHERE Extract (year from create_date) = {DateTime.Now.Year}";
            string totalPOinYear = (int.Parse(db.ExcuteQueryAndGetData(sqlCountPOInYear).data[0]["count"].ToString()) + 1).ToString().PadLeft(4, '0'); // 0012 ;

            // Neu new Issue
            if (isNew) // mới mà chưa có số PO
            {
                if (String.IsNullOrEmpty(poIssueNo))
                {
                    SucPOIssueNo = "PO" + today.ToString("yyMMdd") + "-" + totalPOinYear + "-NE-00";
                }
                else
                {
                    SucPOIssueNo = poIssueNo;
                }
            }
            else
            {
                var mainNo = "";
                var upverStr = "";
                if (!String.IsNullOrEmpty(poIssueNo))
                {
                    var curentPOissueNo = poIssueNo;
                    mainNo = curentPOissueNo.Remove(curentPOissueNo.Length - 5, 5); //NE-00
                    var upver = curentPOissueNo.Substring(curentPOissueNo.Length - 2, 2); //00
                    int upverInt = Convert.ToInt16(upver) + 1;
                    upverStr = Convert.ToString(upverInt).PadLeft(2, '0'); //01, 02, 03...
                }
                if (isChange)
                {
                    SucPOIssueNo = mainNo + "CH-" + upverStr;
                }
                if (isCancel)
                {
                    if (poIssueNo == null)
                    {
                        SucPOIssueNo = "-";
                    }
                    else
                    {
                        SucPOIssueNo = mainNo + "CC-" + upverStr;
                    }
                }
                if (isReIsuse)
                {
                    SucPOIssueNo = mainNo + "RE-" + upverStr;
                }

            }
            return SucPOIssueNo;
        }
    }
}
