﻿using DMSQV_API.Models;
using Microsoft.AspNetCore.Razor.TagHelpers;
using Npgsql;
using System.Data.Common;
using System.Text;

namespace DMSQV_API.Data
{
    public class DBConnector
    {
        //START*** Cấu hình kết nối đến Postgress **//
        string connectionString = "Host=localhost;Username=postgres;Password=sa;Database=DMS";

        public class dataReturn
        {
            public int rowEffected { get; set; }
            public List<Dictionary<string, object>> data { get; set; }

        }
        private dataReturn GetDataFromDatabase(string sql)
        {
            int rowEffected = 0;
            List<Dictionary<string, object>> data = new List<Dictionary<string, object>>();
            using (var connection = GetConnection())
            {
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = sql;
                    using (var reader = command.ExecuteReader())
                    {
                        rowEffected = reader.RecordsAffected;
                        while (reader.Read())
                        {
                            var row = new Dictionary<string, object>();
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                row.Add(reader.GetName(i), reader.GetValue(i));
                            }
                            data.Add(row);
                        }
                    }
                    connection.Close();
                }
            }
            var output = new dataReturn
            {
                rowEffected = rowEffected,
                data = data
            };
            return output;
        }


        private DbConnection GetConnection()
        {

            var connection = new NpgsqlConnection(connectionString);
            connection.Open();
            return connection;
        }

        //END*** Cấu hình kết nối đến Postgress **//


        // Start các chuỗi kết nối đến databse

        public dataReturn ExistUser(string code, string password)
        {
            var today = DateTime.Now;
            string sql = $"update users set last_online = '{today}' where user_code = '{code}' and password = '{password}'; " +
                $"SELECT CASE WHEN EXISTS ( SELECT 1  FROM users u WHERE user_code = '{code}' and password = '{password}')" +
                $"THEN (SELECT u.user_id FROM users u WHERE user_code = '{code}' and password = '{password}') ELSE 0 END AS result;";

            var resutl = GetDataFromDatabase(sql);
            // nếu ko tồn tại thì return 0, nếu tồn tại user thì return user_id
            return resutl;
        }

        public dataReturn getUserProfile(int user_id)
        {
            string sql = $"SELECT u.*,d.*,c.tpi_role_id, c.mr_role_id, c.po_role_id, c.die_role_id, c.dtf_role_id, c.dsum_role_id, c.dispose_role_id,c.dcf_role_id from userrole c " +
                $"inner join users u on c.user_id = u.user_id  " +
                $"inner join  department d on c.dept_id = d.dept_id " +
                $"where c.user_id = {user_id}";

            var resutl = GetDataFromDatabase(sql);
            return resutl;
        }

        public dataReturn getDMSGradeCatergory()
        {
            string sql = $"SELECT * FROM gradecategory";
            var result = GetDataFromDatabase(sql);
            return result;
        }

        public dataReturn getDMSRoleCatergory()
        {
            string sql = $"SELECT * FROM rolecategory";
            var result = GetDataFromDatabase(sql);
            return result;
        }

        public dataReturn getListDept()
        {
            string sql = $"SELECT * FROM department";
            var result = GetDataFromDatabase(sql);
            return result;
        }

        public dataReturn resetPW(string code, string encodePW)
        {
            string sql = $"UPDATE users set password = '{encodePW}' WHERE user_code = '{code}'";
            var result = GetDataFromDatabase(sql);
            return result;
        }

        public dataReturn isExistEmployeeCode(string user_code)
        {
            string sql = $"SELECT user_id FROM users u WHERE user_code ILIKE '%{user_code}%'";
            var result = GetDataFromDatabase(sql);
            return result;
        }

        public dataReturn CreateNewDMSAccount(string user_code, string user_name, string password, string buyer_code, int grade_id, string email, string[] dept_ids)
        {
            int user_id = 0;
            var result = new dataReturn();
            var encodePW = encodePassword.EncodePasswordMd5(password);
            // 1. insert vao bang user va lay duoc user_id
            string sqlInsertUser = $"INSERT INTO public.users(user_name, user_code, password, buyer_code, grade_id, email, is_admin, is_verified, is_active, is_delete, lock_reason, last_online, create_date)" +
                $"VALUES ('{user_name}', '{user_code}', '{encodePW}', '{buyer_code}', {grade_id}, '{email}', {false}, {false}, {false}, {false}, '{"Waiting Admin verify you register!"}','{DateTime.Now}' ,'{DateTime.Now} ');";
            var resultInsertUser = GetDataFromDatabase(sqlInsertUser);
            if (resultInsertUser.rowEffected > 0)
            {
                string sql_getnewUser_id = $"SELECT u.user_id FROM users u WHERE user_code = '{user_code}'";
                var user_id_raw = GetDataFromDatabase(sql_getnewUser_id);
                user_id = (int)user_id_raw.data[0].Values.ToList()[0];
                foreach (var dept_id_str in dept_ids)
                {
                    int dept_id_int = int.Parse(dept_id_str);
                    //2. insert vao bang userrole 
                    string sqlInsertRole = $"INSERT INTO public.userrole( user_id, dept_id, tpi_role_id, mr_role_id, po_role_id, die_role_id, dtf_role_id, dsum_role_id, dispose_role_id, dcf_role_id)" +
                                            $"VALUES ({user_id},{dept_id_int},{1},{1},{1},{1},{1},{1},{1},{1});";
                    result = GetDataFromDatabase(sqlInsertRole);
                }
            }
            return result;
        }

    }
}
