﻿using Microsoft.AspNetCore.Mvc;

namespace DMSQV_API.Controllers
{
    public class SendEmail : Controller
    {
        public void sendEmailResetPW(string to, string newPW)
        {

        }
    }
}
