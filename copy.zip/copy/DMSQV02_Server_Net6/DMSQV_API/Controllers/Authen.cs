﻿using DMSQV_API.Data;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using DMSQV_API.Models;
using System.Reflection.Metadata;

namespace DMSQV_API.Controllers
{
    public class Authen : Controller
    {
        DBConnector db = new DBConnector();
        CommonFunction commonfunction = new CommonFunction();
        SendEmail sendEmail = new SendEmail();
        public async Task<JsonResult> api_login(string code, string password)
        {
            // Kiểm tra user có tồn tại hau ko?
            // nếu user ID > 0 là tồn tại và tạo cookie trả về client + thông tin users + status = true
            // nếu user = 0 ko tồn tại user, trả về client status = false và user = null
            bool status = false;
            string encodePW = encodePassword.EncodePasswordMd5(password);
            var result = db.ExistUser(code, encodePW);
            var user_id = (int)result.data[0].Values.ToList()[0];

            if (user_id > 0) // có tồn tại user này rồi
            {
                // tạo cookie
                var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, user_id.ToString())
                };
                var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity));
                status = true;
                //HttpContext.Session.SetString("user_id", user_id.ToString());
                //var isCookiePresent = Request.Cookies.ToList();
            }
            var output = new
            {
                status = status,
                user = api_getUserProfile(user_id),
            };
            return Json(output);
        }



        public async Task<JsonResult> api_logout()
        {
            // clear cookie and session
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            HttpContext.Session.Clear();
            return Json(true);
        }


        public JsonResult api_isLoginAndReturnUserProfile()
        {
            bool isLogin = true;
            // Lấy user_id dùng từ claim cookie
            var user_id = HttpContext.User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value;

            // Lấy các thông tin khác nếu cần
            var userInfor = HttpContext.User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier)?.Value;

            if (user_id == null)
            {
                user_id = "0";
                isLogin = false;
            }


            var output = new
            {
                status = isLogin,
                user = api_getUserProfile(int.Parse(user_id)),
            };

            return Json(output);
        }

        

        public object api_getUserProfile(int user_id)
        {
            var user = db.getUserProfile(user_id);
            return user;
        }

        public object api_resetPW(string user_code)
        {
            bool status = false;
            string newPW = encodePassword.RandomString(6);
            string encodePW = encodePassword.EncodePasswordMd5(newPW);
            var result = db.resetPW(user_code, encodePW);
            if (result.rowEffected > 0)
            {
                status = true;
                sendEmail.sendEmailResetPW(user_code, newPW);
            }
            var output = new
            {
                status = status,
                data = result
            };

            return Json(output);
        }

        public object api_createNewAccount(string user_code, string user_name, string password, string buyer_code, string grade_id, string email, string dept_id)
        {
            bool status = false;
            string msg = "";
            var arrayParameter = new[] { user_code, user_name, password, grade_id, email, dept_id };
            int grade_id_int = int.Parse(grade_id);
            string[] dept_ids = dept_id.Split(',');
            bool testResult = commonfunction.checkArrayHasAnyElementNullOrEmpty(arrayParameter);
            if (!testResult)
            {
                var isExistUser = db.isExistEmployeeCode(user_code);
                if (isExistUser.data.Count() > 0)
                {
                    status = false;
                    msg = $"This Employee Code {user_code} already register account, Please reset PW if you forgot";
                }
                else // tao tai khoan moi
                {
                   var result = db.CreateNewDMSAccount(user_code, user_name, password, buyer_code, grade_id_int, email, dept_ids);
                  
                    status = true;
                    msg = "Create sucess! Please wait Admin verify you account!";
                }
            }
            else
            {
                status = false;
                msg = "Please input all information!";
            }

            var output = new
            {
                status = status,
                msg = msg,
            };
            return Json(output);
        }


        //public object api_changeUserProfile(string grade_id, string email)
        //{
        //    bool status = false;
        //   var currentUser_id = 

        //}
    }
}
