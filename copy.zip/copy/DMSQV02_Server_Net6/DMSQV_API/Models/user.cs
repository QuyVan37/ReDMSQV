﻿namespace DMSQV_API.Models
{
    public class user
    {
        public int user_id { get; set; }
        public string? user_name { get; set; }
        public string? user_code { get; set; }
        public string? buyer_code { get; set; }
        public string? grade_id { get; set; }
        public string? email { get; set; }
        public Boolean is_admin { get; set; }
        public Boolean is_verified { get; set; }
        public Boolean is_active { get; set; }
        public Boolean is_delete { get; set; }
        public string? lock_reason { get; set; }
        public DateTime last_online { get; set; }
        public DateTime create_date { get; set; }
        public int dept_id { get; set; }
        public string? dept_name { get; set; }
        public string? division { get; set; }
        public int tpi_role_id { get; set; }
        public int mr_role_id { get; set; }
        public int po_role_id { get; set; }
        public int die_role_id { get; set; }
        public int dtf_role_id { get; set; }
        public int dsum_role_id { get; set; }
        public int dispose_role_id { get; set; }
        public int dcf_role_id { get; set; }
    }
}
