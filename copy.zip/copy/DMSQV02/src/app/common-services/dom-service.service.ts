import { Injectable } from '@angular/core';
declare var $: any;
declare var bootstrap: any;
@Injectable({
  providedIn: 'root'
})
export class DOMServiceService {

  constructor() { }
  onloading(selector: string) {
    $(document).find(selector).addClass('disabled')
    $(document).find(selector).children('.spinner-border').remove()
    $(document).find(selector).append(
      `
        <span class="spinner-border spinner-border-sm" aria-hidden="true"></span>
      `)
  }

  onloaded(selector: string) {
    $(document).find(selector).children('.spinner-border').remove()
    $(document).find(selector).removeClass('disabled')
  }


  createOptionElement(
    listOption: any[] | undefined,
    fields_view: Array<string>,
    Field_value: string,
    selected_Value: string
  ): string {
    let option = '<option value="">---</option>';
    listOption?.forEach(e => {
      let view: Array<string> = [];
      fields_view.forEach(f => {
        view.push(e[f]);
      });
      option += `<option ${e[Field_value] === selected_Value ? 'selected' : ''} value="${e[Field_value]}">${view.join('-')}</option>`;
    });
    return option;
  }

  appendToElement(selector: string, content: string) {
    $(selector).empty().append(content)
  }


  showAlertMassage(massage: string, isSucces: boolean) {

    // massageType: success or faill
    let bg_color = "danger"
    if (isSucces) bg_color = 'success'
    //1. Loại bỏ modal ra khỏi DOM nếu có
    $(document).find('#modelAlertMassage').remove()
    //2. add modal vào DOM
    $('.content').append(
      `
     <div class="modal fade" id="modelAlertMassage" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
     <div class="modal-dialog">
         <div class="modal-content">
         <div class="modal-header bg-${bg_color} text-white">
             <h1 class="modal-title fs-5" id="exampleModalLabel">System massage</h1>
             <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
         </div>
         <div class="modal-body">
             ${massage}
         </div>
         <div class="modal-footer">
             <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
         </div>
         </div>
     </div>
     </div>
     `
    )

    // 3. show modal
    const modalMassage = new bootstrap.Modal('#modelAlertMassage', {
      keyboard: false
    })
    modalMassage.show()
  }

  showUserInActiveWaning(msg: string) {
    //1. Loại bỏ modal ra khỏi DOM nếu có
    $(document).find('#modelAlertMassage').remove()
    console.log('ssss')
    $('.content').append(
      `
        <div class="modal fade" id="modalWarningUserNotActive" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header bg-danger">
                <h1 class="modal-title fs-5" id="staticBackdropLabel">Waring: You account was not active!</h1>
              </div>
              <div class="modal-body">
                  ${msg}

              </div>
                <div class="modal-footer">
                  <a href="/login">Login other account</a>
                </div>
            </div>
          </div>
        </div>
     `
    )
    // 3. show modal
    const modalMassage = new bootstrap.Modal('#modalWarningUserNotActive', {
      keyboard: false
    })
    modalMassage.show()

  }










}