import { Component } from '@angular/core';

@Component({
  selector: 'app-dcf',
  templateUrl: './dcf.component.html',
  styleUrl: './dcf.component.css'
})
export class DcfComponent {

}
