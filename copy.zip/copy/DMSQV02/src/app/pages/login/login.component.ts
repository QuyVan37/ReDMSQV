import { Component, OnInit } from '@angular/core';
import { AuthenService } from '../../API-Services/authen.service';
import { Router } from '@angular/router';
import { FormControl, FormGroup } from '@angular/forms';
import { DataTrasferService } from '../../common-services/data-transfer.service';
import { DOMServiceService } from '../../common-services/dom-service.service';
import { CookieService } from 'ngx-cookie-service';
import { AppAPIService } from '../../API-Services/app-api.service';
import * as moment from 'moment';
import { error } from 'jquery';


declare var $: any;
declare var bootstrap: any;
declare var Validator: any;
declare var selectjs: any // jsFunction trong asset/selecjs, chức năng để để modify lại thẻ select để search option


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit {
  public massage = ""
  constructor(private authen: AuthenService,
    private router: Router,
    private dataTrasferService: DataTrasferService,
    private DOMServiceService: DOMServiceService,
    private cookieService: CookieService,
    private APIservices: AppAPIService,

  ) { }
  islogin = true;
  isResetPW = false;
  isCreateNew = false;
  ngOnInit(): void {
    this.authen.logout()
    this.islogin = true;
    this.isResetPW = false;
    this.isCreateNew = false;
  }

  showFormResetPW() {
    this.islogin = false;
    this.isResetPW = true;
    this.isCreateNew = false;
    this.massage = ''
  }
  showFormLogin() {
    this.islogin = true;
    this.isResetPW = false;
    this.isCreateNew = false;
    this.massage = ''
  }
  showFormCreateNew() {
    this.islogin = false;
    this.isResetPW = false;
    this.isCreateNew = true;
    this.massage = ''
    this.createGradeOptionElement()
    this.createDeptOptionElement()
    selectjs()
  }

  async createGradeOptionElement() {
    let grades = await this.APIservices.getGradeCategory().toPromise()
    let result = this.DOMServiceService.createOptionElement(grades?.data, ["grade_name"], "grade_id", "")
    this.DOMServiceService.appendToElement("select#grade_id", result)
  }

  async createDeptOptionElement() {
    let depts = await this.APIservices.getListDept().toPromise()
    let result = this.DOMServiceService.createOptionElement(depts?.data, ["dept_name", 'factory'], "dept_id", "")
    this.DOMServiceService.appendToElement("select#dept_id", result)
  }

  loginForm: FormGroup = new FormGroup({
    code: new FormControl('443975'),
    password: new FormControl('nMk9w1')
  })

  submitLogin() {
    this.DOMServiceService.onloading('.btn_login')
    this.authen.login(this.loginForm.value).subscribe(
      data => {
        if (data.status == true) {
          let user = data.user.data
          this.dataTrasferService.transferUserProfile(user)
          // luu cookie vao store rate
          let json_user = JSON.stringify(user)
          localStorage.setItem("user", json_user)

          // quay lai trang truoc khi login
          let currentURL = localStorage.getItem('currentURL') + ""
          location.href = currentURL
        } else {
          this.massage = "Code or Password not correct!"
        }
        this.DOMServiceService.onloaded('.btn_login')

      },
      error => {
        this.massage = "System Erorr!"
        this.DOMServiceService.onloaded('.btn_login')
      }

    )
  }

  submitResetPW() {
    let _that = this
   
    Validator({
      form: '#form_login',
      formGroupSelector: '.nice-form-group',
      rules: [
        Validator.isRequired('input[name=user_code]', 'Please input your full name'),
      ],
      onSubmit: async function (data: any) {
        _that.DOMServiceService.onloading('.btn_resetPwd')
        _that.authen.resetPW(data).subscribe(
            data => {
              console.log(data)
              if (data.status) {
                _that.showFormLogin()
                let msg = "New password was sent to your email!"
                _that.DOMServiceService.showAlertMassage(msg, true)
              } else {
                let msg = "Reset PW fail, Your code is not correct or you dont have DMS account!"
                _that.DOMServiceService.showAlertMassage(msg, false)
                
              }
              this.DOMServiceService.onloaded('.btn_resetPwd')
            },
            error => {
              this.massage = "System Erorr!"
              this.DOMServiceService.onloaded('.btn_resetPW')
            }
        )
      }
    });
  }

  submitCreateAcount() {
    let _that = this
   
    Validator({
      form: '#form_login',
      formGroupSelector: '.nice-form-group',
      rules: [
        Validator.isRequired('input[name=user_code]'),
        Validator.minLength('input[name=user_code]',6),
        Validator.isRequired('input[name=password]'),
        Validator.minLength('input[name=password]',6),
        Validator.isRequired('input[name=user_name]'),
        Validator.isEmail('input[name=email]'),
        Validator.isRequired('select[name=dept_id]'),
        Validator.isRequired('select[name=grade_id]'),
      ],
      onSubmit: async function (data: any) {
        _that.DOMServiceService.onloading('.btn_create')
        console.log(data)
        _that.authen.createNewAccount(data).subscribe(
            data => {
             
              if (data.status) {
                _that.showFormLogin()
                _that.DOMServiceService.showAlertMassage(data.msg, true)
              } else {
                _that.DOMServiceService.showAlertMassage(data.msg, false)
                
              }
              _that.DOMServiceService.onloaded('.btn_create')
            },
            error => {
               this.massage = "System Erorr!"
              _that.DOMServiceService.onloaded('.btn_create')
            }

        )
        
      }

    });
  }
}
