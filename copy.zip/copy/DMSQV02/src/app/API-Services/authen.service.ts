import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { HttpClient, HttpHeaders, HttpParams, HttpErrorResponse } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { Router, UrlTree } from '@angular/router';
import { post } from 'jquery';

@Injectable({
  providedIn: 'root'
})

export class AuthenService {

  constructor(private http: HttpClient) { }
  private apiAuthenURL = 'http://localhost:5019/authen';
  private handleError(error: HttpErrorResponse) {
    if (error.status === 0) {
      // Lỗi phía client hoặc lỗi mạng
      console.error('An error occurred:', error.error);
    } else if (error.status === 404) {
      // Lỗi 404 - Không tìm thấy
      console.error('Not Found:', error.message);
    } else {
      // Các lỗi khác từ server
      console.error(`Backend returned code ${error.status}, body was: `, error.error);
    }
    // Trả về một observable với thông báo lỗi thân thiện với người dùng
    return throwError(() => new Error('Something bad happened; please try again later.'));
  }

  private convertToFormData(data:any): FormData{
    let formData = new FormData()
    for (let key in data) {

      if (data.hasOwnProperty(key)) {
        formData.append(key, data[key]);
      }
    }
    return formData
  }


  login(data: any): Observable<any> {

    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    let formData = this.convertToFormData(data)
    return this.http.post<any>(this.apiAuthenURL + '/api_login', formData, { withCredentials: true }).pipe(
      catchError(this.handleError)
    );
  }

  logout() {
    localStorage.removeItem("user")
    return this.http.get<any>(this.apiAuthenURL + '/api_logout', { withCredentials: true }).pipe(
      catchError(this.handleError)
    );
  }

  isLoginedAndUserProfile(): Observable<{ status: boolean, user: any }> {
    // nếu đã login thì trả về user profile, nếu chưa login thì trả về false
    return this.http.get<{ status: boolean, user: any }>(this.apiAuthenURL + '/api_isLoginAndReturnUserProfile', { withCredentials: true }).pipe(
      catchError(this.handleError)
    );
  }

  isLogined(): { status: boolean, user: any } {
    let json_user = localStorage.getItem("user")
    if (json_user) {
      return {
        status: true,
        user: JSON.parse(json_user)
      }
    } else {
      return {
        status: false,
        user: null
      }
    }
  }

  resetPW(data:any): Observable<any> {
    let formData = this.convertToFormData(data)
    return this.http.post<any>(this.apiAuthenURL + '/api_resetPW', formData, { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }

  createNewAccount(data:any):Observable<any>{
    let formData = this.convertToFormData(data);
    return this.http.post<any>(this.apiAuthenURL + '/api_createNewAccount', formData, { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }

  changeUserProfile(data:any):Observable<any>{
    let formData = this.convertToFormData(data);
    return this.http.post<any>(this.apiAuthenURL + '/api_changeUserProfile', formData, {withCredentials: true}).pipe(
      catchError(this.handleError)
    )
  }
}
