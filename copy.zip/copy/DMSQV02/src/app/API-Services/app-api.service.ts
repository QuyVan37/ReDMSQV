import { Injectable } from '@angular/core';
import { Observable , throwError} from 'rxjs';
import { HttpClient, HttpHeaders, HttpParams,HttpErrorResponse  } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { Router , UrlTree} from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AppAPIService {

  constructor(private http: HttpClient) { }
  private apiCommonUrl = 'http://localhost:5019/commonAPI';

  getGradeCategory():Observable<{rowEffected: number, data: any[]}> {
    return this.http.get<{rowEffected: number, data: any[]}>(this.apiCommonUrl + '/api_DMSGradeCategory', { withCredentials: true })
  }

  getRolesCategory():Observable<{rowEffected: number, data: any[]}> {
    return this.http.get<{rowEffected: number, data: any[]}>(this.apiCommonUrl + '/api_DMSRoleCategory', { withCredentials: true })
  }

  getListDept():Observable<{rowEffected: number, data: any[]}> {
    return this.http.get<{rowEffected: number, data: any[]}>(this.apiCommonUrl + '/api_GetListDept', { withCredentials: true })
  }







}
