﻿using Microsoft.AspNetCore.Mvc;

namespace DMSQV_API.Controllers
{
    public class SendEmail : Controller
    {
        // chú ý: Mail của function nào thì chỉ gửi cho user có role >=3 của function đó
        public void systemSendEmail(string to, string subject, string body)
        {

        }

        public void sendEmailResetPW(string to, string newPW)
        {
            
        }

        public void sendEmailVerifiedUsers(int user_id)
        { 

        }

        public void sendEmailTPIProgress(string tpi_id)
        {
            //Theo belog
            //1. CRG => Chỉ gửi cho PUR và CRG
            //2. Inhouse => 
                // => gửi Inhouse nếu chỉ có INhouse
                // => Gửi cho PE1 nếu có cả PE1
            //3. LBP => gửi cho PUR/PAE/PE1
            //4. OTHER => gửi cho PE1
            //5. Khi status_id mà là "close, W-MR,W-PO,W-FA,Reject,Cancel"
                //Nếu PUR chưa confirm => gửi mail tới PUR
                //Nếu PUR đã confirm => gửi mail tới RPA
        }
        public void sendEmailTPIToRPA()
        {

        }

    }
}
