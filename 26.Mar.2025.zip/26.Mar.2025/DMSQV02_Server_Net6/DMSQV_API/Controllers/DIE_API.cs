﻿using DMSQV_API.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Text;
using static DMSQV_API.Controllers.CommonFunction;
using static DMSQV_API.Data.DBConnector;

namespace DMSQV_API.Controllers
{

    public class DIE_API : Controller
    {
        DBConnector db = new DBConnector();
        Authen authen = new Authen();
        CommonFunction commonFunction = new CommonFunction();
        WorkInExcel workInExcel = new WorkInExcel();
        public JsonResult api_getDieList(string search, string? supplier_id, string? model_id, string die_classify, string progress, int? page = 1, int? pageSize = 50)
        {
            search = search?.Trim();
            bool status = false;
            string msg = "";
            var islogin = authen.isLoginAndReturnUserProfile(HttpContext);

            dataReturn data = new dataReturn();
            if (islogin.status)
            {
                data = db.getDieList(search, supplier_id, model_id, die_classify, progress, page, pageSize);
                status = true;
            }
            else
            {
                msg = "Please login!";
                status = false;
            }


        exit:
            var output = new
            {
                status = status,
                msg = msg,
                recordsTotal = data.totalCount,
                recordsFiltered = data.totalCount,
                page = page,
                pageSize = pageSize,
                Data = data.data,
            };
            return Json(output);
        }

        public JsonResult api_addNewDieByExcel(IFormFile file_add_die_Excel)
        {
            var islogin = authen.isLoginAndReturnUserProfile(HttpContext);
            string msg = "";
            List<string> listFail = new List<string>();
            int success = 0;
            int fail = 0;
            if (!islogin.status)
            {
                msg = "Please login!";
                goto exit;
            }
            bool isPermit = islogin.dataUsers.Any(e => new[] { 3, 4, 5, 6 }.Contains(e.die_role_id));
            if (isPermit == false)
            {
                msg = "You do not have permision!";
                goto exit;
            }
            if (file_add_die_Excel == null)
            {
                msg = "No file upload!";
                goto exit;
            }
            var data = workInExcel.readListExcelFile(file_add_die_Excel, 3, 5);
            if (data.status == false)
            {
                msg = data.msg;
                goto exit;
            }

            var processCodeID = "";
            var modeID = "";
            var supplierID = "";
            foreach (var item in data.data)
            {
                processCodeID = db.ExcuteQueryAndGetData($"SELECT  CASE   WHEN EXISTS (SELECT proces_id FROM die_process_code_category WHERE type ILIKE '%{item["Process_code"].ToString()}%')  THEN (SELECT proces_id FROM die_process_code_category WHERE type ILIKE '%{item["Process_code"].ToString()}%' LIMIT 1)  ELSE 1 END AS proces_id;").data[0]["proces_id"].ToString();
                modeID = commonFunction.createModel(item["Model"].ToString()).ToString();
                supplierID = db.ExcuteQueryAndGetData($"SELECT  CASE   WHEN EXISTS (SELECT supplier_id FROM suppliers WHERE supplier_code ILIKE '%{item["Supplier_code"].ToString()}%' OR supplier_name ILIKE '%{item["Supplier_code"].ToString()}%' )  THEN (SELECT supplier_id FROM suppliers WHERE supplier_code ILIKE '%{item["Supplier_code"].ToString()}%' OR supplier_name ILIKE '%{item["Supplier_code"].ToString()}%' LIMIT 1)   ELSE 0  END AS supplier_id;").data[0]["supplier_id"].ToString();
                var resultAddNewDie = api_AddNewDie(item["Part_No"].ToString(), item["Die_code"].ToString(), processCodeID, modeID, supplierID, item["Target_OK_Date"].ToString());
                if (resultAddNewDie.status == false)
                {
                    listFail.Add($"Error update: {item["Part_No"].ToString()}-{item["Die_code"].ToString()} => {resultAddNewDie.msg}");
                    fail++;
                }
                else
                {
                    success++;
                }
            }


        exit:
            var output = new
            {
                fail = fail,
                success = success,
                listFail = listFail,
                msg = msg
            };
            return Json(output);
        }
        public jsonResult api_AddNewDie(string? part_no, string? die_code, string? process_id, string? model_id, string? supplier_id, string? target_ok)
        {

            bool status = false;
            string msg = "";
            var islogin = authen.isLoginAndReturnUserProfile(HttpContext);

            dataReturn data = new dataReturn();
            if (islogin.status)
            {
                bool isPermit = islogin.dataUsers.Any(e => new[] { 3, 4, 5, 6 }.Contains(e.die_role_id));
                if (isPermit == false)
                {
                    msg = "You do not have permision!";
                    goto exit;
                }
                var arrayParameter = new[] { part_no, die_code, process_id, model_id, supplier_id };
                bool isPass = commonFunction.checkArrayHasAnyElementNullOrEmpty(arrayParameter);
                part_no = part_no.Replace(" ", "").Trim().ToUpper();
                part_no = part_no.Length == 8 ? $"{part_no}-000" : (part_no.Length > 12 ? part_no.Substring(0, 12) : part_no.PadRight(12, '0'));
                die_code = die_code.Replace(" ", "").Trim().ToUpper();
                if (part_no.Length != 12 && die_code.Length != 3)
                {
                    status = false;
                    msg = (part_no.Length != 12 ? "Part No must be 12 kí tự " : "") + (die_code.Length != 3 ? "Die code must be 3 kí tự " : "");
                    goto exit;
                }
                if (isPass)
                {
                    status = false;
                    msg = "Please input information before submit";
                    goto exit;
                }

                // ADD DIE KHI MỌI THỨ ĐÃ OK
                DateTime out_targetOK = DateTime.Today.AddDays(120);
                DateTime.TryParse(target_ok, out out_targetOK);
                manualINPUTDieInfor newDieInfor = new manualINPUTDieInfor()
                {
                    partNo = part_no,
                    dieCode = die_code,
                    processCodeID = int.Parse(process_id),
                    modelID = int.Parse(model_id),
                    supplierID = int.Parse(supplier_id),
                    targetOK = out_targetOK,
                };
                var result = commonFunction.genarateAndUpdateNEWDIE(newDieInfor, null, null, HttpContext);

                status = result[0].status;
                msg = result[0].msg;
            }
            else
            {
                msg = "Please login!";
                status = false;
            }

        exit:
            jsonResult output = new jsonResult
            {
                status = status,
                msg = msg,
            };
            return output;

        }




        public JsonResult api_getDieDetail(int id)
        {
            bool status = false;
            string msg = "";
            string sqlGetDieInfor = $"SELECT die_id, fixed_asset_no, dieno, d.model_id as model, die_maker, d.supplier_id as supplier, die_classify, mc_size, cav_quantity, cycle_time_sec, cycle_time_targetasdsum, die_cost_usd, die_make_location, special_spec, texture, texture_type, core_cav_material, slider_material, lifter_material, gate_type, hot_runner, lead_time_make_die, po_date, start_use, die_warranty_short, warranty_shot_as_dsum, pae_target_short, is_stacking, is_shaft_kashime, is_burring_kashime, spm_progressive, spm_single, pxno_of_component, pxno_of_state, puch_holder, punch_backing_plate, punch_plate, punch, insert_block, stripper_backing_plate, stripper_plate, die_plate, die_backing_plate, die_holder, geta_plate, sub_plate, belong, genaral_information, target_ok_date, family_die_with, common_part_with, no_of_q, no_of_c, no_of_d, jig_using, is_new_master_gear, t0_plan, t0_actual, t0_result, t0_solve_method, texture_meeting_date, texture_go_date, s0_plan, s0_result, s0_solve_method, texture_app_date, texture_jp_hp_app_result, texture_note, prekk_plan, prekk_result, fa_sub_time, fa_plan, fa_result, fa_result_date, fa_problem, fa_action_improve, first_lot_date, is_official, short, record_date, inventory_status, remark_die_status_using, stop_date, supplier_proposal, reason_proposal, s.type as die_status_id, pr.type as process, model_name as model_id, supplier_code as supplier_id, supplier_name, progress, chk.die_check_result as die_check_result_id, d.check_review_date " +
                                    $" FROM dies d " +
                                    $"INNER JOIN die_status_category s ON s.die_status_id = d.die_status_id  " +
                                    $"INNER JOIN die_process_code_category pr ON pr.proces_id = d.process_code_id  " +
                                    $"INNER JOIN models m ON m.model_id = d.model_id  " +
                                    $"INNER JOIN suppliers spl ON spl.supplier_id = d.supplier_id " +
                                    $"LEFT JOIN die_check_result_category chk ON chk.die_check_result_id = d.die_check_result_id " +
                                    $"WHERE die_id = {id}";
            var dieInfo = db.ExcuteQueryAndGetData(sqlGetDieInfor).data[0];
            string sqlGetTPI = $"SELECT tpi_id, tpi.trouble_name, tpi_no, s.status_type, po.type as po_code FROM tpi " +
                               $"INNER JOIN tpi_status_category s ON s.tpi_status_id = tpi.tpi_status_id  " +
                               $"LEFT JOIN tpi_po_code po ON po.tpi_po_code_id = tpi.tpi_po_code_id  " +
                               $"WHERE die_id = {id} AND (tpi.active is null OR tpi.active = true) ";
            var tpi = db.ExcuteQueryAndGetData(sqlGetTPI).data;
            string sqlGetDFM = $"SELECT  dsum.dfm_id, dsum.dsum_no, s.status FROM DSUM " +
                                $"INNER JOIN attachment att ON DSUM.dfm_id = att.dsum_id  " +
                                $"INNER JOIN dsum_status_category s ON s.dsum_status_id = DSUM.dsum_status_id  " +
                                $"WHERE DSUM.die_id = {id} AND ((att.clasify ilike '%PAE%' AND att.clasify ilike '%APPROVE%') OR att.clasify ilike '%FINISH%')  " +
                                $"AND (dsum.active = true OR dsum.active is null)  " +
                                $"AND DSUM.dsum_status_id not in (11,12)";

            var dsum = db.ExcuteQueryAndGetData(sqlGetDFM).data;
            string sqlGetMR = $"SELECT mr_id, mr_no,  mr.app_cost_exchange_usd as cost, s.type as status, t.type as mr_type  FROM mr  " +
                              $"LEFT JOIN dies d ON d.dieno = mr.die_no  " +
                              $"JOIN mr_status_category s ON s.mr_status_id = mr.status_id  " +
                              $"JOIN mr_type_category t ON t.mr_type_id = mr.type_id  " +
                              $"WHERE d.die_id = {id} AND (mr.is_active = true OR mr.is_active is null) AND mr.status_id not in (11,12)";
            var mrs = db.ExcuteQueryAndGetData(sqlGetMR).data;
            string sqlGetCommonPart = $"SELECT common_id, p.part_no, p.part_name, p.material||'['||p.grade_mat||']' as material, is_common_part, is_family_die FROM common_die c " +
                                      $"JOIN parts p ON c.part_id = p.part_id  " +
                                      $"WHERE die_id= {id}";
            var common = db.ExcuteQueryAndGetData(sqlGetCommonPart).data;

            string sqlGetTransfer = $"SELECT dtf_no, s.status, old_spl.supplier_code as current_location, new_spl.supplier_code as new_location, dtf.shot  From dtf   " +
                                    $"INNER JOIN dies d ON d.dieno = dtf.die_no   " +
                                    $"INNER JOIN dtf_status_category s ON s.dtf_status_id = dtf.dtf_status_id  " +
                                    $"INNER JOIN suppliers old_spl ON old_spl.supplier_id = dtf.current_location_id  " +
                                    $"INNER JOIN suppliers new_spl ON new_spl.supplier_id = dtf.new_location_id " +
                                    $"WHERE d.die_id = {id} AND (dtf.is_active = true OR dtf.is_active is null)";

            var transfers = db.ExcuteQueryAndGetData(sqlGetTransfer).data;
            string sqlGetDisposal = $"SELECT dis_no,dcs.decision, dps.is_refer_die, dps.physical_dispose_date  FROM dispose_verify_detail dps  " +
                                    $"LEFT JOIN dispose_decision_category dcs ON dcs.decision_id = dps.final_decision_id  " +
                                    $"INNER JOIN dies d ON d.dieno = dps.die_no  " +
                                    $"WHERE d.die_id = {id}";
            var disposal = db.ExcuteQueryAndGetData(sqlGetDisposal).data;

            string sqlDIESCORE = $"SELECT * FROM genarate_die_score({id})";
            var dieScore = db.ExcuteQueryAndGetData(sqlDIESCORE).data;
            var sqlAllAttachment = $"SELECT * from attachment WHERE die_id = {id} AND dsum_id IS NULL";
            var attachment = db.ExcuteQueryAndGetData(sqlAllAttachment).data;

            List<object> Mid_ps = new List<object>();

            foreach (var part in common)
            {
                string sqlGetMidPS = $"SELECT * FROM Mid_PS Where partno = '{part["part_no"]}'";
                var ps2 = db.ExcuteQueryAndGetData(sqlGetMidPS).data;
                if (ps2.Count > 0)
                {
                    Mid_ps.Add(ps2[0]);
                }
            }

            var output = new
            {
                dieInfo = dieInfo,
                common = common,
                tpi = tpi,
                dsum = dsum,
                mrs = mrs,
                transfers = transfers,
                disposal = disposal,
                mid_ps = Mid_ps,
                attachment = attachment,
                dieScore = dieScore
            };
            return Json(output);
        }

        public JsonResult api_searchPartNo(string search)
        {
            search = search?.Trim();
            bool status = false;
            string msg = "";
            var islogin = authen.isLoginAndReturnUserProfile(HttpContext);

            dataReturn data = new dataReturn();
            if (islogin.status)
            {
                data = db.getDieBySearchPartNo(search);
                status = true;
            }
            else
            {
                msg = "Please login!";
                status = false;
            }

            return Json(data);
        }


        public JsonResult api_updateDieInfo(string die_id, string name, string newValue, IFormFile fileDieCheckReport)
        {

            bool status = false;
            string msg = "";
            string progress = "";
            var islogin = authen.isLoginAndReturnUserProfile(HttpContext);

            if (islogin.status)
            {
                bool isPermit = islogin.dataUsers.Any(e => new[] { 3, 4, 5, 6 }.Contains(e.die_role_id));
                if (isPermit)
                {
                    string subsql = "";
                    // defaul 
                    subsql = $"{name} = '{newValue}' ";

                    if (name == "die_check_result_id")
                    {
                        string sub2Q = "";
                        if (fileDieCheckReport != null && !String.IsNullOrEmpty(newValue))
                        {
                            // LUU vào Attachement table
                            commonFunction.SaveAttachment(int.Parse(die_id), null, fileDieCheckReport, "Check_Die_Renew_Report", "/File/Attachment/Die/", "Check_Die_Report", islogin.dataUsers[0].user_name);
                        }

                        subsql = $"{name} = '{newValue}', check_review_date = '{DateTime.Now}' " + sub2Q;
                    }
                    if (name == "genaral_information")
                    {
                        subsql = $" {name} = CONCAT_WS(CHR(10),'{newValue}' ,dies.genaral_information) ";
                    }


                    string sqlUpdate = $"UPDATE dies " +
                                       $"SET  " +
                                      subsql +
                                       $"WHERE die_id = '{die_id}' ";

                    try
                    {
                        db.ExcuteQueryAndGetData(sqlUpdate);
                        progress = db.ExcuteQueryAndGetData($"SELECT progress FROM dies WHERE die_id = {die_id}").data[0]["progress"].ToString();
                        status = true;

                    }
                    catch
                    {
                        msg = "can not save!";
                        status = false;
                    }

                }
                else
                {
                    msg = "you do not have permision!";
                }

            }
            else
            {
                msg = "Please login!";

            }

            var result = new
            {
                msg = msg,
                status = status,
                progress = progress
            };


            return Json(result);
        }


        public JsonResult api_addDieAttachment(string die_id, string clasify, IFormFile[] die_attachment)
        {

            bool status = false;
            string msg = "";
            var islogin = authen.isLoginAndReturnUserProfile(HttpContext);

            if (islogin.status)
            {
                bool isPermit = islogin.dataUsers.Any(e => new[] { 3, 4, 5, 6 }.Contains(e.die_role_id));
                if (isPermit)
                {
                    // LUU vào Attachement table
                    foreach (var file in die_attachment)
                    {
                        commonFunction.SaveAttachment(int.Parse(die_id), null, file, clasify, "/File/Attachment/Die/", file.FileName, islogin.dataUsers[0].user_name);

                    }
                    status = true;
                }
                else
                {
                    msg = "you do not have permision!";
                }

            }
            else
            {
                msg = "Please login!";

            }

            var result = new
            {
                msg = msg,
                status = status,
            };


            return Json(result);
        }
        public JsonResult api_getSumaryDieProgress()
        {
            string sql = $"SELECT * FROM sumarize_die_progress()";
            var data = db.ExcuteQueryAndGetData(sql).data;
            var output = new
            {
                data = data
            };
            return Json(output);
        }

        public JsonResult api_add_editCommon(string die_id, string part_no, string is_common_part, string is_family_die, string common_id, string isDeleteCommon, string isDeleteDie)
        {
            bool status = false;
            string msg = "Do not thing!";
            var islogin = authen.isLoginAndReturnUserProfile(HttpContext);
            bool cvert_result = false;
            bool is_common_part_cvert;
            bool is_family_die_cvert;
            cvert_result = bool.TryParse(is_common_part, out is_common_part_cvert);
            cvert_result = bool.TryParse(is_family_die, out is_family_die_cvert);
            dataReturn data = new dataReturn();
            if (islogin.status)
            {
                bool isPermit = islogin.dataUsers.Any(e => new[] { 6 }.Contains(e.die_role_id));
                if (isPermit == false)
                {
                    msg = "Only Admin Role can add/edit/delete!";
                    status = false;
                    goto exit;
                }
                // add common
                if (!String.IsNullOrWhiteSpace(die_id) && !String.IsNullOrWhiteSpace(part_no))
                {
                    int part_id = commonFunction.AddOrUpdatePART(part_no, null, null);
                    int dieID = int.Parse(die_id);

                    int re_commonID = commonFunction.AddOrUpdateCOMMONTABLE(part_id, dieID, "Manual Add Common", is_common_part_cvert, is_family_die_cvert);
                    if (re_commonID > 0)
                    {
                        status = true;
                        msg = "Add Common/Family success";
                        goto exit;
                    }
                }
                // edit 
                if (!String.IsNullOrEmpty(common_id) && isDeleteCommon == null)
                {
                    string subSQL = "";
                    if (is_family_die != null)
                    {
                        subSQL += $"is_family_die = '{is_family_die_cvert}' ";
                    }
                    if (is_common_part != null)
                    {
                        subSQL += $"is_common_part = '{is_common_part_cvert}' ";
                    }

                    string sqlUpdateCommon = $"UPDATE common_die   " +
                        $"SET  " + subSQL +
                        $"WHERE common_id = {common_id}";

                    db.ExcuteQueryAndGetData(sqlUpdateCommon);
                    status = true;
                    msg = "Update sucess!";
                }
                // delete common
                if (isDeleteCommon != null && !String.IsNullOrEmpty(common_id))
                {
                    string sqlCheckQtyOfCommon = $"SELECT Count(*) from common_die  " +
                                                $"where die_id in (Select die_id from common_die c1 where c1.common_id = {common_id})";
                    int qtyOfCommon = int.Parse(db.ExcuteQueryAndGetData(sqlCheckQtyOfCommon).data[0]["count"].ToString());
                    if (qtyOfCommon > 1)
                    {
                        string sqlDeleteCommon = $"Delete from common_die where common_id = {common_id}";
                        db.ExcuteQueryAndGetData(sqlDeleteCommon);
                        status = true;
                        msg = "Delete the common/family relationship!";
                    }
                    else
                    {
                        status = false;
                        msg = "You can not delete when list common/faminly just exist 1";
                    }
                }

                // delete die
                if (isDeleteDie != null && !String.IsNullOrEmpty(die_id))
                {
                    string sqlCheckQtyOfCommon = $"UPDATE dies " +
                                                 $"SET is_active= 'false' " +
                                                $"where die_id = {die_id}";
                    db.ExcuteQueryAndGetData(sqlCheckQtyOfCommon);
                    status = true;
                    msg = "Success Delete Die ";
                    goto exit;
                }
            }
            else
            {
                msg = "Please login!";
                status = false;
            }

        exit:
            var result = new
            {
                status = status,
                msg = msg
            };
            return Json(result);
        }


    }
}
