﻿using DMSQV_API.Data;
using Microsoft.AspNetCore.Mvc;

namespace DMSQV_API.Controllers
{
    public class CommonAPI : Controller
    {
        DBConnector db = new DBConnector();
        public JsonResult api_DMSGradeCategory()
        {
            var result = db.getDMSGradeCatergory();
            return Json(result);
        }

        public JsonResult api_DMSRoleCategory()
        {
            var result = db.getDMSRoleCatergory();
            return Json(result);
        }

        public JsonResult api_GetListDept()
        {
            var result = db.getListDept();
            return Json(result);
        }

        public JsonResult api_GetMRTypeCategory()
        {
            var result = db.getMRTypeCategory();
            return Json(result);
        }

        public JsonResult api_GetSupplierList()
        {
            var result = db.getSupplierList();
            return Json(result);
        }
        public JsonResult api_GetProcessCodeCategory()
        {
            var result = db.getListProcessCode();
            return Json(result);
        }


        // add 28.Sept.2024
        public JsonResult api_GetModelList()
        {
            var result = db.getModelList();
            return Json(result);
        }
        public JsonResult api_GetBudgetCodeList()
        {
            var result = db.getBudgetCodeList();
            return Json(result);
        }

        public JsonResult api_getTPIRelatedDieNo(string dieNo)
        {
            var result = db.getTPIRelatedDieNo(dieNo);
            return Json(result);
        }

        public JsonResult api_getDFMRelatedDieNo(string dieNo)
        {
            var result = db.getDFMRelatedDieNo(dieNo);
            return Json(result);
        }

        public JsonResult api_checkDieExist(string dieNo)
        {
            bool isExist = db.isExistDie(dieNo).data.Count() > 0;
            var result = new
            {
                status = isExist,
                msg = isExist == false ? $"Die {dieNo} is not yet issue PO or Disposed or Cancel or Not Exist" : ""
            };
            return Json(result);
        }
        public JsonResult api_GetListProcessCode()
        {
            var result = db.getListProcessCode();
            return Json(result);
        }
        public JsonResult api_GetDieStatusCategory()
        {
            var result = db.getDieStatusCategory();
            return Json(result);
        }

        public JsonResult api_GetDieCheckResultCategory()
        {
            var result = db.getDieCheckResultCategory();
            return Json(result);
        }

        public JsonResult api_getTPITypeCategory()
        {
            var result = db.getTPITypeCategory();
            return Json(result);
        }

        public JsonResult api_getTPITroubleAreasCategory()
        {
            var result = db.getTPITroubleAreasCategory();
            return Json(result);
        }

        public JsonResult api_getTPIRootCauseCategory()
        {
            var result = db.getTPIRootCauseCategory();
            return Json(result);
        }

        public JsonResult api_getTPIPOCodeCategory()
        {
            var result = db.getTPIPOCodeCategory();
            return Json(result);
        }

        public JsonResult api_getTPICMCategory()
        {
            var result = db.getTPICMCategory();
            return Json(result);
        }

        public JsonResult api_getRenewDecisionCategory()
        {
            var result = db.getRenewDecisionCategory();
            return Json(result);
        }

        public JsonResult api_getExchangeRete()
        {
            string sql = $"SELECT * FROM exchange_rate ORDER BY update_Date DESC LIMIT 1";
            var result = db.ExcuteQueryAndGetData(sql);
            return Json(result);
        }

        public JsonResult api_getDTFTypeList()
        {
            string sql = $"select * from dtf_type_category";
            var result = db.ExcuteQueryAndGetData(sql);
            return Json(result);
        }




    }
}
