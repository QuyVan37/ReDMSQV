﻿using DMSQV_API.Data;
using Microsoft.AspNetCore.Mvc;
using static DMSQV_API.Data.DBConnector;

namespace DMSQV_API.Controllers
{
    public class MASTER_API : Controller
    {
        DBConnector db = new DBConnector();
        Authen authen = new Authen();
        CommonFunction commonFunction = new CommonFunction();
        WorkInExcel workInExcel = new WorkInExcel();
        public JsonResult api_getMasterList(string table, string search, int? page = 1, int? pageSize = 50)
        {
            search = search?.Trim();
            bool status = false;
            string msg = "";
            var islogin = authen.isLoginAndReturnUserProfile(HttpContext);

            dataReturn data = new dataReturn();
            if (islogin.status)
            {
                data = db.getMASTERList(search, table, page, pageSize);
                status = true;
            }
            else
            {
                msg = "Please login!";
                status = false;
            }
        exit:
            var output = new
            {
                status = status,
                msg = msg,
                recordsTotal = data.totalCount,
                recordsFiltered = data.totalCount,
                page = page,
                pageSize = pageSize,
                Data = data.data,
            };
            return Json(output);
        }
    }
}
