﻿using Aspose.Cells;
using DMSQV_API.Data;
using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using SkiaSharp;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Xml.Linq;
using static DMSQV_API.Controllers.CommonFunction;
using static DMSQV_API.Data.DBConnector;


namespace DMSQV_API.Controllers
{
    public class DSUM_API : Controller
    {
        DBConnector db = new DBConnector();
        Authen authen = new Authen();
        CommonFunction commonFunction = new CommonFunction();
        WorkInExcel workInExcel = new WorkInExcel();
        DateTime applyDate = new DateTime(2023, 12, 13);
        public JsonResult api_getSumarizeDSUMPending()
        {
            var result = db.getSumarizeDSUMPending();
            return Json(result);
        }

        public JsonResult api_getDSUMList(string search, string? supplier_id, string? model_id, int? page = 1, int? pageSize = 50)
        {
            search = search?.Trim();
            bool status = false;
            string msg = "";
            var islogin = authen.isLoginAndReturnUserProfile(HttpContext);

            dataReturn data = new dataReturn();
            if (islogin.status)
            {
                data = db.getDSUMList(search, supplier_id, model_id, page, pageSize);
                status = true;
            }
            else
            {
                msg = "Please login!";
                status = false;
            }


        exit:
            var output = new
            {
                status = status,
                msg = msg,
                recordsTotal = data.totalCount,
                recordsFiltered = data.totalCount,
                page = page,
                pageSize = pageSize,
                Data = data.data,
            };
            return Json(output);
        }


        public JsonResult api_issueDSUM(string part_no, string die_code, IFormFile file_cover, IFormFile file_content)
        {
            bool status = false;
            string msg = "";
            var today = DateTime.Now;
            // kiểm tra user
            var userLogin = authen.isLoginAndReturnUserProfile(HttpContext);
            if (!userLogin.status)
            {
                status = false;
                msg = "Please login in!";
                goto exit;
            }

            bool isPermit = userLogin.dataUsers.Any(e => new[] { 3, 4, 5, 6 }.Contains(e.dsum_role_id));
            if (!isPermit)
            {
                status = false;
                msg = "You do not have permition!";
                goto exit;
            }


            //Kiểm tra form
            var verifyFormResult = workInExcel.verifyFormCoverPageDSUM(file_cover, part_no, null, true);
            if (!verifyFormResult.isPass)
            {
                status = false;
                msg = verifyFormResult.msg;
                goto exit;
            }
            //kiểm tra DSUM tồn tại chưa
            string[] listRawPartNo = part_no.Split(',');
            List<string> listPartNo = new List<string>();
            string listDieIDs = "";
            foreach (var raw_part in listRawPartNo)
            {
                string part = raw_part.Replace(" ", "").Trim();
                if (part.Length >= 8)
                {
                    part = part.Length == 8 ? $"{part}-000" : (part.Length > 12 ? part.Substring(0, 12) : part.PadRight(12, '0'));
                    listPartNo.Add(part);
                    string dieNo = $"{part}-{die_code}-001";
                    string sqlFinDie = $"SELECT string_agg(d.die_ID::TEXT, ',') AS dieids  " +
                                       $"FROM dies d  " +
                                       $"JOIN common_die c ON d.die_ID = c.die_ID  " +
                                       $"JOIN parts p ON p.part_id = c.part_id  " +
                                       $"WHERE p.part_no = '{part}' AND d.die_code = '{die_code}';";
                    var r = db.ExcuteQueryAndGetData(sqlFinDie).data;
                    if (r.Count > 0)
                    {
                        listDieIDs = listDieIDs + "," + r[0]["dieids"].ToString();
                    }
                }
            }

            string[] dieIDs = listDieIDs.Split(',').Where(d => !string.IsNullOrEmpty(d)).Distinct().ToArray(); ;
            // check xem cos dieID nay trong DSUM chua
            if (dieIDs.Length == 0)
            {
                status = false;
                msg = "This die not exist in [Die]! Plz re-Check PartNo, DieNo is correct or not?. If it correct plz go to [Die] and click [Add New] ";
                goto exit;
            }
            foreach (var dieID in dieIDs)
            {
                string sqlCheckExistDSUM = $"SELECT * FROM dsum WHERE die_id = '{dieID}' AND part_no = '{listPartNo[0]}'";
                var isExistDSUM = db.ExcuteQueryAndGetData(sqlCheckExistDSUM);
                if (isExistDSUM.data.Count > 0)
                {
                    status = false;
                    msg = $"This DSUM already exist! It was submited by {isExistDSUM.data[0]["submit_by"]} on {isExistDSUM.data[0]["submit_date"].ToString()}";
                    goto exit;
                }
            }

            // xử lí file content vào cover page và Luu file
            // Open an existing workbook
            string pathFolder = "/File/Attachment/DFM/";
            string fileCoverPageName = $"DFM_Sub-{listPartNo[0]}-{die_code}";
            string fileContentName = $"DFM_Content-{listPartNo[0]}-{die_code}";
            string pathCover = commonFunction.savePhysicalFileOnServer(file_cover, pathFolder, fileCoverPageName);
            string pathFullFileCover = commonFunction.currentURLHost + pathCover;
            string pathFullFileContent = commonFunction.currentURLHost + commonFunction.savePhysicalFileOnServer(file_content, pathFolder, fileContentName);
            string pathFullFileIcon = commonFunction.currentURLHost + pathFolder + "icon.png";

            try
            {
                // Đọc file biểu tượng vào mảng byte
                byte[] iconBytes = System.IO.File.ReadAllBytes(pathFullFileIcon);

                // Đọc file nội dung (DFM) vào mảng byte
                byte[] embeddedFileBytes = System.IO.File.ReadAllBytes(pathFullFileContent);

                // Mở workbook và truy cập worksheet đầu tiên
                using (Workbook workbook = new Workbook(pathFullFileCover))
                {
                    Worksheet worksheet = GetWorksheet(workbook, new[]
                    {
                    "Att-01_ver7__Mo_(Update size)",
                    "Att-02_ver8__PX_(Official)",
                    "Att-02_ver7__PX_(Official)",
                    "MO"
                });

                    if (worksheet == null)
                    {
                        throw new Exception("Không tìm thấy bảng tính hợp lệ trong file Excel.");
                    }

                    // Thêm đối tượng OLE
                    worksheet.Shapes.AddOleObject(36, 0, 10, 0, 150, 300, iconBytes);

                    // Gắn dữ liệu file DFM và hiển thị dưới dạng biểu tượng
                    worksheet.OleObjects[0].ObjectData = embeddedFileBytes;
                    worksheet.OleObjects[0].DisplayAsIcon = true;

                    // Lưu workbook đã chỉnh sửa
                    workbook.Save(pathFullFileCover);
                    Console.WriteLine("Tệp đã được nhúng thành công và lưu workbook.");
                    deleteWorksheetLisence(pathFullFileCover);
                    commonFunction.DeletePhysicalFileOnServer(pathFullFileContent);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Lỗi: {ex.Message}");
            }

            // update Cover page => lastest version
            bool isSuccessSignature = false;
            string controlLatestVersion = "By " + userLogin.dataUsers[0].user_name + "_" + today.ToString("yyyy/MM/dd HH:mm:ss tt");

            isSuccessSignature = GetSignatureAndSaveCoverPage(pathFullFileCover, 1, userLogin.dataUsers[0].user_name, false, true, "", controlLatestVersion, false, null, die_code);
            if (isSuccessSignature == false)
            {
                status = false;
                msg = "Canot save cover page!";
                goto exit;
            }


            //Lưu database 
            // luu attachement

            string sqlSave = $"INSERT INTO public.dsum(die_id, dsum_status_id, dsum_no, submit_by, submit_date, create_date, active, control_lastest_dfm, part_no)  " +
                             $"VALUES ('{dieIDs[0]}', 1, '{genarateDSUMNo("", true, false)}','{userLogin.dataUsers[0].user_name}' ,'{today}','{today}', 'true', '{controlLatestVersion}', '{listPartNo[0]}')  " +
                             $"RETURNING dfm_id;";

            var dfm_id = db.ExcuteQueryAndGetData(sqlSave).data[0]["dfm_id"].ToString();

            string sqlSaveAttach = $"INSERT INTO public.attachment(die_id, clasify, dsum_id, file_name, path, create_by, create_date)  " +
               $"VALUES ('{dieIDs[0]}', 'DFM_SUPPLIER_SUBMIT', {dfm_id}, '{fileCoverPageName}', '{pathCover}', '{userLogin.dataUsers[0].user_name}', '{DateTime.Now}');";
            db.ExcuteQueryAndGetData(sqlSaveAttach);
        exit:
            var output = new
            {
                msg = msg,
                status = status
            };
            return Json(output);
        }

        // Phương thức hỗ trợ chọn bảng tính
        static Worksheet GetWorksheet(Workbook workbook, string[] sheetNames)
        {
            foreach (string sheetName in sheetNames)
            {
                var worksheet = workbook.Worksheets[sheetName];
                if (worksheet != null)
                {
                    return worksheet;
                }
            }

            // Nếu không tìm thấy tên bảng tính, trả về bảng đầu tiên
            return workbook.Worksheets.Count > 0 ? workbook.Worksheets[0] : null;
        }

        public void deleteWorksheetLisence(string fullPath)
        {
            //*use epluse
            try
            {
                using (ExcelPackage pck = new ExcelPackage(fullPath))
                {

                    var wk = pck.Workbook.Worksheets["Evaluation Warning"];
                    pck.Workbook.Worksheets.Delete(wk);
                    pck.SaveAs(fullPath);
                }
            }
            catch
            {

            }



        }
        public bool GetSignatureAndSaveCoverPage(string fullCoverPath, int CurrentStatusID, string userName, bool isRevise, bool isNewDFM, string reviseContent, string controlLatest, bool isUpVer, int? newVer, string dieCode)
        {
            bool status = false;
            var today = DateTime.Now;

            try
            {
                using (ExcelPackage package = new ExcelPackage(fullCoverPath))
                {
                    var worksheet = package.Workbook.Worksheets.First();

                    // Cập nhật DIE NO
                    worksheet.Cells["M16"].Value = dieCode;

                    if (isRevise)
                    {
                        // Xử lý revise
                        worksheet.Cells["Q42"].Value = $"● {today:yyyy/MM/dd} {userName} Revised: {Environment.NewLine}{reviseContent}{Environment.NewLine}{worksheet.Cells["Q42"].Text}";

                        if (isUpVer && newVer.HasValue)
                        {
                            string[] configCellInputVer = { "-", "-", "AH26", "AI26", "AJ26", "AK26", "AL26", "AM26", "AN26" };
                            string[] configCellInputDate = { "-", "-", "I5", "K5", "M5", "O5", "Q5", "S5", "U5" };

                            if (newVer.Value + 1 < configCellInputVer.Length)
                            {
                                worksheet.Cells[configCellInputVer[newVer.Value + 1]].Value = true;
                                worksheet.Cells[configCellInputDate[newVer.Value + 1]].Value = today.ToString("MM/dd/yyyy");
                            }
                        }
                    }
                    else
                    {
                        // Xử lý CurrentStatusID
                        var cellMapping = new Dictionary<int, string>
                {
                    { 1, "I9" }, { 2, "I13" }, { 3, "E13" },
                    { 4, "Q13" }, { 5, "I13" }, { 6, "Q13" },
                    { 7, "T13" }, { 8, "M13" }, { 12, "M9" }
                };

                        if (isNewDFM)
                        {
                            worksheet.Cells["AG26"].Value = true;
                            worksheet.Cells["G5"].Value = today.ToString("MM/dd/yyyy");
                        }
                        else if (cellMapping.ContainsKey(CurrentStatusID))
                        {
                            string currentText = worksheet.Cells[cellMapping[CurrentStatusID]].Text;
                            worksheet.Cells[cellMapping[CurrentStatusID]].Value = $"{userName}{Environment.NewLine}{today:dd-MMM-yy}" +
                                (string.IsNullOrWhiteSpace(currentText) || currentText == "\r\n" ? "" : $"{Environment.NewLine}{currentText}");
                        }
                    }

                    // Thêm controlLatest
                    worksheet.Cells["A4"].Value = controlLatest;

                    package.Save();
                    status = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
                status = false;
            }

            return status;
        }

        public string genarateDSUMNo(string currentDTFNo, bool isNew, bool isRevise)
        {
            var output = "";
            var today = DateTime.Now;
            string sqlTotalDSUMInThisYear = $"SELECT count(*) FROM dsum WHERE EXTRACT(YEAR FROM submit_date) = EXTRACT(YEAR FROM CURRENT_DATE);";
            int totalDSUMinThisYear = int.Parse(db.ExcuteQueryAndGetData(sqlTotalDSUMInThisYear).data[0]["count"].ToString()) + 1;

            if (isNew)
            {
                output = "DFM" + today.ToString("yyMMdd-") + totalDSUMinThisYear.ToString().PadLeft(4, '0') + "-00";
            }
            if (isRevise)
            {
                var upver = currentDTFNo.Substring(currentDTFNo.Length - 2, 2); // 00
                int upverInt = System.Convert.ToInt16(upver) + 1;
                var mainNo = currentDTFNo.Remove(currentDTFNo.Length - 2, 2);
                output = mainNo + upverInt.ToString().PadLeft(2, '0');
            }
            return output;
        }

        public JsonResult api_getDSUMRouteTemplate()
        {
            string sqlGetTempalate = "SELECT * FROM dsum_route_template WHERE is_active = true";
            var r = db.ExcuteQueryAndGetData(sqlGetTempalate).data;
            var data = new
            {
                data = r
            };
            return Json(data);
        }







    }
}
