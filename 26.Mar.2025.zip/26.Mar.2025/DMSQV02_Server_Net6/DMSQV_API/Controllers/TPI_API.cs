﻿using Aspose.Cells;
using Aspose.Cells.Revisions;
using DMSQV_API.Data;
using DMSQV_API.Models;
using iTextSharp.text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using OfficeOpenXml.FormulaParsing.Excel.Functions.Engineering;
using OfficeOpenXml.Style;
using System;
using System.Diagnostics;
using System.Drawing;
using System.Reflection.Emit;
using System.Reflection.Metadata;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Xml.Linq;
using static DMSQV_API.Controllers.WorkInExcel;
using static DMSQV_API.Data.DBConnector;
using static Org.BouncyCastle.Bcpg.Attr.ImageAttrib;

namespace DMSQV_API.Controllers
{
    public class TPI_API : Controller
    {
        DBConnector db = new DBConnector();
        Authen authen = new Authen();
        CommonFunction commonFunction = new CommonFunction();
        WorkInExcel workInExcel = new WorkInExcel();
        SendEmail sendMailJob = new SendEmail();
        string currentURLHost = System.IO.Directory.GetCurrentDirectory();
        public JsonResult api_getTPIList(string search, string? tpi_id, string? supplier_id, string? model_id, string phase, string tpi_status, int? page = 1, int? pageSize = 50)
        {
            search = search?.Trim();
            bool status = false;
            string msg = "";
            var islogin = authen.isLoginAndReturnUserProfile(HttpContext);

            dataReturn data = new dataReturn();
            if (islogin.status)
            {
                data = db.getTPIList(search, tpi_id, supplier_id, model_id, phase, tpi_status, page, pageSize);
                status = true;
            }
            else
            {
                msg = "Please login!";
                status = false;
            }


        exit:
            var output = new
            {
                status = status,
                msg = msg,
                recordsTotal = data.totalCount,
                recordsFiltered = data.totalCount,
                page = page,
                pageSize = pageSize,
                Data = data.data,
            };
            return Json(output);
        }

        public JsonResult api_getSumarizeTPIPending()
        {
            string sqlTPIWaitPUR = "SELECT count(*) FROM tpi WHERE is_need_pur_confirm = true AND  (tpi.active is null OR tpi.active = true)";
            var waitPUR = db.ExcuteQueryAndGetData(sqlTPIWaitPUR).data[0]["count"];

            var tpiPending = db.getSumarizeTPIPending();
            var output = new
            {
                tpiPending = tpiPending.data,
                waitPUR = waitPUR
            };
            return Json(output);
        }


        public JsonResult api_getTPIDetailByID(int id)
        {
            bool status = false;
            string msg = "";
            var islogin = authen.isLoginAndReturnUserProfile(HttpContext);

            dataReturn data = new dataReturn();
            dataReturn his = new dataReturn();
            dataReturn totalDie = new dataReturn();

            if (islogin.status)
            {
                string sql = $"SELECT * FROM search_tpi_by_parameters('','{id}','','','','')";
                data = db.ExcuteQueryAndGetData(sql);
                string sqlHisTPI = $"SELECT tpi.tpi_no, tpi.tpi_id, tpi.trouble_name, tpi_po_code.type as po_code, s.status_type as tpi_status  FROM tpi " +
                                   $"LEFT JOIN tpi_po_code ON tpi_po_code.tpi_po_code_id = tpi.tpi_po_code_id " +
                                   $"Left join tpi_status_category s ON s.tpi_status_id = tpi.tpi_status_id " +
                                   $"WHERE die_id = {data.data[0]["die_id"].ToString()} " +
                                   $"AND (active is null OR active = true) " +
                                   $"ORDER BY tpi.tpi_id DESC";
                his = db.ExcuteQueryAndGetData(sqlHisTPI);

                totalDie = db.getDieBySearchPartNo(data.data[0]["part_no"].ToString().Substring(0, 8));
                status = true;
            }
            else
            {
                msg = "Please login!";
                status = false;
            }
            var result = new
            {
                msg = msg,
                data = data.data[0],
                his = his.data,
                totalDie = totalDie.data
            };
            return Json(result);
        }


        public JsonResult api_issueTPI(IFormFile fileTPI)
        {
            bool status = false;
            bool isReject = false;

            string msg = "";
            var islogin = authen.isLoginAndReturnUserProfile(HttpContext);
            if (islogin.status)
            {
                bool isPermit = islogin.dataUsers.Any(e => new[] { 3, 4, 5, 6 }.Contains(e.tpi_role_id));
                string dept = islogin.dataUsers.Where(e => new[] { 3, 4, 5, 6 }.Contains(e.tpi_role_id)).FirstOrDefault()?.dept_name;
                string division = islogin.dataUsers.Where(e => new[] { 3, 4, 5, 6 }.Contains(e.tpi_role_id)).FirstOrDefault()?.division;
                if (isPermit == false)
                {
                    msg = "You do not have permision!";
                    goto exit;
                }

                var resultVerifyForm = workInExcel.verifyTPIForm(fileTPI, null);
                if (resultVerifyForm.isPass == false)
                {
                    if (islogin.dataUsers[0].user_name.Contains("RPA")) // do RPA upload lên
                    {
                        // Reject
                        isReject = true;
                        msg = resultVerifyForm.msg;
                        goto continuse;
                    }
                    else
                    {
                        msg = resultVerifyForm.msg;
                        goto exit;
                    }
                }

            continuse: // trường hợp VERIFY FORM false nhưng do RPA upload thì vẫn được chạy tiếp
                       // 1. Doc file va lay thong tin tu TPI
                tpiData tpi = new tpiData();
                tpi = workInExcel.readTPI(tpi, fileTPI);

                if (isReject == true)
                {
                    tpi.FinalStatusID = 11; // Reject
                    tpi.TroubleFrom = "OUTSIDE";
                    tpi.isNeedRPA = true;
                }
                else
                {
                    // Thay đổi TPI status
                    bool isINHOSE = new[] { "DIV1" }.Contains(division);
                    if (isINHOSE)
                    {
                        tpi.TroubleFrom = "INHOUSE";
                        tpi.FinalStatusID = 10; // W-DMT-Check
                    }
                    else
                    {
                        if (tpi.DieBelong.Contains("CRG"))
                        {
                            tpi.TroubleFrom = "CRG";
                            tpi.FinalStatusID = 12; // W-CRG-CHECK
                        }
                        else
                        {
                            if (tpi.DieBelong.Contains("LBP"))
                            {
                                tpi.TroubleFrom = "OUTSIDE";
                                tpi.FinalStatusID = 3; // W-PAE-CHECK
                            }
                            else
                            {
                                tpi.TroubleFrom = "OTHER";
                                tpi.FinalStatusID = 8; // W-PE1-CHECK
                            }
                        }
                        // OUTSIDE cần PUR xác nhận
                        tpi.IsNeedPURConfirm = isTPINeedPURConfirm(tpi.TroubleFrom, tpi.phase, tpi.TroubleName);

                    }

                }
                tpi.SubmitDate = DateTime.Now;
                tpi.SubmitBy = islogin.dataUsers[0].user_name;
                tpi.Progress = DateTime.Now.ToString("yyyy/MM/dd") + ": " + tpi.SubmitBy + " uploaded report.";
                tpi.Active = true;




                // Luu file maker TPI
                bool isNewsubmit = tpi.tpi_id == 0 ? true : false;
                tpi.TPINo = genarateTPINo(isNewsubmit, tpi.TPINo);
                string fileName = $"[MAKER_TPI][{tpi.TPINo}]_{tpi.dieNo}";
                tpi.ReportFromPur = commonFunction.savePhysicalFileOnServer(fileTPI, "/File/TPI/", fileName);
                string note = "";
                if (isReject == true) // RPA Submit
                {
                    note = $"RPA Reject due to {msg}";
                    string fileReportName = $"[{tpi.TPINo}]_{tpi.dieNo}";
                    tpi.Report = commonFunction.savePhysicalFileOnServer(fileTPI, "/File/TPI/", fileReportName);
                    workInExcel.UpdateTPIForm(tpi.TPINo, tpi.dieNo, tpi.Report, "Submit", isReject, false, dept, division, islogin.dataUsers[0].user_name, msg, null, null, null);
                }
                else
                {
                    workInExcel.UpdateTPIForm(tpi.TPINo, tpi.dieNo, tpi.ReportFromPur, "Submit", false, false, dept, division, islogin.dataUsers[0].user_name, msg, null, null, null);
                }



                // chuyển đổi để lưu được vào database
                string sqlUpsert = "";
                if (tpi.tpi_id == 0)
                {
                    // Insert
                    sqlUpsert = $"INSERT INTO tpi (tpi_no,tpi_status_id, die_id,part_no,trouble_from, trouble_level_id,dead_line_if_urgent, die_trouble_running_status_id,trouble_name,happen_date, progress, actual_short,report_from_pur, report,submit_date, submit_by,supplier_name,supplier_code,phase, submit_type,is_need_pur_confirm, is_need_rpa, active, note )  " +
                    $"VALUES('{tpi.TPINo}','{tpi.FinalStatusID}','{tpi.die_id}','{tpi.partNo}','{tpi.TroubleFrom}','{tpi.TroubleLevelID}',COALESCE(NULLIF('{tpi.dueDate}', ''), NULL)::date,'{tpi.DieTroubleRunningStatusID}','{tpi.TroubleName}','{tpi.happenDate}','{tpi.Progress}','{tpi.shot}','{tpi.ReportFromPur}',COALESCE(NULLIF('{tpi.Report}', ''), NULL),'{tpi.SubmitDate}','{tpi.SubmitBy}','{tpi.supplierName}','{tpi.supplierCode}','{tpi.phase}','{tpi.SubmitType}','{tpi.IsNeedPURConfirm}','{tpi.isNeedRPA}','{true}', '{note}')  ";
                }
                else
                {
                    // Update
                    sqlUpsert = $"UPDATE tpi SET  " +
                    $"tpi_no = '{tpi.TPINo}', " +
                    $"tpi_status_id = '{tpi.FinalStatusID}', " +
                    $"die_id = '{tpi.die_id}', " +
                    $"part_no = '{tpi.partNo}', " +
                    $"trouble_from = '{tpi.TroubleFrom}', " +
                    $"trouble_level_id = '{tpi.TroubleLevelID}', " +
                    $"dead_line_if_urgent = COALESCE(NULLIF('{tpi.dueDate}', ''), NULL)::date, " +
                    $"die_trouble_running_status_id = '{tpi.DieTroubleRunningStatusID}', " +
                    $"trouble_name = '{tpi.TroubleName}', " +
                    $"happen_date = '{tpi.happenDate}', " +
                    $"progress = '{tpi.Progress}', " +
                    $"actual_short = '{tpi.shot}', " +
                    $"report_from_pur = '{tpi.ReportFromPur}', " +
                    $"report = COALESCE(NULLIF('{tpi.Report}', ''), NULL), " +
                    $"submit_date = '{tpi.SubmitDate}', " +
                    $"submit_by = '{tpi.SubmitBy}', " +
                    $"supplier_name = '{tpi.supplierName}', " +
                    $"supplier_code = '{tpi.supplierCode}', " +
                    $"phase = '{tpi.phase}', " +
                    $"submit_type = '{tpi.SubmitType}', " +
                    $"is_need_pur_confirm = '{tpi.IsNeedPURConfirm}', " +
                    $"is_need_rpa = '{tpi.isNeedRPA}', " +
                    $"note =  '{note}',  " +
                    $"active = '{true}' " +
                    $"WHERE tpi_id = {tpi.tpi_id}";
                }
                db.ExcuteQueryAndGetData(sqlUpsert);
                status = true;
            }
        exit:
            var output = new
            {
                status = status,
                msg = msg,
            };
            return Json(output);
        }

        public checkTPIResult rejectTPI(string tpi_id, string reason)
        {
            var today = DateTime.Now;
            bool status = false;
            string msg = "";
            var islogin = authen.isLoginAndReturnUserProfile(HttpContext);
            if (islogin.status)
            {
                var configRejectOutside_Packing = new[] { 14, 8, 11 };
                var configRejectOutside_CRG = new[] { 13, 12, 11 };
                var configRejectOutside_LBP = new[] { 14, 8, 3, 11, 9, 3, 11, 7, 10, 3, 11 };
                var configRejectInhouse = new[] { 14, 8, 10, 11, 7, 10, 11 };
                string user_name = islogin.dataUsers[0].user_name;

                //bool isPAE = islogin.dataUsers.Any(e => e.tpi_role_id >= 3 && new[] { "PAE" }.Contains(e.dept_name) && new[] { "QV", "TS" }.Contains(e.factory));
                //bool isCRG = islogin.dataUsers.Any(e => e.tpi_role_id >= 3 && new[] { "CRG" }.Contains(e.dept_name) && new[] { "QV", "TS" }.Contains(e.factory));
                //bool isPE1 = islogin.dataUsers.Any(e => e.tpi_role_id >= 3 && new[] { "PE1" }.Contains(e.dept_name) && new[] { "QV", "TS" }.Contains(e.factory));
                //bool isINHOUSE = islogin.dataUsers.Any(e => e.tpi_role_id >= 3 && new[] { "DIV1" }.Contains(e.division) && new[] { "QV", "TS" }.Contains(e.factory));

                string sql = $"SELECT tpi.*, dies.dieno FROM tpi " +
                    $"INNER JOIN dies ON dies.die_id = tpi.die_id " +
                    $"WHERE tpi_id = {tpi_id}";
                var tpi = db.ExcuteQueryAndGetData(sql).data[0];

                string troubleFrom = tpi["trouble_from"].ToString();
                int currentStatusID = int.Parse(tpi["tpi_status_id"].ToString());
                int nextStatusID = currentStatusID;
                string deptAction = "";
                if (troubleFrom.Contains("INHOUSE"))
                {

                    nextStatusID = configRejectInhouse[Array.IndexOf(configRejectInhouse, currentStatusID) + 1];
                }
                if (troubleFrom.Contains("CRG"))
                {

                    nextStatusID = configRejectOutside_CRG[Array.IndexOf(configRejectOutside_CRG, currentStatusID) + 1];
                }

                if (troubleFrom.Contains("OTHER"))
                {

                    nextStatusID = configRejectOutside_Packing[Array.IndexOf(configRejectOutside_Packing, currentStatusID) + 1];
                }
                if (troubleFrom.Contains("OUTSIDE"))
                {
                    nextStatusID = configRejectOutside_LBP[Array.IndexOf(configRejectOutside_LBP, currentStatusID) + 1];
                }


                // Điều kiện đê Reject TPI
                //1. Nếu MR đã được issue bằng TPI này thì ko thể reject được

                var isNeedPURConfirm = tpi["is_need_pur_confirm"];
                if (nextStatusID == 11) // reject
                {
                    isNeedPURConfirm = "false";
                    // Kiểm tra đã issue MR chưa
                    string sqlCheckMRIssueORNot = $"SELECT mr_no FROM MR where MR.tpi_id ilike '{tpi_id}' and (is_active = true OR  is_active is null) and status_id not in (11,12)";
                    var MR_No_Issued = db.ExcuteQueryAndGetData(sqlCheckMRIssueORNot);
                    if (MR_No_Issued.data.Count > 0)
                    {
                        msg = $"Can not REJECT TPI because MR[{MR_No_Issued.data[0]["mr_no"]}] was issued by this TPI. You need ask PUR cancel MR No[{MR_No_Issued.data[0]["mr_no"]}] first. Then Reject TPI";
                        status = false;
                        goto exit;
                    }
                }

            Save:
                string fileReportName = $"[{tpi["tpi_no"]}]_{tpi["dieno"]}";
                string lastTPI = tpi["report"].ToString();
                string submitedTPI = tpi["report_from_pur"].ToString();
                string pathFileTPI = "";
                if (!String.IsNullOrEmpty(lastTPI))
                {
                    pathFileTPI = lastTPI;
                }
                else
                {
                    pathFileTPI = submitedTPI;
                }
                if (nextStatusID == 11)
                {
                    workInExcel.UpdateTPIForm(tpi["tpi_no"].ToString(), tpi["dieno"].ToString(), pathFileTPI, null, true, false, "PUR", "PUR", user_name, reason, null, null, null);
                }

                string sqlUPDATE = $"UPDATE tpi " +
               $"SET " +
               $"tpi_status_id = {nextStatusID},  " +
               $"is_need_pur_confirm = '{isNeedPURConfirm}',  " +
               $"report = '{pathFileTPI}',  " +
               $"note = CASE WHEN '{reason}' IS NOT NULL AND '{reason}' <> '' THEN CONCAT_WS(CHR(10), '{DateTime.Now.ToString(commonFunction.ShotDateFormat) + " " + user_name + " reject: " + reason}', tpi.note) ELSE note END  " +
               $" WHERE tpi_id = {tpi_id}";
                db.ExcuteQueryAndGetData(sqlUPDATE);
                status = true;

            }
        exit:
            checkTPIResult output = new checkTPIResult
            {
                msg = msg,
                status = status
            };
            return output;
        }

        public JsonResult api_checkTPI(string tpi_id, string detail_phenomenon, string detail_action, string trouble_type_id_arr, string trouble_area_id_arr, string root_cause_id_arr, string tpi_po_code_id,
                                        string temp_cm_id_arr, string per_cm_id_arr, string renew_decision_id, string feedback_for_rd, string feedback_for_die_spec, string Comment, string is_need_pe_confirm,
                                        string is_need_dmt_confirm, IFormFile file_report, string temapraty_action, string dead_line_if_urgent, string reject_reason, string btn_action)
        {
            bool status = false;
            string msg = "";
            var islogin = authen.isLoginAndReturnUserProfile(HttpContext);
            if (islogin.status)
            {
                string user_name = islogin.dataUsers[0].user_name;
                bool isPUR = islogin.dataUsers.Any(e => e.tpi_role_id >= 3 && new[] { "PUR" }.Contains(e.dept_name) && new[] { "QV", "TS" }.Contains(e.factory));
                bool isPAE = islogin.dataUsers.Any(e => e.tpi_role_id >= 3 && new[] { "PAE" }.Contains(e.dept_name) && new[] { "QV", "TS" }.Contains(e.factory));
                bool isCRG = islogin.dataUsers.Any(e => e.tpi_role_id >= 3 && new[] { "CRG" }.Contains(e.dept_name) && new[] { "QV", "TS" }.Contains(e.factory));
                bool isPE1 = islogin.dataUsers.Any(e => e.tpi_role_id >= 3 && new[] { "PE1" }.Contains(e.dept_name) && new[] { "QV", "TS" }.Contains(e.factory));
                bool isINHOUSE = islogin.dataUsers.Any(e => e.tpi_role_id >= 3 && new[] { "DIV1" }.Contains(e.division) && new[] { "QV", "TS" }.Contains(e.factory));

                if (!(isPUR || isPAE || isCRG || isPE1 || isINHOUSE))
                {
                    msg = "You do not have permision!";
                    goto exit;
                }
                string sql = $"SELECT tpi.*, dies.dieno FROM tpi " +
                    $"INNER JOIN dies ON dies.die_id = tpi.die_id " +
                    $"WHERE tpi_id = {tpi_id}";
                var tpi = db.ExcuteQueryAndGetData(sql);

                if (btn_action.Contains("REJECT"))
                {
                    var rejectResult = rejectTPI(tpi_id, reject_reason);
                    msg = rejectResult.msg;
                    status = rejectResult.status;
                    goto exit;
                }

                // STATUS TIẾP THEO
                //int currentStatusID = int.Parse(tpi.data[0]["status_id"].ToString());
                //var statusConfig = db.ExcuteQueryAndGetData($"SELECT * FROM tpi_status_category WHERE tpi_status_id = {currentStatusID} ");

                if (isINHOUSE || isPAE || isCRG || isPE1)
                {
                    if (file_report != null)
                    {
                        var verifyTPI = workInExcel.verifyTPIForm(file_report, tpi.data[0]["dieno"].ToString());
                        if (verifyTPI.isPass == false)
                        {
                            msg = verifyTPI.msg;
                            goto exit;
                        }
                    }
                    var result = PAE_CRG_INHOUSE_PE1_CheckAndApproveTPI(islogin, isPAE, isCRG, isINHOUSE, isPE1, file_report, tpi, tpi_id, detail_phenomenon, detail_action, trouble_type_id_arr, trouble_area_id_arr, root_cause_id_arr, tpi_po_code_id,
                                         temp_cm_id_arr, per_cm_id_arr, renew_decision_id, feedback_for_rd, feedback_for_die_spec, Comment, is_need_pe_confirm, is_need_dmt_confirm);
                    status = result.status;
                    msg = result.msg;

                }
                if (isPUR)
                {
                    var resultConfirm = PUR_ConfirmTPI(tpi, tpi_id, temapraty_action, dead_line_if_urgent, Comment, user_name);
                    status = resultConfirm.status;
                    msg = resultConfirm.msg;
                }

                // Xong tất cả => gửi mail 
               
                if(status)
                {
                    sendMailJob.sendEmailTPIProgress(tpi_id);
                }
            }


        exit:
            var output = new
            {
                status = status,
                msg = msg,
            };
            return Json(output);
        }

        public class checkTPIResult
        {
            public bool status { set; get; }
            public string msg { set; get; }
        }
        public checkTPIResult PAE_CRG_INHOUSE_PE1_CheckAndApproveTPI(CheckUserLogin users, bool isPAE, bool isCRG, bool isINHOUSE, bool isPE1, IFormFile file_report, dataReturn tpiDATA, string tpi_id, string detail_phenomenon, string detail_action, string trouble_type_id_arr, string trouble_area_id_arr, string root_cause_id_arr, string tpi_po_code_id,
                                        string temp_cm_id_arr, string per_cm_id_arr, string renew_decision_id, string feedback_for_rd, string feedback_for_die_spec, string Comment, string is_need_pe_confirm, string is_need_dmt_confirm)
        {
            string user_name = users.dataUsers[0].user_name;
            bool status = false;
            bool isRevise = false;
            string msg = "";
            string progress = "";
            bool isNeedPURConfirm = false;
            var today = DateTime.Now;
            var pathFileTPI = "";
            string sqlSUBUpdate = "";
            string subSQLREADFILE = "";
            string sqlRevise = "";
            bool isNeedPE1 = is_need_pe_confirm == "true" ? true : false;
            bool isNeedDMT = is_need_dmt_confirm == "true" ? true : false;
            // ĐOC DỮ LIỆU TỪ TPI
            var tpi = tpiDATA.data[0];
            tpiData tpiRead = new tpiData();

            // LUU FILE TPI
            // File này đã được verify ở controller trước
            string fileReportName = $"[{tpi["tpi_no"]}]_{tpi["dieno"]}";
            string lastTPI = tpi["report"].ToString();
            string submitedTPI = tpi["report_from_pur"].ToString();
            if (file_report != null) // file duoc upload lên
            {
                tpiRead = workInExcel.readTPI(tpiRead, file_report);
                pathFileTPI = commonFunction.savePhysicalFileOnServer(file_report, "/File/TPI/", fileReportName);
                subSQLREADFILE =
                   $"die_id = '{tpiRead.die_id}', " +
                   $"part_no = '{tpiRead.partNo}', " +
                   $"trouble_level_id = '{tpiRead.TroubleLevelID}', " +
                   $"dead_line_if_urgent = COALESCE(NULLIF('{tpiRead.dueDate}', ''), NULL)::date, " +
                   $"die_trouble_running_status_id = '{tpiRead.DieTroubleRunningStatusID}', " +
                   $"trouble_name = '{tpiRead.TroubleName}', " +
                   $"happen_date = '{tpiRead.happenDate}', " +
                   $"actual_short = '{tpiRead.shot}', " +
                   $"supplier_name = '{tpiRead.supplierName}', " +
                   $"supplier_code = '{tpiRead.supplierCode}', " +
                   $"phase = '{tpiRead.phase}', " +
                   $"submit_type = '{tpiRead.SubmitType}', ";
            }
            else // File ko được upload lên => lấy file gần nhất
            {

                if (!String.IsNullOrEmpty(lastTPI))
                {
                    pathFileTPI = lastTPI;
                }
                else
                {
                    // Coppy submited Report
                    FileInfo file_Report_submitted = new FileInfo(currentURLHost + submitedTPI);
                    var iformFileTPI = commonFunction.ConvertFileInfoToIFormFile(file_Report_submitted);
                    pathFileTPI = commonFunction.savePhysicalFileOnServer(iformFileTPI, "/File/TPI/", fileReportName);
                }

            }



            // LOGIC

            // CẦN PUR XÁC NHẬN KO?
            isNeedPURConfirm = isTPINeedPURConfirm(tpi["trouble_from"].ToString(), tpi["phase"].ToString(), tpi["trouble_name"].ToString());

            // STATUS TIẾP THEO
            int currentStatusID = int.Parse(tpi["tpi_status_id"].ToString());
            int nextStatusID = 0;
            bool isNeedGenarateNextStatusAfterDeptApp = false;
            //****CHECK VA APPROVE
            bool isApprover = false;
            string deptAction = "";
            if (isPAE && new[] { 3, 9 }.Contains(currentStatusID))
            {
                deptAction = "PAE";
                isApprover = users.dataUsers.Any(e => e.tpi_role_id >= 4 && new[] { "PAE" }.Contains(e.dept_name) && new[] { "QV", "TS" }.Contains(e.factory));
                if (currentStatusID == 3) // W-PAE-Check
                {
                    progress = "PAECheck";
                    nextStatusID = 9;
                    sqlSUBUpdate =
                        $"progress = CONCAT_WS(CHR(10),'{today.ToString(commonFunction.ShotDateFormat)}: PAE Checked' ,tpi.progress),  " +
                        $"pic = '{user_name}',  " +
                        $"feedback_date = '{today}', " +
                        $"pae_comment = '{Comment}', ";

                }
                else
                {
                    if (currentStatusID == 9 && isApprover) // W-PAE-Approve
                    {
                        progress = "PAEApp";
                        isNeedGenarateNextStatusAfterDeptApp = true;
                        sqlSUBUpdate =
                        $"progress = CONCAT_WS(CHR(10),'{today.ToString(commonFunction.ShotDateFormat)}: PAE Approved' ,tpi.progress),  " +
                        $"pae_commentby = '{user_name}', " +
                        $"pae_comment_date = '{today}', " +
                        $"pae_comment = '{Comment}', ";
                    }
                    else
                    {
                        msg = "You do not have permision for APPROVE TPI";
                        status = false;
                        goto exit;
                    }
                }


                goto save;
            }
            if (isCRG && new[] { 12, 13 }.Contains(currentStatusID))
            {
                deptAction = "CRG";
                isApprover = users.dataUsers.Any(e => e.tpi_role_id >= 4 && new[] { "CRG" }.Contains(e.dept_name) && new[] { "QV", "TS" }.Contains(e.factory));
                if (currentStatusID == 12) // W-CRG-Check
                {
                    progress = "CRGCheck";
                    nextStatusID = 13;
                    sqlSUBUpdate =
                        $"progress = CONCAT_WS(CHR(10),'{today.ToString(commonFunction.ShotDateFormat)}: CRG Checked' ,tpi.progress),  " +
                        $"crg_check_by = '{user_name}', " +
                        $"crg_check_date = '{today}', " +
                        $"crg_comment = '{Comment}', ";
                }
                else
                {
                    if (currentStatusID == 13 && isApprover)
                    {
                        progress = "CRGApp";
                        isNeedGenarateNextStatusAfterDeptApp = true;
                        sqlSUBUpdate =
                        $"progress = CONCAT_WS(CHR(10),'{today.ToString(commonFunction.ShotDateFormat)}: CRG Approved' ,tpi.progress), " +
                        $"crg_app_by = '{user_name}', " +
                        $"crg_app_date = '{today}', " +
                        $"crg_comment = '{Comment}', ";
                    }
                    else
                    {
                        msg = "You do not have permision for APPROVE TPI";
                        status = false;
                        goto exit;
                    }
                }
                goto save;
            }
            if (isINHOUSE && new[] { 10, 7 }.Contains(currentStatusID))
            {
                deptAction = "DMT";
                isApprover = users.dataUsers.Any(e => e.tpi_role_id >= 4 && new[] { "DIV1" }.Contains(e.division) && new[] { "QV", "TS" }.Contains(e.factory));
                if (currentStatusID == 10) // W-DMT-Check
                {
                    progress = "DMTCheck";
                    nextStatusID = 7;
                    sqlSUBUpdate =
                        $"progress = CONCAT_WS(CHR(10),'{today.ToString(commonFunction.ShotDateFormat)}: DMT/MO/MS Checked' ,tpi.progress), " +
                        $"dmt_check_by = '{user_name}', " +
                        $"dmt_check_date = '{today}', " +
                        $"dmt_comment = '{Comment}', ";
                }
                else
                {
                    if (currentStatusID == 7 && isApprover)
                    {
                        progress = "DMTApp";
                        isNeedGenarateNextStatusAfterDeptApp = true;
                        sqlSUBUpdate =
                        $"progress = CONCAT_WS(CHR(10),'{today.ToString(commonFunction.ShotDateFormat)}: DMT Approved' ,tpi.progress), " +
                        $"dmt_app_by = '{user_name}', " +
                        $"dmt_app_date = '{today}', " +
                        $"dmt_comment = '{Comment}', ";
                    }
                    else
                    {
                        msg = "You do not have permision for APPROVE TPI";
                        status = false;
                        goto exit;
                    }
                }

                goto save;
            }
            if (isPE1 && new[] { 8, 14 }.Contains(currentStatusID))
            {
                deptAction = "PE1";
                isApprover = users.dataUsers.Any(e => e.tpi_role_id >= 4 && new[] { "PE1" }.Contains(e.dept_name) && new[] { "QV", "TS" }.Contains(e.factory));
                if (currentStatusID == 8) // W-PE1-Check
                {
                    progress = "PE1Check";
                    nextStatusID = 14;
                    sqlSUBUpdate =
                        $"progress = CONCAT_WS(CHR(10),'{today.ToString(commonFunction.ShotDateFormat)}: PE1 Checked' ,tpi.progress), " +
                        $"pe1_comment_by = '{user_name}', " +
                        $"pe1_comment_date = '{today}', " +
                        $"pe1_comment = '{Comment}', ";
                }
                else
                {
                    if (currentStatusID == 14 && isApprover)
                    {
                        progress = "PE1App";
                        isNeedGenarateNextStatusAfterDeptApp = true;
                        sqlSUBUpdate =
                        $"progress = CONCAT_WS(CHR(10),'{today.ToString(commonFunction.ShotDateFormat)}: PE1 Approved' ,tpi.progress), " +
                        $"pe1_app_by = '{user_name}', " +
                        $"pe1_app_date = '{today}', " +
                        $"pe1_comment = '{Comment}', ";
                    }
                    else
                    {
                        msg = "You do not have permision for APPROVE TPI";
                        status = false;
                        goto exit;
                    }
                }

                goto save;
            }
            //***** KET THUC CHECK VA APPROVE

            //******REVISE*********

            {


                if (isPAE)
                {
                    sqlSUBUpdate =
                        $"pic = '{user_name} [Revised]',  " +
                        $"feedback_date = '{today}', " +
                        $"pae_comment = '{Comment}', ";
                    deptAction = "PAE";
                    nextStatusID = 9;
                    isRevise = true;
                }
                if (isCRG)
                {
                    sqlSUBUpdate =
                      $"crg_check_by = '{user_name} [Revised]', " +
                      $"crg_check_date = '{today}', " +
                      $"crg_comment = '{Comment}', ";
                    deptAction = "CRG";
                    nextStatusID = 13;
                    isRevise = true;
                }
                if (isINHOUSE)
                {
                    sqlSUBUpdate =
                       $"dmt_check_by = '{user_name} [Revised]', " +
                       $"dmt_check_date = '{today}', " +
                       $"dmt_comment = '{Comment}', ";
                    deptAction = "DMT";
                    nextStatusID = 7;
                    isRevise = true;
                }
                if (isPE1)
                {
                    sqlSUBUpdate =
                      $"pe1_comment_by = '{user_name} [Revised]', " +
                      $"pe1_comment_date = '{today}', " +
                      $"pe1_comment = '{Comment}', ";
                    deptAction = "PE1";
                    nextStatusID = 14;
                    isRevise = true;
                }
                // Điều kiện đê revise MR
                //1. Nếu chuyển từ isNeedMR => NoNeedMR thì phải kiểm tra xem MR đã issue Chưa
                // Nếu đã Issue thì ko được revise mà phải y/c cancel MR trước ngược lại thì được revise
                var tpi_po_code_id_before = String.IsNullOrWhiteSpace(tpi["tpi_po_code_id"].ToString()) ? 4 : tpi["tpi_po_code_id"];
                var beforeSQL = $"SELECT is_need_mr from tpi_po_code WHERE tpi_po_code_id = {tpi_po_code_id_before}";
                var afterSQL = $"SELECT is_need_mr from tpi_po_code WHERE tpi_po_code_id = {tpi_po_code_id}";
                var isNeedMRBeforeRevise = db.ExcuteQueryAndGetData(beforeSQL).data[0]["is_need_mr"];
                var isNeedMRAfterRevise = db.ExcuteQueryAndGetData(afterSQL).data[0]["is_need_mr"];
                if (isNeedMRBeforeRevise.Equals(true))
                {
                    if (isNeedMRAfterRevise.Equals(false))
                    {
                        // Kiểm tra đã issue MR chưa
                        string sqlCheckMRIssueORNot = $"SELECT mr_no FROM MR where MR.tpi_id ilike '{tpi_id}' and (is_active = true OR  is_active is null) and status_id not in (11,12)";
                        var MR_No_Issued = db.ExcuteQueryAndGetData(sqlCheckMRIssueORNot);
                        if (MR_No_Issued.data.Count > 0)
                        {
                            msg = $"Can not revise [PO_Code] because MR[{MR_No_Issued.data[0]["mr_no"]}] was issued by this TPI. You need ask PUR cancel MR No[{MR_No_Issued.data[0]["mr_no"]}] first. Then revise TPI";
                            status = false;
                            goto exit;
                        }
                    }
                }
            }

        save:
            string msgComment = "";
            if (isNeedGenarateNextStatusAfterDeptApp)
            {
                msgComment = Comment;

                nextStatusID = genarateTPIStatusIDAfterEachDEPTApprove(int.Parse(tpi_id), currentStatusID, isNeedPE1, isNeedDMT);
            }
            if (isRevise)
            {
                msgComment = Comment;
                sqlRevise = $"progress = CONCAT_WS(CHR(10),'{today.ToString(commonFunction.ShotDateFormat)}: {deptAction} revised' ,tpi.progress), ";
            }
            string sqlUPDATE = $"UPDATE tpi " +
                $"SET " +
                $"tpi_status_id = {nextStatusID},  " +
                $"detail_phenomenon = '{detail_phenomenon}',  " +
                $"detail_action = '{detail_action}',  " +
                $"trouble_type_id_arr = '{trouble_type_id_arr}',  " +
                $"trouble_area_id_arr = '{trouble_area_id_arr}',  " +
                $"root_cause_id_arr = '{root_cause_id_arr}',  " +
                $"tpi_po_code_id = '{tpi_po_code_id}',  " +
                $"temp_cm_id_arr = '{temp_cm_id_arr}',  " +
                $"per_cm_id_arr = '{per_cm_id_arr}',  " +
                $"renew_decision_id = '{renew_decision_id}',  " +
                $"feedback_for_rd = '{feedback_for_rd}',  " +
                $"feedback_for_die_spec = '{feedback_for_die_spec}',  " +
                $"is_need_pe_confirm = '{isNeedPE1}',  " +
                $"is_need_dmt_confirm = '{isNeedDMT}',  " +
                $"is_need_pur_confirm = '{isNeedPURConfirm}',  " +
                $"report = '{pathFileTPI}',  " +
                 subSQLREADFILE + sqlSUBUpdate + sqlRevise +
                $"note = CASE WHEN '{Comment}' IS NOT NULL AND '{Comment}' <> '' THEN CONCAT_WS(CHR(10), '{today.ToString(commonFunction.ShotDateFormat) + " " + user_name + ": " + Comment}', tpi.note) ELSE note END  " +
                $" WHERE tpi_id = {tpi_id}";
            db.ExcuteQueryAndGetData(sqlUPDATE);


            string devision = users.dataUsers.Where(x => x.tpi_role_id >= 3 && new[] { "QV", "TS" }.Contains(x.factory)).FirstOrDefault()?.division;
            string po_code = db.ExcuteQueryAndGetData($"SELECT type FROM tpi_po_code WHERE tpi_po_code_id = {tpi_po_code_id}").data[0]["type"].ToString();
            string renewDecision = db.ExcuteQueryAndGetData($"SELECT type FROM tpi_renew_decision_catergory WHERE renew_decision_id = {renew_decision_id}").data[0]["type"].ToString();

            workInExcel.UpdateTPIForm(tpi["tpi_no"].ToString(), tpi["dieno"].ToString(), pathFileTPI, progress, false, isRevise, deptAction, devision, user_name, msgComment, null, po_code, renewDecision);
            status = true;


        exit:
            checkTPIResult output = new checkTPIResult
            {
                msg = msg,
                status = status
            };

            return output;
        }

        public checkTPIResult PUR_ConfirmTPI(dataReturn tpiDATA, string tpi_id, string temapraty_action, string dead_line_if_urgent, string Comment, string user_name)
        {
            var tpi = tpiDATA.data[0];
            string fileReportName = $"[{tpi["tpi_no"]}]_{tpi["dieno"]}";
            string lastTPI = tpi["report"].ToString();
            string submitedTPI = tpi["report_from_pur"].ToString();
            string pathFileTPI = "";
            if (!String.IsNullOrEmpty(lastTPI))
            {
                pathFileTPI = lastTPI;
            }
            else
            {
                pathFileTPI = submitedTPI;
            }
            workInExcel.UpdateTPIForm(tpi["tpi_no"].ToString(), tpi["dieno"].ToString(), pathFileTPI, "PURCheck", false, false, "PUR", "PUR", user_name, Comment, temapraty_action, null, null);

            DateTime today = DateTime.Now;
            bool status = false;
            string msg = "Save error!";
            string sqlUPDATE = $"UPDATE tpi " +
               $"SET " +
               $"is_need_pur_confirm = 'false',  " +
               $"pur_comment_by = '{user_name}',  " +
               $"pur_comment_date = '{today}',  " +
               $"pur_comment = '{Comment}',  " +
               $"temapraty_action = '{temapraty_action}',  " +
               $"trouble_level_id = '{commonFunction.genarateTPILevelID(dead_line_if_urgent)}', " +
               $"dead_line_if_urgent = COALESCE(NULLIF('{dead_line_if_urgent}', ''), NULL)::date, " +
               $"progress = CONCAT_WS(CHR(10),'{today.ToString(commonFunction.ShotDateFormat)}: PUR Confirmed' ,tpi.progress), " +
               $"note = CASE WHEN '{Comment}' IS NOT NULL AND '{Comment}' <> '' THEN CONCAT_WS(CHR(10), '{today.ToString(commonFunction.ShotDateFormat) + " " + user_name + ": " + Comment}', tpi.note) ELSE note END  " +
               $" WHERE tpi_id = {tpi_id}";
            db.ExcuteQueryAndGetData(sqlUPDATE);
            status = true;
            msg = "";
            var output = new checkTPIResult
            {
                msg = msg,
                status = status
            };
            return output;
        }
        public string genarateTPINo(bool isNewSubmit, string currentTPINo)
        {
            // chỉ genarate TPI No khi new issue Va REVISE TPI

            var TotalTPIInThisYear = 0;
            var today = DateTime.Now;
            var TPINo = "";

            string sqlTotalTPIInThisYear = $"SELECT count(*) FROM tpi WHERE EXTRACT(YEAR FROM submit_date) = EXTRACT(YEAR FROM CURRENT_DATE);";
            TotalTPIInThisYear = int.Parse(db.ExcuteQueryAndGetData(sqlTotalTPIInThisYear).data[0]["count"].ToString()) + 1;
            TPINo = "TPI" + today.ToString("yyMMdd") + "-" + TotalTPIInThisYear.ToString().PadLeft(4, '0') + "-00";

            if (isNewSubmit != true)
            {
                try
                {
                    if (currentTPINo != null)
                    {
                        // PUR - 00 => PAE 1st 01 => revise 02,03...
                        var upver = currentTPINo.Substring(currentTPINo.Length - 2, 2);
                        int upverInt = (int)commonFunction.getNummberInString(upver) + 1;

                        var mainNo = currentTPINo.Remove(currentTPINo.Length - 2, 2);
                        TPINo = mainNo + upverInt.ToString().PadLeft(2, '0');
                    }
                }
                catch
                {

                }
            }
            // check đã tồn tại số này chưa => nếu chưa đã tồn tại lại genarate lại
            string sqlcheck = $"SELECT tpi_id FROM tpi WHERE tpi_no = '{TPINo}'";
            if (db.ExcuteQueryAndGetData(sqlcheck).data.Count > 0)
            {
                TPINo = genarateTPINo(false, TPINo);
            }
            return TPINo;
        }

        public bool isTPINeedPURConfirm(string trouble_from, string phase, string trouble_name)
        {
            bool isTPINeedPURConfirm = false;
            if ((!trouble_from.ToString().Contains("IN")) && phase.Contains("MP") && (new[] { "ECN/ERI", "FA improvement", "Die transfer", "MP trouble" }.Contains(trouble_name)))
            {
                isTPINeedPURConfirm = true;
            }
            return isTPINeedPURConfirm;
        }

        public int genarateTPIStatusIDAfterEachDEPTApprove(int tpi_id, int currentStatusID, bool isNeedPE1, bool isNeedDMT)
        {
            int nextStatusID = currentStatusID;
            if (currentStatusID == 9) // W-PAE-APP
            {
                if (isNeedPE1 == false && isNeedDMT == false)
                {
                    nextStatusID = genarateTPIStatusFinal(tpi_id);
                }
                if (isNeedPE1 == true && isNeedDMT == false)
                {
                    nextStatusID = 8; //W-PE1-Check
                }
                if (isNeedPE1 == true && isNeedDMT == true)
                {
                    nextStatusID = 10; //W-DMT-Check
                }
                if (isNeedPE1 == false && isNeedDMT == true)
                {
                    nextStatusID = 10; //W-DMT-Check
                }
            }

            if (currentStatusID == 13 || currentStatusID == 14) // W-CRG/PE1-APP
            {
                nextStatusID = genarateTPIStatusFinal(tpi_id);
            }

            if (currentStatusID == 7) // W-DMT-APP
            {
                if (isNeedPE1 == false)
                {
                    nextStatusID = genarateTPIStatusFinal(tpi_id);
                }
                if (isNeedPE1 == true)
                {
                    nextStatusID = 8; //W-PE1-Check
                }
            }


            return nextStatusID;
        }

        public int genarateTPIStatusFinal(int tpi_id)
        {
            string sql = $"SELECT * FROM update_tpi_final_status('{tpi_id}')";
            var data = db.ExcuteQueryAndGetData(sql);
            return int.Parse(data.data[0]["update_tpi_final_status"].ToString());
        }

        public JsonResult api_deleteTPI(int id)
        {
            string msg = "";
            bool status = false;
            var islogin = authen.isLoginAndReturnUserProfile(HttpContext);
            if (!islogin.status)
            {
                msg = "Please login!";
                status = false;
            }
            if(!islogin.dataUsers.Any(e => e.tpi_role_id == 6))
            {
                msg = "You do not have permision!";
                status = false;
            }
            string sqlUpdate = $"UPDATE tpi SET active = false, note = CONCAT_WS(CHR(10),'{DateTime.Now.ToString(commonFunction.ShotDateFormat)}: {islogin.dataUsers[0].user_name} deleted' ,tpi.note) WHERE tpi_id={id}";
            db.ExcuteQueryAndGetData(sqlUpdate);
            status = true;

        exit:
            var result = new
            {
                msg = msg,
                status = status
            };
            return Json(result);
        }
    }
}
