﻿using DMSQV_API.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml.Drawing.Controls;
using OfficeOpenXml.Style;
using System.Linq;
using System.Net.NetworkInformation;
using static DMSQV_API.Controllers.CommonFunction;
using static DMSQV_API.Data.DBConnector;
using static Org.BouncyCastle.Math.Primes;

namespace DMSQV_API.Controllers
{
    public class DTF_API : Controller
    {
        DBConnector db = new DBConnector();
        Authen authen = new Authen();
        CommonFunction commonFunction = new CommonFunction();
        WorkInExcel workInExcel = new WorkInExcel();
        public JsonResult api_getSumarizeDTFPending()
        {
            var result = db.getSumarizeDTFPending();
            return Json(result);
        }

        public JsonResult api_getDTFByID(int id)
        {
            bool status = false;
            string msg = "";
            var islogin = authen.isLoginAndReturnUserProfile(HttpContext);

            dataReturn data = new dataReturn();
            if (islogin.status)
            {
                data = db.getDTFByID(id);
                status = true;
            }
            else
            {
                msg = "Please login!";
                status = false;
            }


        exit:
            var output = new
            {
                status = status,
                msg = msg,
                Data = data.data,
            };
            return Json(output);
        }
        public JsonResult api_getDTFList(string search, string? supplier_id, string? dtf_type_id, int? page = 1, int? pageSize = 50)
        {
            search = search?.Trim();
            bool status = false;
            string msg = "";
            var islogin = authen.isLoginAndReturnUserProfile(HttpContext);

            dataReturn data = new dataReturn();
            if (islogin.status)
            {
                data = db.getDTFList(search, supplier_id, dtf_type_id, page, pageSize);
                status = true;
            }
            else
            {
                msg = "Please login!";
                status = false;
            }


        exit:
            var output = new
            {
                status = status,
                msg = msg,
                recordsTotal = data.totalCount,
                recordsFiltered = data.totalCount,
                page = page,
                pageSize = pageSize,
                Data = data.data,
            };
            return Json(output);
        }

        public jsonResult api_issueDTF(string dtf_type_id, string fixaset_no, string die_no, string current_location_id, string new_location_id, string shot, string transport, string eta_plan, string etd_plan, string reason, string edit_dtf_id)
        {
            bool status = false;
            string msg = "";
            fixaset_no = fixaset_no?.Trim().ToUpper();
            die_no = die_no?.Trim().ToUpper();

            var userLogin = authen.isLoginAndReturnUserProfile(HttpContext);
            if (!userLogin.status)
            {
                status = false;
                msg = "Please login in!";
                goto exit;
            }

            bool isHasNull = commonFunction.checkArrayHasAnyElementNullOrEmpty(new[] { dtf_type_id, fixaset_no, die_no, current_location_id, new_location_id, shot, transport, eta_plan, etd_plan, reason });
            if (isHasNull)
            {
                status = false;
                msg = "Please input all information!";
                goto exit;
            }


            bool isINhouse = userLogin.dataUsers.Any(e => new[] { "DIV1" }.Contains(e.division) && new[] { 3, 4 }.Contains(e.dtf_role_id));
            bool isPUR = userLogin.dataUsers.Any(e => new[] { "PUR" }.Contains(e.dept_name) && new[] { 3, 4 }.Contains(e.dtf_role_id));
            bool isPUC = userLogin.dataUsers.Any(e => new[] { "PUC" }.Contains(e.dept_name) && new[] { 3, 4 }.Contains(e.dtf_role_id));
            string deptAction = "";
            if (!(isINhouse || isPUC || isPUR))
            {
                status = false;
                msg = "You do not have permition!";
                goto exit;
            }
            deptAction = isPUR ? "PUR" : (isPUC ? "PUC" : (isINhouse ? userLogin.dataUsers[0].dept_name : ""));
            // Kiem tra da co tồn tại request đang trong tiến trình xử lí ko?
            // Nếu đã tồn tại => ko cho phép issue
            // Nếu chưa tồn tại => được phép issue
            // ****
            var sqlCheckExistRQ = $"SELECT * FROM dtf WHERE fixaset_no = '{fixaset_no}' AND (is_active = true OR is_active is null) AND dtf_status_id <= 9";
            var existRQ = db.ExcuteQueryAndGetData(sqlCheckExistRQ).data;


            if (existRQ.Count > 0)
            {
                status = false;
                msg = "Already exist request trasfer on processing DFTNo: " + existRQ[0]["dtf_no"];
                goto exit;
            }

            // Kiểm tra DIENO có tồn tại hay ko?
            var sqlCheckDieExist = $"SELECT * FROM dies INNER JOIN models ON models.model_id = dies.model_id WHERE dieno = '{die_no}' AND (dies.is_active IS NULL  OR dies.is_active = true)";
            var existDie = db.ExcuteQueryAndGetData(sqlCheckDieExist).data;
            if (existDie.Count == 0)
            {
                status = false;
                msg = "Die ID is not exist, Pls re-check it";
                goto exit;
            }

            //1. Tạo new request on DB if new issue
            //2. Edit info nếu edit dtf 
            var dtf_id = 0;
            if (String.IsNullOrEmpty(edit_dtf_id))
            {
                string sqlINSERT = $"INSERT INTO public.dtf(dtf_status_id, dtf_no, dtf_type_id, fixaset_no, die_no, shot, etd_plan, eta_plan, transport, current_location_id, new_location_id, model_name,reason_transfer, is_active)  " +
                              $"VALUES (12, '{genarateDTFNo(null, true)}', '{dtf_type_id}', '{fixaset_no}', '{die_no}', '{shot}', '{etd_plan}', '{eta_plan}', '{transport}', '{current_location_id}', '{new_location_id}','{existDie[0]["model_name"]}', '{reason}' ,'false')" +
                              $"RETURNING dtf_id;";

                var resultInsert = db.ExcuteQueryAndGetData(sqlINSERT);
                dtf_id = int.Parse(resultInsert.data[0]["dtf_id"].ToString());
            }
            else
            {
                var currentDTF = db.getDTFByID(int.Parse(edit_dtf_id)).data[0];
                // Edit sql
                string stringUpdate = $"UPDATE dtf " +
                                      $"SET  " +
                                      $"dtf_no = '{genarateDTFNo(currentDTF["dtf_no"].ToString(), false)}',  " +
                                      $"dtf_type_id = '{dtf_type_id}', " +
                                      $"fixaset_no = '{fixaset_no}', " +
                                      $"die_no = '{die_no}', " +
                                      $"shot = '{shot}', " +
                                      $"etd_plan = '{etd_plan}', " +
                                      $"eta_plan = '{eta_plan}', " +
                                      $"transport = '{transport}', " +
                                      $"current_location_id = '{current_location_id}', " +
                                      $"new_location_id = '{new_location_id}', " +
                                      $"model_name = '{existDie[0]["model_name"]}', " +
                                      $"reason_transfer = '{reason}'  " +
                                      $"WHERE dtf_id = '{edit_dtf_id}'";
                db.ExcuteQueryAndGetData(stringUpdate);
                dtf_id = int.Parse(edit_dtf_id);

            }


            var genarateResult = genarateProgress(dtf_id, true, userLogin.dataUsers[0].user_name, deptAction, null, null);
            if (genarateResult)
            {
                status = true;
                msg = "Success";
                goto exit;
            }
            else
            {
                status = false;
                msg = "Error Save Data!";
                goto exit;
            }

        exit:
            jsonResult result = new jsonResult
            {
                msg = msg,
                status = status
            };
            return result;
        }

        public JsonResult api_verifyDTF(string dtf_ids, string comment, bool isReject, bool isCancel, string actual_transfer_date)
        {
            bool status = false;
            string msg = "";
            List<int> success = new List<int>();
            List<string> listFail = new List<string>();
            var userLogin = authen.isLoginAndReturnUserProfile(HttpContext);
            if (!userLogin.status)
            {
                status = false;
                msg = "Please login in!";
                goto exit;
            }
            bool isINhouse = userLogin.dataUsers.Any(e => new[] { "DIV1" }.Contains(e.division) && new[] { 3, 4 }.Contains(e.dtf_role_id));
            bool isPUR = userLogin.dataUsers.Any(e => new[] { "PUR" }.Contains(e.dept_name) && new[] { 3, 4 }.Contains(e.dtf_role_id));
            bool isPUC = userLogin.dataUsers.Any(e => new[] { "PUC" }.Contains(e.dept_name) && new[] { 3, 4 }.Contains(e.dtf_role_id));
            string deptAction = "";
            if (!(isINhouse || isPUC || isPUR))
            {
                status = false;
                msg = "You do not have permition!";
                goto exit;
            }
            deptAction = isPUR ? "PUR" : (isPUC ? "PUC" : (isINhouse ? userLogin.dataUsers[0].dept_name : ""));

            string[] listIDs = dtf_ids.Split(',');
            foreach (var sid in listIDs)
            {
                status = true;
                int id = int.Parse(sid);
                var dtf = db.getDTFByID(id).data[0];
                var deptRes = dtf["dept_res"].ToString();
                bool ispermit = userLogin.dataUsers.Any(e => deptRes.Contains(e.dept_name) && e.dtf_role_id >= e.dcf_role_id);
                if (ispermit)
                {
                    if (isCancel)
                    {
                        bool isCancelPermit = userLogin.dataUsers.Any(e => deptRes.Contains(e.dept_name) && e.dtf_role_id >= e.dcf_role_id && e.dept_name.Contains(dtf["request_dept"].ToString()));
                        if (isCancelPermit)
                        {
                            string sqlCancel = $"UPDATE dtf  " +
                                           $"SET  " +
                                           $"remark = CONCAT_WS(CHR(10),'{DateTime.Now.ToString(commonFunction.ShotDateFormat)} {userLogin.dataUsers[0].user_name} canceled: {comment}' , dtf.remark), " +
                                           $"dtf_status_id = '12'  " +
                                           $"WHERE dtf_id = '{id}'";

                            try
                            {
                                db.ExcuteQueryAndGetData(sqlCancel);
                                success.Add(id);
                            }
                            catch
                            {
                                listFail.Add($"{dtf["dtf_no"]}: [{dtf["die_no"]}] is fail to Cancel!");
                            }
                        }
                        else
                        {
                            listFail.Add($"{dtf["dtf_no"]}: [{dtf["die_no"]}] is fail to Cancel. Only dept request [{dtf["request_dept"]}] can cancel this DTF!");
                        }

                    }
                    if (isReject)
                    {
                        string sqlCancel = $"UPDATE dtf  " +
                                           $"SET  " +
                                           $"remark = CONCAT_WS(CHR(10),'{DateTime.Now.ToString(commonFunction.ShotDateFormat)} {userLogin.dataUsers[0].user_name} rejected: {comment}' , dtf.remark), " +
                                           $"dtf_status_id = '11'  " +
                                           $"WHERE dtf_id = '{id}'";

                        try
                        {
                            db.ExcuteQueryAndGetData(sqlCancel);
                            success.Add(id);
                        }
                        catch
                        {
                            listFail.Add($"{dtf["dtf_no"]}: [{dtf["die_no"]}] is fail to Cancel!");
                        }
                    }
                    if (!isReject && !isCancel)
                    {
                        bool result = genarateProgress(id, false, userLogin.dataUsers[0].user_name, null, comment, actual_transfer_date);
                        if (result)
                        {
                            success.Add(id);
                        }
                        else
                        {
                            listFail.Add($"{dtf["dtf_no"]}: [{dtf["die_no"]}] is fail to check/Approve!");
                        }
                    }

                }
                else
                {
                    listFail.Add($"{dtf["dtf_no"]}: [{dtf["die_no"]}] is not your permision!");
                }

            }



        exit:
            var output = new
            {
                status = status,
                msg = msg,
                success = success,
                listFail = listFail,
            };
            return Json(output);
        }


        public JsonResult api_issueDTFByExcel(IFormFile file)
        {
            string msg = "";
            List<string> listFail = new List<string>();
            int success = 0;
            int fail = 0;
            var userLogin = authen.isLoginAndReturnUserProfile(HttpContext);
            if (!userLogin.status)
            {
                msg = "Please login in!";
                goto exit;
            }
            if (file == null)
            {
                msg = "No file upload!";
                goto exit;
            }
            var data = workInExcel.readListExcelFile(file, 4, 5);
            if (data.status == false)
            {
                msg = data.msg;
                goto exit;
            }
            foreach (var DTF in data.data)
            {

                string type = DTF["Route Type"].ToString();
                string fixedAsset = DTF["Fixed Asset No"].ToString();
                string dieNo = DTF["Die ID"].ToString().ToUpper().Trim();
                string currentLocation = DTF["Current Location (Code) Ex: TABT"].ToString();
                string newLocation = DTF["New Location (Code) Ex: TABT"].ToString();
                string shot = DTF["Shots"].ToString();
                string transport = DTF["Transport"].ToString();
                string ETD = DTF["ETD"].ToString().Trim().ToUpper();
                string ETA = DTF["ETA"].ToString();
                string reason = DTF["Reason Transfer"].ToString();
                

                // xu li du lieu

                // type
                int? dtf_type_id = commonFunction.getNummberInString(type);
                if (dtf_type_id == null)
                {
                    listFail.Add($"{fixedAsset} - [{dieNo}]: Route type '{type}' invalid");
                    fail++;
                    goto exitLoop;
                }

                // current_location_id
                int current_location_id = 0;
                string sqlGetSupplierID = $"SELECT supplier_id FROM suppliers WHERE supplier_code Ilike '{currentLocation}'";
                var supplier = db.ExcuteQueryAndGetData(sqlGetSupplierID).data;
                if (supplier.Count > 0)
                {
                    current_location_id = int.Parse(supplier[0]["supplier_id"].ToString());
                }
                if (current_location_id == 0)
                {
                    listFail.Add($"{fixedAsset} - [{dieNo}]: Current Location '{currentLocation}' invalid");
                    fail++;
                    goto exitLoop;
                }

                // new_location_id
                int new_location_id = 0;
                string sqlGetSupplierID2 = $"SELECT supplier_id FROM suppliers WHERE supplier_code Ilike '{newLocation}'";
                var supplier2 = db.ExcuteQueryAndGetData(sqlGetSupplierID2).data;
                if (supplier2.Count > 0)
                {
                    new_location_id = int.Parse(supplier2[0]["supplier_id"].ToString());
                }
                if (new_location_id == 0)
                {
                    listFail.Add($"{fixedAsset} - [{dieNo}]: New Location '{newLocation}' invalid");
                    fail++;
                    goto exitLoop;
                }

                // ETD
                DateTime newETD;
                bool testDate = DateTime.TryParse(ETD, out newETD);
                if (testDate == false)
                {
                    listFail.Add($"{fixedAsset} - [{dieNo}]: ETD '{ETD}' invalid");
                    fail++;
                    goto exitLoop;
                }

                // ETA
                DateTime newETA;
                bool testDate2 = DateTime.TryParse(ETA, out newETA);
                if (testDate2 == false)
                {
                    listFail.Add($"{fixedAsset} - [{dieNo}]: ETA '{ETA}' invalid");
                    fail++;
                    goto exitLoop;
                }

                // Estimate code
                double shots = 0;
                bool testDouble = double.TryParse(shot, out shots);
                if (testDouble == false)
                {
                    listFail.Add($"{fixedAsset} - [{dieNo}]: Current Location '{ETA}' invalid");
                    fail++;
                    goto exitLoop;
                }

                //transport
                
                if (new[] { "10-Ocean", "40-Air", "50-Post(Truck)", "60-Courie", "90-None Shipment" }.Contains(transport) == false)
                {
                    listFail.Add($"{fixedAsset} - [{dieNo}]: Transport '{ETA}' invalid");
                    fail++;
                    goto exitLoop;
                }

            

                

                var issueResult = api_issueDTF(dtf_type_id.ToString(), fixedAsset,dieNo,current_location_id.ToString(),new_location_id.ToString(), shot, transport,ETA,ETD,reason, null);

                if (issueResult.status == false)
                {
                    listFail.Add($"{fixedAsset} - [{dieNo}]: Issue Fail '{issueResult.msg}'");
                    fail++;
                    goto exitLoop;
                }
                else
                {
                    success++;
                }
            exitLoop:
                ViewBag.exitLoop = "Just exit loop ";
            }
        exit:
            var result = new
            {

                fail = fail,
                success = success,
                listFail = listFail,
                msg = msg
            };
            return Json(result);
        }



        public bool genarateProgress(int dtf_id, bool isNewIssue, string user_name, string requestDept, string comment, string actualTranferDate)
        {
            bool status = false;
            var sqlOutPut = "";
            var dtf = db.ExcuteQueryAndGetData($"SELECT dtf.*,newLocation.supplier_code as new_location, currentLocation.supplier_code as current_location   FROM DTF " +
                                               $"INNER JOIN suppliers newLocation ON newLocation.supplier_id = dtf.new_location_id " +
                                               $"INNER JOIN suppliers currentLocation ON currentLocation.supplier_id = dtf.current_location_id " +
                                               $"WHERE dtf_id = '{dtf_id}'").data[0];
            var route = int.Parse(dtf["dtf_type_id"].ToString());
            var currentStatusID = dtf["dtf_status_id"]?.ToString();
            var newStatus = 0;
            int[] configRoute1Status = { 1, 2, 9, 10 };
            int[] configRoute2Status = { 1, 2, 3, 4, 5, 6, 9, 10 };
            int[] configRoute3Status = { 3, 4, 5, 6, 9, 10 };
            int[] configRoute4Status_Inhouse = { 3, 4, 1, 2, 5, 6, 9, 10 };
            int[] configRoute4Status_Supplier = { 3, 4, 7, 8, 5, 6, 9, 10 };
            int[] configRoute5Status = { 5, 6, 9, 10 };

            // Route = 1~5
            if (route == 1) // status: 1 => 2 => 1(recive) => 2(reciept)
            {
                newStatus = String.IsNullOrEmpty(currentStatusID) ? configRoute1Status[0] : configRoute1Status[Array.IndexOf(configRoute1Status, int.Parse(currentStatusID)) + 1];
            }
            if (route == 2)
            {
                newStatus = String.IsNullOrEmpty(currentStatusID) ? configRoute2Status[0] : configRoute2Status[Array.IndexOf(configRoute2Status, int.Parse(currentStatusID)) + 1];
            }
            if (route == 3)
            {
                newStatus = String.IsNullOrEmpty(currentStatusID) ? configRoute3Status[0] : configRoute3Status[Array.IndexOf(configRoute3Status, int.Parse(currentStatusID)) + 1];
            }

            if (route == 4)
            {
                string[] configCodeInhouse = { "5400", "5500", "3400", "3500" };
                if (Array.IndexOf(configCodeInhouse, dtf["new_location"].ToString()) != -1) // Khuon chuyen ve inhouse
                {
                    newStatus = String.IsNullOrEmpty(currentStatusID) ? configRoute4Status_Inhouse[0] : configRoute4Status_Inhouse[Array.IndexOf(configRoute4Status_Inhouse, int.Parse(currentStatusID)) + 1];

                }
                else // Khuon chuyen tu diemake => Supplier
                {
                    newStatus = String.IsNullOrEmpty(currentStatusID) ? configRoute4Status_Supplier[0] : configRoute4Status_Supplier[Array.IndexOf(configRoute4Status_Supplier, int.Parse(currentStatusID)) + 1];

                }
            }
            if (route == 5)
            {
                newStatus = String.IsNullOrEmpty(currentStatusID) ? configRoute5Status[0] : configRoute5Status[Array.IndexOf(configRoute5Status, int.Parse(currentStatusID)) + 1];
            }

            // Who
            if (isNewIssue)
            {
                sqlOutPut = $"request_by = '{user_name}', " +
                             $"request_date = '{DateTime.Now}', " +
                             $"request_dept = '{requestDept}'  ";

            }
            if (currentStatusID == "1")
            {
                sqlOutPut = $"dmt_check_by = '{user_name}', " +
                            $"dmt_check_date = '{DateTime.Now}' ";
            }
            if (currentStatusID == "2")
            {
                sqlOutPut = $"dmt_app_by = '{user_name}', " +
                             $"dmt_app_date = '{DateTime.Now}' ";
            }
            if (currentStatusID == "3")
            {
                sqlOutPut = $"pur_check_by = '{user_name}', " +
                            $"pur_check_date = '{DateTime.Now}' ";
            }
            if (currentStatusID == "4")
            {
                sqlOutPut = $"pur_app_by = '{user_name}', " +
                            $"pur_app_date = '{DateTime.Now}' ";

            }
            if (currentStatusID == "5")
            {
                sqlOutPut = $"puc_check_by = '{user_name}', " +
                           $"puc_check_date = '{DateTime.Now}' ";

            }
            if (currentStatusID == "6")
            {
                sqlOutPut = $"puc_app_by = '{user_name}', " +
                           $"puc_app_date = '{DateTime.Now}' ";

            }
            if (currentStatusID == "7")
            {
                sqlOutPut = $"pae_check_by = '{user_name}', " +
                           $"pae_check_date = '{DateTime.Now}' ";
            }
            if (currentStatusID == "8")
            {
                sqlOutPut = $"pae_app_by = '{user_name}', " +
                            $"pae_app_date = '{DateTime.Now}' ";
            }
            string subComment = "";
            if (currentStatusID == "9")
            {
                try
                {
                    sqlOutPut = $"actual_transfer_date = '{DateTime.Parse(actualTranferDate)}'::date ";
                    subComment = $"{user_name} updated actual transfer date on {DateTime.Parse(actualTranferDate)}";
                }
                catch
                {
                    return false;
                }


            }

            string subSqlComment = "";
            if (!String.IsNullOrWhiteSpace(comment) || !String.IsNullOrWhiteSpace(subComment))
            {
                subSqlComment = $"remark = CONCAT_WS(CHR(10),'{DateTime.Now.ToString(commonFunction.ShotDateFormat)} {user_name}: {comment}. {subComment} , dtf.remark), ";
               
            } 

            sqlOutPut = $"UPDATE dtf  " +
                $"SET  " + subSqlComment +
                $"is_active = 'true',  " +
                $"dtf_status_id = '{newStatus}', " + sqlOutPut +
                $"WHERE dtf_id = '{dtf_id}'";
            try
            {
                db.ExcuteQueryAndGetData(sqlOutPut);
                status = true;
            }
            catch
            {
                status = false;
            }


            return status;
        }



        public string genarateDTFNo(string currentDTFNo, bool isNew)
        {
            var output = "";
            var today = DateTime.Now;
            string sqlTotalDTFInThisYear = $"SELECT count(*) FROM dtf WHERE EXTRACT(YEAR FROM request_date) = EXTRACT(YEAR FROM CURRENT_DATE);";
            int totalDTFinThisYear = int.Parse(db.ExcuteQueryAndGetData(sqlTotalDTFInThisYear).data[0]["count"].ToString()) + 1;
            string DTFNo = "DTF" + today.ToString("yyMMdd") + "-" + totalDTFinThisYear.ToString().PadLeft(4, '0') + "-00";

            if (isNew != true)
            {
                try
                {
                    if (currentDTFNo != null)
                    {
                        // PUR - 00 => PAE 1st 01 => revise 02,03...
                        var upver = currentDTFNo.Substring(currentDTFNo.Length - 2, 2);
                        int upverInt = (int)commonFunction.getNummberInString(upver) + 1;

                        var mainNo = currentDTFNo.Remove(currentDTFNo.Length - 2, 2);
                        DTFNo = mainNo + upverInt.ToString().PadLeft(2, '0');
                    }
                }
                catch
                {

                }
            }
            // check đã tồn tại số này chưa => nếu chưa đã tồn tại lại genarate lại
            string sqlcheck = $"SELECT dtf_no FROM dtf WHERE dtf_no = '{DTFNo}'";
            if (db.ExcuteQueryAndGetData(sqlcheck).data.Count > 0)
            {
                DTFNo = genarateDTFNo(DTFNo, false);
            }
            return DTFNo;

        }
    }
}
