﻿using DMSQV_API.Data;
using DMSQV_API.Models;
using iTextSharp.text;
using iTextSharp.text.pdf;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Formatters;
using Microsoft.VisualBasic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System;
using System.IO;

namespace DMSQV_API.Controllers
{
    public class CommonFunction : Controller
    {
       public string currentURLHost = System.IO.Directory.GetCurrentDirectory();
        DBConnector db = new DBConnector();
       
        public bool checkArrayHasAnyElementNullOrEmpty<T>(T[] array)
        {
            if ((array == null || array.Length == 0))
            {
                return true;
            }
            else
            {
                return array.Any(item => item == null);
            }

        }

        // 06.OCT.2024 TẠO DIE, PART VÀ COMMON TỪ MANUAL VÀ TỪ MR ISSUE
        public class createDieResult
        {
            public bool status { set; get; }
            public string msg { set; get; }
        }
        public class manualINPUTDieInfor
        {
            public string partNo { get; set; }
            public string dieCode { get; set; }
            public int modelID { get; set; }
            public int supplierID { get; set; }
            public int processCodeID { get; set; }
            public DateTime targetOK { get; set; }

        }
        public class dieInfoNeedConfig
        {
            public int suffix { set; get; }
            public int dieStatusID { set; get; }
            public string dieClasify { set; get; }
            public string belong { set; get; }
            public bool isOfficial { set; get; }
            public bool isCancel { set; get; }
            public bool isActive { set; get; }
            public bool isClose { set; get; }


        }

        public string ShotDateFormat = "yyyy/MM/dd";
        public string LongDateFormat = "yyyy/MM/dd HH:mm tt";


        public string genarateDieClasify(string dieCode)
        {
            return db.ExcuteQueryAndGetData($"SELECT genarate_die_classify('{dieCode}')").data[0]["genarate_die_classify"].ToString();
        //    dieCode = dieCode.Replace(" ", "").Trim();
        //    string output = "INVALID"; // 11A
        //    if (dieCode == null)
        //    {
        //        output = "INVALID";
        //        goto exit;
        //    }

        //    if (dieCode.Length != 3)
        //    {
        //        output = "INVALID";
        //        goto exit;
        //    }

        //    dieCode = dieCode.ToUpper().Trim();

        //    if (dieCode == "11A")
        //    {
        //        output = "New";
        //        goto exit;
        //    }
        //    if (new[] { "2", "3", "4", "8" }.Contains(dieCode[1].ToString())) //12A,12B,13A,14A
        //    {
        //        output = "Renewal";
        //        goto exit;
        //    }
        //    if (dieCode[0] != '1' && dieCode[1] == '1' && dieCode[2] == 'A')
        //    {
        //        output = "Additional";
        //        goto exit;
        //    }
        //    output = "INVALID";
        //exit:
        //    return output;

        }

        public List<createDieResult> genarateAndUpdateNEWDIE(manualINPUTDieInfor? manual, Dictionary<string, object>? MR, Dictionary<string, object>? PO, HttpContext httpcontext)
        {
            bool status = false;
            List<createDieResult> output = new List<createDieResult>();
            // xử lí dữ liệu
            var userLogin = new Authen().isLoginAndReturnUserProfile(httpcontext).dataUsers;
            if (manual != null)
            {
                dieInfoNeedConfig config = new dieInfoNeedConfig();
                config.dieClasify = genarateDieClasify(manual.dieCode);
                if (config.dieClasify.Contains("INVALID"))
                {
                    output.Add(new createDieResult
                    {
                        status = false,
                        msg = "Die No/ Dim is not correct!"
                    });
                    goto exit;
                }

                config.suffix = 1;
                config.dieStatusID = 1;
                config.belong = "LBP";
                config.isOfficial = false;
                config.isCancel = false;
                config.isActive = true;
                config.isClose = false;
                string source = $"Manual create on {DateTime.Now} by {userLogin[0].user_name}";
                int dieID = AddOrUpdateDIE(config, manual, null, null);
                int partID = AddOrUpdatePART(manual.partNo, null, null);
                int commonID = AddOrUpdateCOMMONTABLE(partID, dieID, source, false, false);
                status = commonID > 0;
                output.Add(new createDieResult
                {
                    status = status,
                    msg = status == true ? $"Succes Add Die {manual.partNo} - {manual.dieCode}" : $"Fail Add Die {manual.partNo} - {manual.dieCode}"
                });
            }
            if (MR != null)
            {
                //3.3 kiểm tra số component lớn hơn 1 và add die và common tương ứng.
                //3.4 Kiểm tra commonpart và add Part và Common tương ứng
                //3.5 Kiểm tra family part và add Part và Common tương ứng
                //3.6 trường hợp vừa component lớn hơn 1 và có commonpart và family part
                int NoOfComponent = 1;
                int.TryParse(MR["no_of_die_component"].ToString(), out NoOfComponent);

                string partNoOrginal = MR["part_no"].ToString();
                string commonPart = MR["common_part"].ToString();
                string familyPart = MR["family_part"].ToString();
                string allPart = $"{partNoOrginal},{commonPart},{familyPart}";
                string[] arrayOfAllPart = allPart.Split(',');

                string noteFamily = String.IsNullOrWhiteSpace(MR["family_part"].ToString()) ? "" : MR["family_part"].ToString().Length > 7 ? $"{MR["part_no"].ToString()} family die with {MR["family_part"].ToString()} " : "";
                string noteCommon = String.IsNullOrWhiteSpace(MR["common_part"].ToString()) ? "" : MR["common_part"].ToString().Length > 7 ? $"{MR["part_no"].ToString()} common die with {MR["common_part"].ToString()} " : "";
                string source = $"From MR [{MR["mr_no"]}]";

                // add comom for original part
                for (int i = 1; i <= NoOfComponent; i++)
                {
                    int dieID = 0;
                    // create config
                    bool isOfficial = false;
                    string PoDate = "";
                    string PayDate = "";
                    if (PO != null)
                    {
                        PoDate = PO["podate"].ToString();
                        PayDate = PO["payment_date"]?.ToString();
                        isOfficial = String.IsNullOrWhiteSpace(PoDate) ? false : true;

                    }
                    dieInfoNeedConfig config = new dieInfoNeedConfig();
                    config.dieClasify = genarateDieClasify(MR["clasification"]?.ToString());
                    config.suffix = i;
                    config.dieStatusID = String.IsNullOrWhiteSpace(PayDate) ? 1 : 2;
                    config.belong = new[] { "INHOUSE", "LBP" }.Contains(MR["belong"].ToString()) ? "LBP" : (new[] { "CRG" }.Contains(MR["belong"].ToString()) ? "CRG" : "OTHER");
                    config.isOfficial = isOfficial;
                    config.isCancel = false;
                    config.isActive = true;
                    config.isClose = false;
                    if (config.dieClasify.Contains("INVALID"))  // MR Modify
                    {
                        // MR modify có thể add common part 
                        // Lúc này DieID sẽ là die đã tồn tại đang issue MR để modify
                        string sqlGetDieID = $"SELECT die_id FROM dies WhERE dieno = '{MR["die_no"]}'";
                        dieID = int.Parse(db.ExcuteQueryAndGetData(sqlGetDieID).data[0]["die_id"].ToString());
                    }
                    else
                    // ADD DIE
                    {

                        dieID = AddOrUpdateDIE(config, null, MR, PO);
                    }

                    // ADD PART AND COMMON
                    foreach (var raw_part in arrayOfAllPart)
                    {
                        string part = raw_part.Replace(" ", "").Trim();
                        if (part.Length >= 8)
                        {
                            string note = "";
                            bool isCommon = false;
                            bool isFamaily = false;
                            part = part.Length == 8 ? $"{part}-000" :(part.Length >12 ? part.Substring(0,12) : part.PadRight(12, '0') );
                            if (commonPart.Contains(raw_part))
                            {
                                isCommon = true;
                                note = noteCommon;
                            }
                            if (familyPart.Contains(raw_part))
                            {
                                isFamaily = true;
                                note = noteFamily;
                            }
                            int partID = AddOrUpdatePART(part, MR["part_name"].ToString(), note);
                            int commonID = AddOrUpdateCOMMONTABLE(partID, dieID, source, isCommon, isFamaily);
                            status = commonID > 0;
                            output.Add(new createDieResult
                            {
                                status = status,
                                msg = status == true ? $"Succes Added/Updated Die Info {MR["part_no"]} - {MR["clasification"]}" : $"Fail Add/Update Die {MR["part_no"]} - {MR["clasification"]}"
                            });
                        }
                    }
                }
            }

        exit:
            return output;
        }

        public int AddOrUpdateDIE(dieInfoNeedConfig config, manualINPUTDieInfor? manual, Dictionary<string, object>? MR, Dictionary<string, object>? PO)
        {
            //1: ADD DIE
            //1.1: Kiểm tra die đã tồn tại chưa
            //1.2: Add hoặc Edit => Lấy die_id
            int dieID = 0;
            string sql = "";
            string formattedSuffix = config.suffix.ToString().PadLeft(3, '0');
            string dieNo = "";

            if (manual != null)
            {
                dieNo = manual.partNo + "-" + manual.dieCode + "-" + formattedSuffix;
                sql = $"INSERT INTO dies (dieno, part_no_original,die_code, process_code_id, die_classify, belong, model_id, supplier_id, die_status_id, is_official, is_cancel, is_active, is_closed)  " +
                          $"VALUES ('{dieNo}','{manual.partNo}','{manual.dieCode}','{manual.processCodeID}','{config.dieClasify}','{config.belong}','{manual.modelID}','{manual.supplierID}','{config.dieStatusID}', '{config.isOfficial}', '{config.isCancel}','{config.isActive}', '{config.isClose}' )  " +
                          $"ON CONFLICT (dieno)  " +
                          $"DO UPDATE  " +
                          $"SET  " +
                              $"part_no_original = '{manual.partNo}', " +
                              $"die_code = '{manual.dieCode}', " +
                              $"process_code_id = '{manual.processCodeID}', " +
                              $"die_classify = '{config.dieClasify}', " +
                              $"belong = '{config.belong}', " +
                              $"model_id = '{manual.modelID}'::int, " +
                              $"supplier_id = '{manual.supplierID}'::int, " +
                              $"die_status_id = '{config.dieStatusID}', " +
                              $"is_official = '{config.isOfficial}', " +
                              $"is_cancel = '{config.isCancel}', " +
                              $"is_active = '{config.isActive}', " +
                              $"is_closed = '{config.isClose}' " +
                              $"RETURNING die_id";
            }

            if (MR != null)
            {
                string subQLPO = "";
                dieNo = MR["part_no"] + "-" + MR["clasification"] + "-" + formattedSuffix;
                if (PO != null)
                {
                    string subPayDate = String.IsNullOrEmpty(PO["payment_date"]?.ToString()) ? "" : $" start_use = '{PO["payment_date"]}', ";
                    string subWarranty = String.IsNullOrEmpty(PO["warranty_shot"]?.ToString()) ? "" : $" die_warranty_short = '{PO["warranty_shot"]}', ";
                    string subPOdate = String.IsNullOrEmpty(MR["po_date"]?.ToString()) ? "" : $" po_date = '{MR["po_date"].ToString()}', ";
                    subQLPO = subPayDate + subWarranty + subPOdate;
                }

                string subQLDieCost = String.IsNullOrEmpty(MR["app_cost_exchange_usd"]?.ToString()) ? "" : $" die_cost_usd = '{MR["app_cost_exchange_usd"].ToString()}', ";
                sql = $"INSERT INTO dies (dieno, part_no_original,die_code, process_code_id, die_classify, belong, mc_size, cav_quantity, model_id, supplier_id, die_maker, die_make_location, special_spec, die_cost_usd, po_date,die_status_id, is_official, is_cancel, is_active, is_closed)  " +
                      $"VALUES ('{dieNo}','{MR["part_no"]}','{MR["clasification"]}','{MR["process_code_id"]}','{config.dieClasify}','{config.belong}','{MR["mc_size"]}','{MR["cav_qty"]}','{MR["model_id"]}','{MR["supplier_id"]}','{MR["die_maker"]}', '{MR["make_location"]}', '{MR["die_special"]}', '{MR["app_cost_exchange_usd"]}','{MR["po_date"]}', '{config.dieStatusID}', '{config.isOfficial}', '{config.isCancel}','{config.isActive}', '{config.isClose}' )  " +
                      $"ON CONFLICT (dieno)  " +
                      $"DO UPDATE  " +
                      $"SET  " +
                          $"part_no_original = '{MR["part_no"]}', " +
                          $"die_code = '{MR["clasification"]}', " +
                          $"process_code_id = '{MR["process_code_id"]}', " +
                          $"die_classify = '{config.dieClasify}', " +
                          $"belong = '{config.belong}', " +
                          $"mc_size = '{MR["mc_size"]}'::int, " +
                          $"cav_quantity = '{MR["cav_qty"]}'::int, " +
                          $"model_id = '{MR["model_id"]}'::int, " +
                          $"supplier_id = '{MR["supplier_id"]}'::int, " +
                          $"die_maker = '{MR["die_maker"]}', " +
                          $"die_make_location = '{MR["make_location"]}', " +
                          $"special_spec = '{MR["die_special"] + System.Environment.NewLine}' || dies.special_spec, " +
                          $" {subQLDieCost} " +
                          $" {subQLPO} " +
                          $"die_status_id = '{config.dieStatusID}', " +
                          $"is_official = '{config.isOfficial}', " +
                          $"is_cancel = '{config.isCancel}', " +
                          $"is_active = '{config.isActive}', " +
                          $"is_closed = '{config.isClose}' " +
                          $"RETURNING die_id";
            }

            dieID = int.Parse(db.ExcuteQueryAndGetData(sql).data[0]["die_id"].ToString());

            return dieID;
        }

        public int AddOrUpdatePART(string partNo, string? partName, string? note)
        {
            //2.1 Kiểm tra đã tồn tại part này chưa?
            //2.2 Add hoặc Edit => Lấy part_id
            int partID = 0;
            string sql = $"INSERT INTO parts (part_no, part_name, note)" +
                         $"VALUES ('{partNo.ToUpper()}','{partName}','{note}') " +
                         $"ON CONFLICT (part_no) " +
                         $"DO UPDATE  " +
                         $"SET part_name = '{partName}', " +
                         $"note = '{note}' " +
                         $"RETURNING part_id";
            partID = int.Parse(db.ExcuteQueryAndGetData(sql).data[0]["part_id"].ToString());
            return partID;
        }

        public int AddOrUpdateCOMMONTABLE(int partID, int dieID, string sourceFrom, bool isCommon, bool isFamily)
        {
            //3.1 Kiểm tra đã có common này chưa,
            //3.2 Add hoặc edit
            int commonID = 0;
            string sql = $"INSERT INTO common_die (die_id, part_id, is_active, issue_date, source_from, is_common_part, is_family_die) " +
                $"VALUES({dieID},{partID},true, '{DateTime.Now}', '{sourceFrom}', '{isCommon}', '{isFamily}') " +
                $"ON CONFLICT(die_id, part_id) " +
                $"DO UPDATE " +
                $"set is_active = true, " +
                $" is_common_part = {isCommon}, " +
                $" is_family_die = {isFamily}, " +
                $"source_from = '{DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss ") + sourceFrom + System.Environment.NewLine}' || common_die.source_from " +
                $"RETURNING common_id ";
            var dataResult = db.ExcuteQueryAndGetData(sql).data[0];
            commonID = int.Parse(dataResult["common_id"].ToString());
            return commonID;
        }




        // Save file vật lí



        public byte[] ConvertExcelToPDF(byte[] file)
        {
            try
            {
                // Convert the byte array to a memory stream
                using (MemoryStream stream = new MemoryStream(file))
                {
                    // Load the Excel file from the memory stream
                    Aspose.Cells.Workbook workbook = new Aspose.Cells.Workbook(stream);

                    // Save the Excel file to a PDF format in a new memory stream
                    using (MemoryStream pdfStream = new MemoryStream())
                    {
                        workbook.Save(pdfStream, Aspose.Cells.SaveFormat.Pdf);

                        // Return the PDF file as a byte array
                        return RemoveWarningLicenseOfAsposeInPDF(pdfStream.ToArray());
                    }
                }
            }
            catch (Exception ex)
            {
                // Log the exception (optional)
                Console.WriteLine("An error occurred: " + ex.Message);

                // Handle the exception (optional)
                // You can return null or throw the exception based on your requirements
                return null;
            }
        }



        public byte[] RemoveWarningLicenseOfAsposeInPDF(byte[] file)
        {
            try
            {
                // Convert byte array to memory stream
                using (MemoryStream inputStream = new MemoryStream(file))
                {
                    // Read the original PDF
                    PdfReader reader = new PdfReader(inputStream);
                    using (MemoryStream outputStream = new MemoryStream())
                    {
                        // Create the document and writer
                        iTextSharp.text.Document document = new iTextSharp.text.Document();
                        PdfWriter writer = PdfWriter.GetInstance(document, outputStream);
                        document.Open();

                        // Process each page of the original PDF
                        for (var i = 1; i <= reader.NumberOfPages; i++)
                        {

                            var baseFont = BaseFont.CreateFont(BaseFont.HELVETICA_BOLD, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
                            var importedPage = writer.GetImportedPage(reader, i);
                            document.SetPageSize(importedPage.BoundingBox);
                            document.NewPage();
                            var contentByte = writer.DirectContent;
                            Rectangle pageSize = reader.GetPageSizeWithRotation(i);
                            contentByte.BeginText();
                            contentByte.SetFontAndSize(baseFont, 8);
                            var page = "PAGE: (" + Convert.ToString(i) + "/" + Convert.ToString(reader.NumberOfPages) + ")";
                            contentByte.AddTemplate(importedPage, 0, 12);
                            contentByte.ShowTextAligned(PdfContentByte.ALIGN_LEFT, page, importedPage.Width - 60, 15, 0);
                            contentByte.EndText();
                        }

                        // Close the document
                        document.Close();
                        writer.Close();
                        reader.Close();

                        // Return the PDF as a byte array
                        return outputStream.ToArray();
                    }
                }
            }
            catch (Exception ex)
            {
                // Log the exception (optional)
                Console.WriteLine("An error occurred: " + ex.Message);
                return null;
            }
        }

        //*********************
        public class ACC_Info
        {
            public string G_L { set; get; }
            public string location { set; get; }
            public string assetNumber { set; get; }
        }

        public class jsonResult
        {
            public bool status { set; get; }
            public string msg { set; get; }
            public object data { set; get; }
        }
        public class exchangeMoneyToVND_USD_JPY
        {
            public double VND { set; get; }
            public double USD { set; get; }
            public double JPY { set; get; }
            public double rateVNDtoUSD { set; get; }
            public double rateJPYtoUSD { set; get; }
        }

        // Save file to attachment table
        public int SaveAttachment(int die_id, int? dsum_id, IFormFile file, string clasify, string pathFolder, string fileNameWithoutExt, string user_name)
        {
            // VIẾT HÀM ĐỂ LƯU FILE VẬT LÍ VÀ LƯU VÀO BẢNG ATTACHMENT
            string fullPath = savePhysicalFileOnServer(file, pathFolder, fileNameWithoutExt);
            var dsum_id_str = dsum_id == null ? "null" : dsum_id.ToString();
            string sql = $"INSERT INTO public.attachment(die_id, clasify, dsum_id, file_name, path, create_by, create_date)  " +
                $"VALUES ('{die_id}', '{clasify}', {dsum_id_str}, '{fileNameWithoutExt}', '{fullPath}', '{user_name}', '{DateTime.Now}');";
            db.ExcuteQueryAndGetData(sql);
            return 0;
        }
        public string savePhysicalFileOnServer(IFormFile file, string pathFolder, string fileNameWithoutExt)
        {
            // return path file
            // pathFolder = "/File/Folder1/.../"
            string outputFullPath = "";
            if (file == null)
            {
                outputFullPath = "";
                goto exit;
            }
            var fileName = Path.GetFileNameWithoutExtension(fileNameWithoutExt)+"_" + encodePassword.RandomString(4) + "_" + DateTime.Now.ToString("yyyyMMdd HH-mm-ss") + Path.GetExtension(file.FileName);
            outputFullPath = Path.Combine(pathFolder, fileName);

            try
            {
                using (var stream = new FileStream(currentURLHost + outputFullPath, FileMode.Create))
                {
                    file.CopyTo(stream);
                }
            }
            catch (Exception ex)
            {
                outputFullPath = "";
            }
        exit:
            return outputFullPath;
        }

        public bool DeletePhysicalFileOnServer(string filePath)
        {
            try
            {
                // Check if the file exists
                if (System.IO.File.Exists(filePath))
                {
                    // Delete the file
                    System.IO.File.Delete(filePath);
                   
                    return true; // Return true if the file is deleted
                }
                else
                {
                    return false; // Return false if the file does not exist
                }
            }
            catch (Exception ex)
            {
                // Log the error (you can replace this with a logging framework)
                Console.WriteLine($"Error deleting file: {ex.Message}");
                return false; // Return false if an error occurred
            }
        }

        public ACC_Info genarateACCInfo(int mr_Type_id, double price, string unit, string belong, string ModelColorOrMono, string supplierCode, string partNo)
        {
            ACC_Info acc = new ACC_Info();
            bool isNeedCapitalBudget = isNeedCapitalBugdet(mr_Type_id, price, unit);
            // 1.GL Account:
            //Nếu X7  => A214-307800-3120-3200
            if (mr_Type_id == 8) //X7-Repair
            {

                if (belong.Contains("CRG")) // CRG
                {
                    acc.G_L = "A214-307800-4850";
                }
                else // LBP
                {
                    acc.G_L = "A214-307800-3120";
                }
            }
            else
            {
                if (isNeedCapitalBudget == true) // Nếu khác X7 và price >30trVND => 2170-001000
                {
                    acc.G_L = "2170-001000";
                }
                else// Other(else) => A212-103000-3120-3200
                {
                    if (belong.Contains("CRG")) // CRG
                    {
                        acc.G_L = "A212-103000-4850";
                    }
                    else // LBP
                    {
                        acc.G_L = "A212-103000-3120";
                    }
                }
                if (price == 10)
                {
                    acc.G_L = "-";
                }
            }

            // 2. Location
            // nếu Inhouse (Code: 5400 || 5500)
            if (!String.IsNullOrEmpty(ModelColorOrMono))
            {
                var Inhouse = new string[] { "5400", "5500", "3400", "3500" };
                if (Inhouse.Contains(supplierCode))
                {
                    if (belong.Contains("CRG")) // CRG
                    {
                        acc.location = "963-CRG";
                    }
                    else // LBP
                    {
                        if (ModelColorOrMono.ToUpper().Contains("MONO"))
                        {
                            acc.location = "964-MONO";
                        }
                        else
                        {
                            acc.location = "965-COLOR";
                        }
                    }

                }
                else
                {
                    if (belong.Contains("CRG")) // CRG
                    {
                        acc.location = "964-CRG";
                    }
                    else // LBP
                    {
                        if (ModelColorOrMono.ToUpper().Contains("MONO"))
                        {
                            acc.location = "961-MONO";
                        }
                        else
                        {
                            acc.location = "963-COLOR";
                        }
                    }

                }
            }
            else
            {
                acc.location = "-";
            }


            // 3.AssetNumber
            string first2LeterOfPartNo = partNo.Substring(0, 2);

            if (new string[] { "RX", "FX", "RJ" }.Contains(first2LeterOfPartNo)) // Packing part
            {
                acc.assetNumber = "08140P";
            }
            else
            {
                acc.assetNumber = "08110P";
            }

            return acc;

        }

        public bool isNeedCapitalBugdet(int mr_Type_id, double price, string unit)
        {
            bool isNeed = false;
            if (mr_Type_id == 8) // X7
            {
                isNeed = false;
                goto exit;
            }
            var exchageValue = ExchangeVNDandJPYUSD(price, unit);
            if (exchageValue.VND > 30000000)
            {
                isNeed = true;
            }

        exit:
            return isNeed;
        }

        public exchangeMoneyToVND_USD_JPY ExchangeVNDandJPYUSD(double amount, string unit)
        {
            unit = unit?.Replace(" ", "").Trim().ToUpper();
            string sqlGetExchangeRate = $"SELECT * from exchange_rate where exchange_id in (select max(exchange_id) from exchange_rate)";
            var exchangeRate = db.ExcuteQueryAndGetData(sqlGetExchangeRate).data[0];

            exchangeMoneyToVND_USD_JPY output = new exchangeMoneyToVND_USD_JPY();
            output.rateVNDtoUSD = double.Parse(exchangeRate["rate_vnd_to_usd"].ToString());
            output.rateJPYtoUSD = double.Parse(exchangeRate["rate_jpy_to_usd"].ToString());
            if (unit == "VND")
            {
                output.VND = amount;
                output.USD = amount / output.rateVNDtoUSD;
                output.JPY = amount / output.rateVNDtoUSD * output.rateJPYtoUSD;
            }
            if (unit == "USD")
            {
                output.VND = amount * output.rateVNDtoUSD;
                output.USD = amount;
                output.JPY = amount * output.rateJPYtoUSD;
            }
            if (unit == "JPY")
            {
                output.VND = amount / output.rateJPYtoUSD * output.rateVNDtoUSD;
                output.USD = amount / output.rateJPYtoUSD;
                output.JPY = amount;
            }
            return output;
        }

        public int createModel(string model_Name)
        {
            int model_id = 0;
            model_Name = model_Name.Trim().ToUpper();
            string sqlChecExistModel = $"SELECT model_id FROM models WHERE model_name ilike '%{model_Name}%'";
            var checkExist = db.ExcuteQueryAndGetData(sqlChecExistModel).data;
            if (checkExist.Count > 0)
            {
                model_id = int.Parse(checkExist[0]["model_id"].ToString());
            }
            else
            {
                string sql = $"INSERT INTO models (model_name, phase, issue_date, is_active)  " +
               $"VALUES('{model_Name}','MT', '{DateTime.Now}', true ) " +
               $"ON CONFLICT (model_name) " +
               $"DO UPDATE SET Model_name = '{model_Name}'  " +
               $"RETURNING model_id";

                model_id = int.Parse(db.ExcuteQueryAndGetData(sql).data[0]["model_id"].ToString());
            }

            return model_id;
        }

        public int genarateMRtypeID(string dim)
        {
            // Neu thay doi logic thi phai thay doi trong file mr.component.ts cua front end

            int mr_type_id = 0;
            if (dim == null)
            {
                return mr_type_id;
            }
            dim = dim?.ToUpper().Trim();
            string last2leterOfDim = dim?.Substring(1, 2);

            if (dim == "11A")
            {
                mr_type_id = 1;
            }
            if (dim[0] != '1' && last2leterOfDim == "1A")
            {
                mr_type_id = 2;
            }
            if (last2leterOfDim == "2A")
            {
                mr_type_id = 3;
            }
            if (last2leterOfDim == "3A")
            {
                mr_type_id = 4;
            }
            if (dim[1] == '4')
            {
                mr_type_id = 5;
            }
            if (dim[1] == '5')
            {
                mr_type_id = 6;
            }
            if (dim[1] == '6')
            {
                mr_type_id = 7;
            }
            if (dim[1] == '7')
            {
                mr_type_id = 8;
            }
            if (dim[1] == '8')
            {
                mr_type_id = 9;
            }
            if (dim[1] == '9')
            {
                mr_type_id = 10;
            }
            return mr_type_id;
        }

        public int? getNummberInString(string str_num)
        {

            string numbersOnly = Regex.Replace(str_num, "[^0-9]", "");
            int num = 0;
            bool isNum = int.TryParse(numbersOnly, out num);
            int? result = isNum ? num : new Nullable<Int32>();
            return result;

        }

        public  IFormFile ConvertFileInfoToIFormFile(FileInfo fileInfo)
        {
            using (var fileStream = fileInfo.OpenRead())
            {
                var fileContent = new MemoryStream();
                fileStream.CopyTo(fileContent);
                fileContent.Position = 0;

                return new FormFile(fileContent, 0, fileContent.Length, fileInfo.Name, fileInfo.Name)
                {
                    Headers = new HeaderDictionary(),
                    ContentType = "application/octet-stream"
                };
            }
        }
        public int genarateTPILevelID(string deadline)
        {
            int output = 3;
            DateTime deadLineConvert = DateTime.Now;
            bool isConvert = DateTime.TryParse(deadline, out deadLineConvert);
            if(isConvert == true)
            {
                DateTime today = DateTime.Now;
                output = deadLineConvert.Subtract(today).Days > 14 ? 1 : deadLineConvert.Subtract(today).Days > 7 ? 2 : 3;
            }
          
            return output;
        }

        public string trimAllSpace(string str)
        {
           return str.Replace(" ", "");
           
        }

    }
}
