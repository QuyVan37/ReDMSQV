﻿using Aspose.Cells;
using DMSQV_API.Data;
using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml;
using System;
using static DMSQV_API.Data.DBConnector;

namespace DMSQV_API.Controllers
{
    public class WorkInExcel : Controller
    {
        DBConnector db = new DBConnector();
        CommonFunction commonfunction = new CommonFunction();
        string currentURLHost = System.IO.Directory.GetCurrentDirectory();
        public class resultReadExcel
        {
            public bool status { set; get; }
            public string msg { set; get; }
            public List<Dictionary<string, object>> data { set; get; }
        }

        public class resultWriteExcel
        {
            public bool status { set; get; }
            public string msg { set; get; }
            public string fileGuid { set; get; }
            public string fileName { set; get; }
            public string contentType { set; get; }

        }

        public class configColumToWrite
        {
            public string Column { set; get; }
            public string cell { set; get; }
            public string ColumnTitle { set; get; }
            public string dataTitle { set; get; }
        }

        public class verifyForm
        {
            public bool isPass { set; get; }
            public string msg { set; get; }
        }

        public class tpiData
        {
            public int FinalStatusID { set; get; }
            public string TroubleFrom { set; get; }
            public bool isNeedRPA { set; get; }
            public int die_id { set; get; }
            public int tpi_id { set; get; }
            public string SubmitType { set; get; }
            public string TroubleName { set; get; }
            public string dieNo { set; get; }
            public string partNo { set; get; }
            public string cavNG { set; get; }
            public string TotalCav { set; get; }
            public int MCsize { set; get; }
            public string ecn_eriNo { set; get; }
            public DateTime? happenDate { set; get; }
            public double shot { set; get; }
            public int DieTroubleRunningStatusID { set; get; }
            public int TroubleLevelID { set; get; }
            public string phase { set; get; }
            public string proccesNG { set; get; }
            public string dieMaterial { set; get; }
            public string supplierCode { set; get; }
            public string supplierName { set; get; }
            public string TPINo { set; get; }
            public DateTime? dueDate { set; get; }
            public string DieBelong { set; get; }
            public bool IsNeedPURConfirm { set; get; }
            public DateTime SubmitDate { set; get; }
            public string SubmitBy { set; get; }
            public string Progress { set; get; }
            public string ReportFromPur { set; get; }
            public string Report { set; get; }
            public bool Active { set; get; }
        }

        public resultReadExcel readListExcelFile(IFormFile file, int titelRow, int startRow)
        {

            resultReadExcel result = new resultReadExcel();
            if (file == null)
            {
                result.status = false;
                result.msg = "No file upload!";
                return result;
            }

            if (!Path.GetExtension(file.FileName).Contains(".xls"))
            {
                result.status = false;
                result.msg = "File must excel!";
                return result;
            }

            string fileGuid = Guid.NewGuid().ToString();
            MemoryStream output = new MemoryStream();
            Object linkdowload = new Object();
            using (ExcelPackage package = new ExcelPackage(file.OpenReadStream()))
            {
                ExcelWorksheet sheet = package.Workbook.Worksheets.First();
                var start = sheet.Dimension.Start;
                var end = sheet.Dimension.End;
                List<Dictionary<string, object>> data = new List<Dictionary<string, object>>();


                for (int row = startRow; row <= end.Row; row++)
                {
                    var rowData = new Dictionary<string, object>();
                    for (int i = 1; i <= end.Column; i++)
                    {
                        var title = sheet.Cells[titelRow, i].Text.Trim();
                        var value = sheet.Cells[row, i].Text.Trim();
                        rowData.Add(title, value);
                    }
                    data.Add(rowData);
                }


                result.status = true;
                result.data = data;
            }

            return result;
        }

        public resultWriteExcel writeListExcelFile(string pathFullFormExcel, int startRow, int starCol, string[] cols, dataReturn data, HttpContext httpContext)
        {
            MemoryStream output = new MemoryStream();
            string fileGuid = Guid.NewGuid().ToString();

            using (ExcelPackage package = new ExcelPackage(new FileInfo(pathFullFormExcel)))
            {
                ExcelWorksheet sheet = package.Workbook.Worksheets.First();
                int row = startRow;
                int col = starCol;
                for (int i = 0; i < data.data.Count; i++)
                {
                    var rowData = data.data[i];
                    for (int j = 0; j < cols.Length; j++)
                    {

                        sheet.Cells[row, col + j].Value = rowData[cols[j]];
                    }
                    row++;
                }

                package.SaveAs(output);
            }
            output.Position = 0;
            httpContext.Session.Set(fileGuid, output.ToArray());
            var fileName = Path.GetFileNameWithoutExtension(pathFullFormExcel);
            var extension = Path.GetExtension(pathFullFormExcel);
            fileName = fileName + DateTime.Now.ToString("yyyyMMdd HHmmss") + extension;
            resultWriteExcel result = new resultWriteExcel()
            {
                status = true,
                msg = "",
                fileGuid = fileGuid,
                fileName = fileName,
                contentType = "application/vnd.ms-excel"
            };

            return result;
        }

        public verifyForm verifyTPIForm(IFormFile reportFile, string? dieNoCheck)
        {

            // Trả về kết quả verify
            // Nhiệm vụ của verify 
            // 1. Check format đúng version hay ko?
            // 2. check thông tin đã nhập đầy đủ hay ko?
            // 3. Check Die tồn tại hay ko?

            bool isPass = false;
            string msg = "";
            if (reportFile == null)
            {
                isPass = false;
                msg = "No File upload";
                goto Exit;
            }

            if (!reportFile.FileName.Contains(".xls"))
            {
                isPass = false;
                msg = "Must Excel (.xlsx)";
                goto Exit;
            }

            // 1. Check format đúng version chưa
            var Y1 = "LPE-0010";
            var Y2 = "Att.06/Rev 01";
            var R11 = "Final Decision";
            var G17 = "PAE confirm";
            var B59 = "For Inhouse/CRG/PUR";
            var U63 = "Information refer";


            using (ExcelPackage package = new ExcelPackage(reportFile.OpenReadStream()))
            {
                ExcelWorksheet worksheet = package.Workbook.Worksheets.First();
                // Check version

                var y1 = worksheet.Cells["Y1"].Text.Trim();
                var y2 = worksheet.Cells["Y2"].Text.Trim();

                //Check hàng

                var r11 = worksheet.Cells["R11"].Text.Trim();
                var g17 = worksheet.Cells["G17"].Text.Trim();
                var b59 = worksheet.Cells["B59"].Text.Trim();
                var u63 = worksheet.Cells["U63"].Text.Trim();

                if ((Y1 != y1 || Y2 != y2))
                {
                    msg = "Wrong Format, Collunm Y1 = " + Y1 + " & Collunm Y2 = " + Y2;
                    isPass = false;
                    goto Exit;
                }
                else
                {
                    if ((R11 != r11 || G17 != g17 || B59 != b59 || U63 != u63))
                    {
                        msg = "Wrong Format, Format was add/delete Collunm or Row";
                        isPass = false;
                        goto Exit;
                    }
                    else
                    {
                        // Format OK
                        // 2.Check Đã đủ thông tin chưa
                        var SubmitType = worksheet.Cells["F4"].Text.Trim();
                        var classification = worksheet.Cells["F5"].Text.Trim();
                        var dieNo = worksheet.Cells["F6"].Text.Trim();
                        var partNo = worksheet.Cells["F7"].Text.Trim();
                        var cavNG = worksheet.Cells["F8"].Text.Trim();
                        var TotalCav = worksheet.Cells["F9"].Text.Trim();
                        var MCsize = worksheet.Cells["F10"].Text.Trim();
                        var ecn_eriNo = worksheet.Cells["P4"].Text.Trim();
                        var happenDate = worksheet.Cells["P5"].Text.Trim();
                        var shot = worksheet.Cells["P6"].Text.Trim();
                        var prodStatus = worksheet.Cells["P7"].Text.Trim();
                        var phase = worksheet.Cells["P8"].Text.Trim();
                        var proccesNG = worksheet.Cells["P9"].Text.Trim();
                        var dieMaterial = worksheet.Cells["P10"].Text.Trim();
                        var supplierCode = worksheet.Cells["W3"].Text.Trim();
                        var TPINo = worksheet.Cells["L3"].Text.Trim();
                        var dueDate = worksheet.Cells["X10"].Text.Trim();

                        if (String.IsNullOrWhiteSpace(SubmitType) || String.IsNullOrWhiteSpace(classification) || String.IsNullOrWhiteSpace(dieNo) ||
                            String.IsNullOrWhiteSpace(partNo) || String.IsNullOrWhiteSpace(cavNG) || String.IsNullOrWhiteSpace(TotalCav) ||
                            String.IsNullOrWhiteSpace(MCsize) || String.IsNullOrWhiteSpace(shot) || String.IsNullOrWhiteSpace(prodStatus) ||
                            String.IsNullOrWhiteSpace(phase) || String.IsNullOrWhiteSpace(proccesNG) || String.IsNullOrWhiteSpace(dieMaterial) || String.IsNullOrWhiteSpace(supplierCode))
                        {
                            msg = "Field (*) must input!";
                            isPass = false;
                            goto Exit;
                        }

                        string sqlCheckDie = $"SELECT * FROM dies WHERE dieno ='{dieNo}' ";
                        var existDie = db.ExcuteQueryAndGetData(sqlCheckDie).data;
                        if (existDie.Count == 0)
                        {
                            msg = "Die ID: " + dieNo + " not exist!.";
                            isPass = false;
                            goto Exit;
                        }


                        if (!String.IsNullOrEmpty(dieNoCheck))
                        {
                            if (dieNoCheck != dieNo)
                            {
                                msg = "Maybe you upload wrong TPI, Die ID on TPI: " + dieNo + " but you'r checking TPI for Die ID " + dieNoCheck;
                                isPass = false;
                                goto Exit;
                            }
                        }


                        if (SubmitType == "Revise/Feedback")
                        {
                            // Check Old TPI đúng dieNo ko?
                            string sqlSearchTPI = $"select d.dieno from tpi inner join dies d ON d.die_id = tpi.die_id where tpi_no = '{TPINo}'";
                            var oldTPI = db.ExcuteQueryAndGetData(sqlSearchTPI).data;
                            if (oldTPI.Count > 0)
                            {
                                if (oldTPI[0]["dieno"].ToString() != dieNo)
                                {
                                    msg = SubmitType + " for TPI_No: " + TPINo + $"[{oldTPI[0]["dieno"]}] But DieID input is [{dieNo}]!";
                                    isPass = false;
                                    goto Exit;
                                }
                                else
                                {
                                    msg = "OK";
                                    isPass = true;
                                }
                            }
                            else
                            {
                                msg = "Submit Type is [" + SubmitType + "] must keep TPI_No, Plz check again!";
                                isPass = false;
                                goto Exit;
                            }
                        }

                        if (classification == "ECN/ERI")
                        {
                            if (String.IsNullOrWhiteSpace(ecn_eriNo))
                            {
                                msg = "Classification* = " + classification + " must input ENC/ERINo. Plz input it!";
                                isPass = false;
                                goto Exit;
                            }
                        }
                        isPass = true;

                    }
                }


            }

        Exit:
            var output = new verifyForm()
            {
                isPass = isPass,
                msg = msg
            };
            return output;
        }

        public tpiData readTPI(tpiData tpi, IFormFile reportFile)
        {
            if (reportFile == null)
            {
                return tpi;
            }
            var today = DateTime.Now;
            using (ExcelPackage package = new ExcelPackage(reportFile.OpenReadStream()))
            {
                ExcelWorksheet worksheet = package.Workbook.Worksheets.First();
                // 2.Check Đã đủ thông tin chưa
                tpi.SubmitType = worksheet.Cells["F4"].Text.Trim();
                tpi.TroubleName = worksheet.Cells["F5"].Text.Trim();
                tpi.dieNo = worksheet.Cells["F6"].Text.Trim().ToUpper();
                tpi.partNo = worksheet.Cells["F7"].Text.Trim().ToUpper();
                tpi.cavNG = worksheet.Cells["F8"].Text.Trim();
                tpi.TotalCav = worksheet.Cells["F9"].Text.Trim();
                var MCsize = worksheet.Cells["F10"].Text.Trim();
                tpi.ecn_eriNo = worksheet.Cells["P4"].Text.Trim();
                var happenDate = worksheet.Cells["P5"].Text.Trim();
                var shot = worksheet.Cells["P6"].Text.Trim();
                var prodStatus = worksheet.Cells["P7"].Text.Trim();
                tpi.phase = worksheet.Cells["P8"].Text.Trim();
                tpi.proccesNG = worksheet.Cells["P9"].Text.Trim();
                tpi.dieMaterial = worksheet.Cells["P10"].Text.Trim();
                tpi.supplierCode = worksheet.Cells["W3"].Text.Trim();
                tpi.TPINo = worksheet.Cells["L3"].Text.Trim();
                var dueDate = worksheet.Cells["X10"].Text.Trim();




                string sqlCheckDie = $"SELECT dies.*,s.supplier_name, s.supplier_code FROM dies INNER JOIN suppliers s ON s.supplier_id = dies.supplier_id  WHERE dieno ='{tpi.dieNo}' ";
                var existDie = db.ExcuteQueryAndGetData(sqlCheckDie).data;

                if (existDie.Count == 0)
                {
                    tpi.die_id = 14389991; // Die fake Offical DB
                    //trouble.DieID = 14389940; // Die fake local DB for testing
                    //trouble.Die1 = db.Die1.Find(14389940);
                    tpi.DieBelong = "LBP";
                }
                else
                {
                    tpi.die_id = int.Parse(existDie[0]["die_id"].ToString());
                    tpi.DieBelong = existDie[0]["belong"].ToString();
                }
                // Truon hop Revise/Feedback TPI
                if (new[] { "Revise/Feedback"}.Contains(tpi.SubmitType) && !String.IsNullOrWhiteSpace(tpi.TPINo))
                {
                    // Check Old TPI đúng dieNo ko?
                    string sqlSearchTPI = $"select d.dieno, tpi.tpi_id from tpi inner join dies d ON d.die_id = tpi.die_id where tpi_no = '{tpi.TPINo}'";
                    var oldTPI = db.ExcuteQueryAndGetData(sqlSearchTPI).data;
                    if (oldTPI.Count > 0)
                    {
                        tpi.tpi_id = int.Parse(oldTPI[0]["tpi_id"].ToString());
                    }

                }
                try
                {
                    tpi.happenDate = DateTime.Parse(happenDate);
                }
                catch
                {
                    tpi.happenDate = today;
                }

                try
                {
                    tpi.shot = double.Parse(shot);
                }
                catch
                {
                    tpi.shot = 0;
                }


                tpi.DieTroubleRunningStatusID = prodStatus.Contains("Stop") ? 1 : prodStatus.Contains("Rework") ? 2 : prodStatus.Contains("Sorting") ? 3 : prodStatus.Contains("Temporary") ? 4 : prodStatus.Contains("other die") ? 5 : 6;
              

                string sqlCheckSupplierCode = $"Select * from suppliers where supplier_code ilike '{tpi.supplierCode.Trim()}'";
                var supplier = db.ExcuteQueryAndGetData(sqlCheckSupplierCode).data;
                if (supplier.Count > 0)
                {
                    tpi.supplierName = supplier[0]["supplier_name"].ToString();
                    tpi.supplierCode = supplier[0]["supplier_code"].ToString();
                }
                else
                {
                    tpi.supplierName = existDie[0]["supplier_name"].ToString();
                    tpi.supplierCode = existDie[0]["supplier_code"].ToString();
                }

                try
                {
                    tpi.dueDate = DateTime.Parse(dueDate);
                }
                catch
                {
                    tpi.dueDate = null;
                }
                try
                {
                    if (tpi.TroubleLevelID == null && tpi.dueDate != null)
                    {
                        tpi.TroubleLevelID = commonfunction.genarateTPILevelID(tpi.dueDate.ToString());
                    }
                    else
                    {
                        tpi.TroubleLevelID = 1;
                    }
                }
                catch
                {
                    tpi.TroubleLevelID = 1;
                }



            }

            return tpi;
        }


       

        public bool UpdateTPIForm(string tpiNo,string dieNo, string PathFuleFile, string progress,  bool isReject, bool isRevise, string dept, string division, string user_name, string comment, string tempoAction, string poCode, string renewDecision)
        {
            bool status = false;
            var today = DateTime.Now;
            //1. Updat Thong Tin Vào form TPI
            using (ExcelPackage package = new ExcelPackage(new FileInfo(currentURLHost + PathFuleFile)))
            {
                ExcelWorksheet worksheet = package.Workbook.Worksheets.First();
                var partNo = worksheet.Cells["F7"].Text.Trim().ToUpper();
                worksheet.Cells["L3"].Value = tpiNo;

                worksheet.Cells["W6"].Value = db.getDieBySearchPartNo(dieNo.Substring(0, 8)).data.Count;
                string model = "";
                try
                {
                   model = db.ExcuteQueryAndGetData($"SELECT m.model_name FROM dies d INNER JOIN models m ON m.model_id = d.model_id WHERE dieno = '{dieNo}'").data[0]["model_name"].ToString();
                }
                catch
                {
                    model = "";
                }
                worksheet.Cells["W7"].Value = model;
                worksheet.Cells["I14"].Value = "";

                if (isReject) // Reject
                {
                    worksheet.Cells["M13"].Value = "[" + today.ToString("yyyy/MM/dd ") + user_name + "]Rejected: " + comment + System.Environment.NewLine + worksheet.Cells["M13"].Text;
                    worksheet.Cells["I14"].Value = "REJECTED";
                    goto save;
                }
                if (isRevise) // Revise
                {
                    // DIV1: Inhouse
                    if (new[] { "ENG", "DIV1", "CRG" }.Contains(division))
                    {
                        worksheet.Cells["M13"].Value = "[" + today.ToString("yyyy/MM/dd ") + user_name + "]Revised: " + comment + System.Environment.NewLine + worksheet.Cells["M13"].Text;
                        if (dept.Contains("PAE"))
                        {
                            worksheet.Cells["N60"].Value = user_name + System.Environment.NewLine + "[Revised]";
                            worksheet.Cells["N62"].Value = today.ToString("yyyy-MM-dd");

                        }
                        else
                        {
                            if (dept.Contains("PE1"))
                            {
                                worksheet.Cells["T60"].Value = user_name + System.Environment.NewLine + "[Revised]";
                                worksheet.Cells["T62"].Value = today.ToString("yyyy-MM-dd");

                            } else
                            {
                                worksheet.Cells["F61"].Value = user_name + System.Environment.NewLine + "[Revised]";
                                worksheet.Cells["F62"].Value = today.ToString("yyyy-MM-dd");
                            }
                        }
                    }
                    else
                    {
                        worksheet.Cells["M16"].Value = "[" + today.ToString("yyyy/MM/dd ") + user_name + "]" + "Revised: " + comment + System.Environment.NewLine + worksheet.Cells["M16"].Text;

                    }
                    worksheet.Cells["I14"].Value = "REVISE";

                }
                if (progress.Contains("Submit"))
                {
                    worksheet.Cells["U11"].Value = "";
                    worksheet.Cells["B61"].Value = user_name;
                    worksheet.Cells["B62"].Value = today.ToString("yyyy-MM-dd");
                }
                if (progress.Contains("PAECheck"))
                {
                    worksheet.Cells["N60"].Value = user_name;
                    worksheet.Cells["N62"].Value = today.ToString("yyyy-MM-dd");

                }
                if (progress.Contains("PAEApp"))
                {
                    worksheet.Cells["Q60"].Value = user_name;
                    worksheet.Cells["Q62"].Value = today.ToString("yyyy-MM-dd");

                    if (!String.IsNullOrWhiteSpace(comment))
                    {
                        worksheet.Cells["M16"].Value = "[" + today.ToString("yyyy/MM/dd ") + user_name + "]PAE: " + comment + System.Environment.NewLine + worksheet.Cells["M16"].Text;
                    }
                }
                if (progress.Contains("PE1Check"))
                {
                    worksheet.Cells["T60"].Value = user_name;
                    worksheet.Cells["T62"].Value = today.ToString("yyyy-MM-dd");

                }
                if (progress.Contains("PE1App"))
                {

                    worksheet.Cells["W60"].Value = user_name;
                    worksheet.Cells["W62"].Value = today.ToString("yyyy-MM-dd");
                    if (!String.IsNullOrWhiteSpace(comment))
                    {
                        worksheet.Cells["M16"].Value = "[" + today.ToString("yyyy/MM/dd ") + user_name + "]PE1: " + comment + System.Environment.NewLine + worksheet.Cells["M16"].Text;
                    }
                }
                if (progress.Contains("DMTCheck") || progress.Contains("CRGCheck"))
                {
                    worksheet.Cells["F61"].Value = user_name;
                    worksheet.Cells["F62"].Value = today.ToString("yyyy-MM-dd");

                }
                if (progress.Contains("DMTApp") || progress.Contains("CRGApp"))
                {
                    worksheet.Cells["J61"].Value = user_name;
                    worksheet.Cells["J62"].Value = today.ToString("yyyy-MM-dd");

                    if (!String.IsNullOrWhiteSpace(comment) && progress.Contains("DMTApp"))
                    {
                        worksheet.Cells["M13"].Value = "[" + today.ToString("yyyy/MM/dd ") + user_name + "]DMT: " + comment + System.Environment.NewLine + worksheet.Cells["M13"].Text;
                    }
                    if (!String.IsNullOrWhiteSpace(comment) && progress.Contains("CRGApp"))
                    {
                        worksheet.Cells["M16"].Value = "[" + today.ToString("yyyy/MM/dd") + user_name + "]CRG: " + comment + System.Environment.NewLine + worksheet.Cells["M16"].Text;
                    }
                }
                if (progress.Contains("PURCheck"))
                {

                    if (!String.IsNullOrWhiteSpace(tempoAction))
                    {
                        worksheet.Cells["M16"].Value = "[" + today.ToString("yyyy/MM/dd ") + user_name + "]PUR: " + tempoAction + System.Environment.NewLine + worksheet.Cells["M16"].Text;
                    }
                    goto save;
                }
                worksheet.Cells["U11"].Value = poCode;
                worksheet.Cells["J17"].Value = renewDecision;

                save:
                package.Save();
                status = true;
            }

            return status;

        }

        public verifyForm verifyFormCoverPageDSUM(IFormFile coverpage, string partNo, string latestVersionControl, bool isNew)
        {
            DateTime applyDate = new DateTime(2023, 12, 13);
            bool isPass = false;
            string msg = "";
            var today = DateTime.Now;
            if (today < applyDate)
            {
                isPass = true;
                msg = "";
                goto Exit;

            }

            if (coverpage == null)
            {
                isPass = false;
                msg = "No file Upload";
                goto Exit;
            }

            var fileExtCoverpage = Path.GetExtension(coverpage.FileName);
            if (!fileExtCoverpage.ToLower().Contains(".xls")) // file excel
            {
                isPass = false;
                msg = "File must be excel (.xls*)";
                goto Exit;
            }

            string MOversion = "LPE-0012- Att 01-Rev.08\nEffective date: Dec/01/2023";
            string PXversion = "LPE-0012- Att 01-Rev.09\nEffective date: Dec/01/2023";
            string A45 = "Auto by Sys";

            using (ExcelPackage package = new ExcelPackage(coverpage.OpenReadStream()))
            {

                ExcelWorksheet worksheet = package.Workbook.Worksheets.First();

                //1. Kiem tra form dung ko?
                string field = worksheet.Cells["A1"].Text?.Trim().ToUpper();

                bool isMofield = field.Contains("MO");
                string formVersion = worksheet.Cells["AB1"].Text.Trim();
                string a45 = worksheet.Cells["A45"].Text.Trim();
                string formPartNo = worksheet.Cells["F16"].Text.Trim().ToUpper();
                string latestDFMVersion = worksheet.Cells["A4"].Text.Trim();
                // Check version
                if (isMofield)
                {
                    if (formVersion != MOversion)
                    {
                        isPass = false;
                        msg = "Not correct version! form you upload is " + formVersion + " but sys request version " + MOversion;
                        goto Exit;
                    }
                }
                else
                {
                    if (formVersion != PXversion)
                    {
                        isPass = false;
                        msg = "Not correct version! form you upload is " + formVersion + " but sys request version " + PXversion;
                        goto Exit;
                    }
                }

                // Check dong A45 
                if (A45 != a45)
                {
                    isPass = false;
                    msg = "Not correct format! Maybe you add/delete row, Please compare with version " + (isMofield ? MOversion : PXversion);
                    goto Exit;
                }

                //2. Kiem tra part No trung ko?
                if (!partNo.Contains(formPartNo))
                {
                    isPass = false;
                    msg = "Maybe you upload wrong Part No. In coverpage PartNo is " + formPartNo + " Part No on DMS is " + partNo;
                    goto Exit;
                }


                //3. Kiem tra lastest version ko?
                if (latestDFMVersion != latestVersionControl && isNew == false)
                {
                    isPass = false;
                    msg = "DFM you upload is not newest version, newest was uploaded " + latestVersionControl;
                    goto Exit;
                }

                isPass = true;
                msg = "OK";

            }



        Exit:
            var output = new verifyForm()
            {
                isPass = isPass,
                msg = msg
            };
            return output;

        }








        //*********END**************
    }
}