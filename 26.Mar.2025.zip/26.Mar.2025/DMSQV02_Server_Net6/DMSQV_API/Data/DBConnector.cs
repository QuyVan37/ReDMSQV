﻿using DMSQV_API.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Razor.TagHelpers;
using Npgsql;
using System;
using System.Data.Common;
using System.Text;

namespace DMSQV_API.Data
{
    public class DBConnector
    {
        //START*** Cấu hình kết nối đến Postgress **//
        string connectionString = "Host=localhost;Username=postgres;Password=sa;Database=DMS";

        // forlocal test
       // string connectionString = "Host=cqv-veng;Username=postgres;Password=123456a@;Database=DMS";
        //for pulblic
        //string connectionString = "Host=localhost;Username=postgres;Password=123456a@;Database=DMS";
        public class dataReturn
        {
            public int rowEffected { get; set; }
            public int totalCount { get; set; }
            public List<Dictionary<string, object>> data { get; set; }

        }

        public class dataReturnStatus
        {
            public int statusID { get; set; }
            public string? status { get; set; }
            public string? dept_res { get; set; }
            public int? mr_role_id_res { get; set; }
            public string? MRNo { get; set; }
            public string? belong { get; set; }
        }

        public dataReturn ExcuteQueryAndGetData(string sql)
        {
            int rowEffected = 0;
            List<Dictionary<string, object>> data = new List<Dictionary<string, object>>();
            using (var connection = GetConnection())
            {
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = sql;
                    using (var reader = command.ExecuteReader())
                    {
                        rowEffected = reader.RecordsAffected;
                        while (reader.Read())
                        {
                            var row = new Dictionary<string, object>();
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                try
                                {
                                    row.Add(reader.GetName(i), reader.GetValue(i) == DBNull.Value ? "" : reader.GetValue(i));
                                }
                                catch
                                {
                                    row.Add(reader.GetName(i) + i, reader.GetValue(i) == DBNull.Value ? "" : reader.GetValue(i));
                                }
                                
                            }
                            data.Add(row);
                        }
                    }
                    connection.Close();
                }
            }
            var output = new dataReturn
            {
                rowEffected = rowEffected,
                data = data
            };
            return output;
        }

        public dataReturn ExcuteFunctionAndGetListData(string sql)
        {
            int rowEffected = 0;
            int totalCount = 0;
            List<Dictionary<string, object>> data = new List<Dictionary<string, object>>();
            using (var connection = GetConnection())
            {
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = sql;

                    using (var reader = command.ExecuteReader())
                    {
                        rowEffected = reader.RecordsAffected;
                        while (reader.Read())
                        {
                            var row = new Dictionary<string, object>();
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                row.Add(reader.GetName(i), reader.GetValue(i) == DBNull.Value ? "" : reader.GetValue(i));
                                var a = reader.GetName(i);
                                if (reader.GetName(i) == "total_count")
                                {
                                    totalCount = reader.GetInt32(i);
                                }
                            }
                            data.Add(row);
                        }
                    }
                    connection.Close();
                }
            }
            var output = new dataReturn
            {
                rowEffected = rowEffected,
                data = data,
                totalCount = totalCount
            };
            return output;

        }


        private DbConnection GetConnection()
        {

            var connection = new NpgsqlConnection(connectionString);
            connection.Open();
            return connection;
        }

        //END*** Cấu hình kết nối đến Postgress **//


        // Start các chuỗi kết nối đến databse

        public dataReturn ExistUser(string code, string password)
        {
            var today = DateTime.Now;
            string sql = $"update users set last_online = '{today}' where user_code = '{code}' and password = '{password}'; " +
                $"SELECT CASE WHEN EXISTS ( SELECT 1  FROM users u WHERE user_code = '{code}' and password = '{password}')" +
                $"THEN (SELECT u.user_id FROM users u WHERE user_code = '{code}' and password = '{password}') ELSE 0 END AS result;";

            var resutl = ExcuteQueryAndGetData(sql);
            // nếu ko tồn tại thì return 0, nếu tồn tại user thì return user_id
            return resutl;
        }

        public List<user> getUserProfile(int user_id)
        {
            string sql = $"SELECT u.user_id, user_name, user_code, buyer_code, grade_id, email,  is_admin, is_verified,is_active, is_delete, lock_reason, last_online, create_date  ,d.dept_id, dept_name, division, factory ,c.tpi_role_id, c.mr_role_id, c.po_role_id, c.die_role_id, c.dtf_role_id, c.dsum_role_id, c.dispose_role_id,c.dcf_role_id from userrole c " +
                $"inner join users u on c.user_id = u.user_id  " +
                $"inner join  department d on c.dept_id = d.dept_id " +
                $"where c.user_id = {user_id}";

            List<user> dataUsers = new List<user>();
            using (var connection = GetConnection())
            {
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = sql;
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var user = new user
                            {
                                user_id = reader.GetInt32(0),
                                user_name = reader.GetString(1),
                                user_code = reader.GetString(2),
                                buyer_code = reader.GetString(3),
                                grade_id = reader.GetInt32(4),
                                email = reader.GetString(5),
                                is_admin = reader.GetBoolean(6),
                                is_verified = reader.GetBoolean(7),
                                is_active = reader.GetBoolean(8),
                                is_delete = reader.GetBoolean(9),
                                //lock_reason = reader.IsDBNull(10) ? null : reader.GetString(10),
                                lock_reason = reader.GetString(10),
                                last_online = reader.GetDateTime(11),
                                create_date = reader.GetDateTime(12),
                                dept_id = reader.GetInt32(13),
                                dept_name = reader.GetString(14),
                                division = reader.GetString(15),
                                factory = reader.GetString(16),
                                tpi_role_id = reader.GetInt32(17),
                                mr_role_id = reader.GetInt32(18),
                                po_role_id = reader.GetInt32(19),
                                die_role_id = reader.GetInt32(20),
                                dtf_role_id = reader.GetInt32(21),
                                dsum_role_id = reader.GetInt32(22),
                                dispose_role_id = reader.GetInt32(23),
                                dcf_role_id = reader.GetInt32(24),
                            };
                            dataUsers.Add(user);
                        }
                    }
                    connection.Close();
                }
            }


            return dataUsers;
        }

        public dataReturn getDMSGradeCatergory()
        {
            string sql = $"SELECT * FROM gradecategory";
            var result = ExcuteQueryAndGetData(sql);
            return result;
        }

        public dataReturn getDMSRoleCatergory()
        {
            string sql = $"SELECT * FROM rolecategory";
            var result = ExcuteQueryAndGetData(sql);
            return result;
        }

        public dataReturn getListDept()
        {
            string sql = $"SELECT * FROM department";
            var result = ExcuteQueryAndGetData(sql);
            return result;
        }
        public dataReturn getListUser(string? user_name, string? user_code, string? dept_id, int? page = 1, int? pageSize = 10)
        {

            string sql = $"SELECT * from get_list_user_after_search('{user_name}','{user_code}','{dept_id}',{page},{pageSize})";

            var result = ExcuteFunctionAndGetListData(sql);
            return result;
        }
        public dataReturn getMRTypeCategory()
        {
            string sql = $"SELECT * FROM mr_type_category";
            var result = ExcuteQueryAndGetData(sql);
            return result;
        }

        public dataReturn getSupplierList()
        {
            string sql = $"SELECT * FROM suppliers";
            var result = ExcuteQueryAndGetData(sql);
            return result;
        }
        public dataReturn getModelList()
        {
            string sql = $"SELECT * FROM models";
            var result = ExcuteQueryAndGetData(sql);
            return result;
        }

       
        public dataReturn getBudgetCodeList()
        {
            string sql = $"SELECT * FROM die_budget_code";
            var result = ExcuteQueryAndGetData(sql);
            return result;
        }

        public dataReturn getTPIRelatedDieNo(string dieNo)
        {
            string sql = $"SELECT tpi_id, tpi_no, trouble_name, c.type as po_code, s.status_type as status , tpi.report, tpi.submit_date  from tpi  " +
                         $"JOIN tpi_po_code c on c.tpi_po_code_id = tpi.tpi_po_code_id " +
                         $"JOIN tpi_status_category s ON s.tpi_status_id = tpi.tpi_status_id  " +
                         $"WHERE die_no = '{dieNo}' and tpi.active in (null, true) and tpi.tpi_status_id in (1,2,4,5,6)";
            var result = ExcuteQueryAndGetData(sql);
            return result;
        }

        public dataReturn getDFMRelatedDieNo(string dieNo)
        {
            string sql = $"SELECT DSUM.dfm_id, DSUM.dsum_no, s.status,DSUM.submit_date  from DSUM  " +
                $"JOIN dsum_status_category s ON s.dsum_status_id = DSUM.dsum_status_id  " +
                $"JOIN dies ON dies.die_id = DSUM.die_id  " +
                $"WHERE dies.dieno = '{dieNo}' and s.dsum_status_id IN (9)";
            var result = ExcuteQueryAndGetData(sql);
            return result;
        }
        public dataReturn getListProcessCode()
        {
            string sql = $"SELECT * FROM die_process_code_category";
            var result = ExcuteQueryAndGetData(sql);
            return result;
        }

       
        public dataReturn resetPW(string code, string encodePW)
        {
            string sql = $"UPDATE users set password = '{encodePW}' WHERE user_code = '{code}'";
            var result = ExcuteQueryAndGetData(sql);
            return result;
        }

        public bool isExistEmployeeCode(string user_code)
        {
            /// <summary>
            /// Signs in a principal using the default authentication scheme.
            /// The default authentication scheme is determined by the `isExistEmployeeCode` property,
            /// which indicates whether to check for an existing employee code.
            /// 
            /// Returns `true` if a user with the specified `user_code` already exists in the system,
            /// otherwise returns `false`.
            /// </summary>
            /// <param name="user_code">The user code to authenticate.</param>
            /// <returns>True if the user exists, false otherwise.</returns>
            bool status = false;
            string sql = $"SELECT user_id FROM users u WHERE user_code ILIKE '%{user_code}%'";
            var result = ExcuteQueryAndGetData(sql);

            if (result.data.Count() > 0)
            {
                status = true;
            }
            return status;
        }

        public dataReturn CreateNewDMSAccount(string user_code, string user_name, string password, string buyer_code, int grade_id, string email, string[] dept_ids)
        {
            int user_id = 0;
            var result = new dataReturn();
            var encodePW = encodePassword.EncodePasswordMd5(password);
            // 1. insert vao bang user va lay duoc user_id
            string sqlInsertUser = $"INSERT INTO public.users(user_name, user_code, password, buyer_code, grade_id, email, is_admin, is_verified, is_active, is_delete, lock_reason, last_online, create_date)" +
                $"VALUES ('{user_name}', '{user_code}', '{encodePW}', '{buyer_code}', {grade_id}, '{email}', {false}, {false}, {false}, {false}, '{"Waiting Admin verify you register!"}','{DateTime.Now}' ,'{DateTime.Now} ');";
            var resultInsertUser = ExcuteQueryAndGetData(sqlInsertUser);
            if (resultInsertUser.rowEffected > 0)
            {
                string sql_getnewUser_id = $"SELECT u.user_id FROM users u WHERE user_code = '{user_code}'";
                var user_id_raw = ExcuteQueryAndGetData(sql_getnewUser_id);
                user_id = (int)user_id_raw.data[0].Values.ToList()[0];
                foreach (var dept_id_str in dept_ids)
                {
                    int dept_id_int = int.Parse(dept_id_str);
                    //2. insert vao bang userrole 
                    string sqlInsertRole = $"INSERT INTO public.userrole( user_id, dept_id, tpi_role_id, mr_role_id, po_role_id, die_role_id, dtf_role_id, dsum_role_id, dispose_role_id, dcf_role_id)" +
                                            $"VALUES ({user_id},{dept_id_int},{1},{1},{1},{1},{1},{1},{1},{1});";
                    result = ExcuteQueryAndGetData(sqlInsertRole);
                }
            }
            return result;
        }


        public dataReturn getMRList(string search, string? supplier_id, string? mr_type_id, int? page = 1, int? pageSize = 10)
        {
            //**** go to store procudure
            string sql = $"SELECT * from get_list_mr_after_search('{search}','{supplier_id}','{mr_type_id}',{page},{pageSize})";

            var result = ExcuteFunctionAndGetListData(sql);
            return result;
        }

        public dataReturn getSumarizeMRPending()
        {
            //**** go to store procudure
            string sql = $"SELECT * from sumarize_mr_pending()";
            var result = ExcuteFunctionAndGetListData(sql);

            return result;
        }

        public dataReturn getMRByID(int mr_id)
        {
            string sql = $"SELECT * FROM mr WHERE mr_id = {mr_id}";
            var output = ExcuteQueryAndGetData(sql);
            return output;
        }
        public dataReturn getMRStatusResponByID(int mRstatusID)
        {
            string sql = $"SELECT * FROM mr_status_category WHERE mr_status_id = {mRstatusID}";
            var output = ExcuteQueryAndGetData(sql);
            return output;
        }

        public dataReturnStatus getCurrentMRStatus(int mr_id)
        {
            string sql = $"select mr.status_id, sct.type as status, sct.dept_res,sct.mr_role_id_res, mr.mr_no, mr.belong from mr " +
                $"join public.mr_status_category sct on mr.status_id = sct.mr_status_id " +
                $"where mr_id = {mr_id}";

            dataReturnStatus output = new dataReturnStatus();
            using (var connection = GetConnection())
            {
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = sql;
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            output = new dataReturnStatus
                            {
                                statusID = reader.GetInt32(0),
                                status = reader.GetString(1),
                                dept_res = reader.GetValue(2) == DBNull.Value ? "" : reader.GetString(2),
                                mr_role_id_res = reader.GetValue(3) == DBNull.Value ? 999 : reader.GetInt32(3),
                                MRNo = reader.GetValue(4) == DBNull.Value ? "" : reader.GetString(4),
                                belong = reader.GetValue(5) == DBNull.Value ? "" : reader.GetString(5),
                            };

                        }
                    }
                    connection.Close();
                }
            }
            return output;
        }

        public dataReturn isExistMR(string part_no, string dim, string his)
        {
            string sql = $"SELECT mr_no, request_by, request_date FROM mr " +
                        $"WHERE part_no = '{part_no}' and is_active in (null, true) and status_id NOT IN (11,12)  " +
                        $"AND ((clasification NOT ILIKE '_5A' AND clasification = '{dim}') OR  (clasification ILIKE '_5A' and clasification = '{dim}' AND draw_his = '{his}'))";
            var output = ExcuteQueryAndGetData(sql);
            return output;
        }

        public dataReturn isExistDie(string dieNo)
        {
            string sql = $"SELECT die_id FROM dies WHERE dieno= '{dieNo}' AND is_active IN (null, true) AND is_cancel IN (null,false) AND is_official IN (null, true) AND die_status_id <> 10";
            var output = ExcuteQueryAndGetData(sql);
            return output;
        }
        public dataReturn getDieStatusCategory()
        {
            string sql = $"SELECT * FROM die_status_category";
            var output = ExcuteQueryAndGetData(sql);
            return output;
        }

        public dataReturn getDieCheckResultCategory()
        {
            string sql = $"SELECT * FROM die_check_result_category";
            var output = ExcuteQueryAndGetData(sql);
            return output;
        }

        public dataReturn getTPITypeCategory()
        {
            string sql = $"SELECT * FROM tpi_trouble_type_category ORDER by order_view";
            var output = ExcuteQueryAndGetData(sql);
            return output;
        }

        public dataReturn getTPITroubleAreasCategory()
        {
            string sql = $"SELECT * FROM tpi_trouble_areas_category ORDER by order_view";
            var output = ExcuteQueryAndGetData(sql);
            return output;
        }

        public dataReturn getTPIRootCauseCategory()
        {
            string sql = $"SELECT * FROM tpi_root_cause_category ORDER by order_view";
            var output = ExcuteQueryAndGetData(sql);
            return output;
        }

        public dataReturn getTPIPOCodeCategory()
        {
            string sql = $"SELECT * FROM tpi_po_code";
            var output = ExcuteQueryAndGetData(sql);
            return output;
        }
        public dataReturn getTPICMCategory()
        {
            string sql = $"SELECT * FROM tpi_cm_catergory ORDER by order_view";
            var output = ExcuteQueryAndGetData(sql);
            return output;
        }

        public dataReturn getRenewDecisionCategory()
        {
            string sql = $"SELECT * FROM tpi_renew_decision_catergory ";
            var output = ExcuteQueryAndGetData(sql);
            return output;
        }

















        // FOR DIE CONTROLLER
        public dataReturn getDieList(string search, string? supplier_id, string? model_id,string die_classify, string progress, int? page = 1, int? pageSize = 10)
        {
            //**** go to store procudure
            string sql = $"SELECT * from get_list_die_after_search   ('{search}','{supplier_id}','{model_id}','{die_classify}','{progress}',{page},{pageSize})";

            var result = ExcuteFunctionAndGetListData(sql);
            return result;
        }

        public dataReturn getDieBySearchPartNo(string search)
        {
            string sql = $"SELECT d.die_id, dieno, s.type as status, d.progress, d.short FROM common_die c  " +
                         $"JOIN parts p ON p.part_id = c.part_id  " +
                         $"JOIN dies d ON d.die_id = c.die_id  " +
                         $"JOIN die_status_category s ON s.die_status_id = d.die_status_id    " +
                         $"Where p.part_no ILIKE '%{search}%' AND (d.is_active IS NULL  OR d.is_active = true)";
            var result = ExcuteQueryAndGetData(sql);
            return result;
        }

        // FOR TPI CONTROLLER

        public dataReturn getTPIList(string search, string? tpi_id, string? supplier_id, string? model_id, string phase, string tpi_status, int? page = 1, int? pageSize = 10)
        {
            //**** go to store procudure
            string sql = $"SELECT * from get_list_tpi_after_search   ('{search}','{tpi_id}','{supplier_id}','{model_id}', '{phase}', '{tpi_status}',{page},{pageSize})";
            var result = ExcuteFunctionAndGetListData(sql);
            return result;
        }

        public dataReturn getSumarizeTPIPending()
        {
            //**** go to store procudure
            string sql = $"SELECT * from sumarize_tpi_pending()";
            var result = ExcuteFunctionAndGetListData(sql);

            return result;
        }






        // FOR PO 

        public dataReturn getPOList(string search, string? supplier_id, string? mr_type_id, string dept, string po_role_id, int? page = 1, int? pageSize = 10)
        {
            //**** go to store procudure
            string sql = $"SELECT * from get_list_po_after_search('{search}','{supplier_id}','{mr_type_id}','{dept}','{po_role_id}',{page},{pageSize})";

            var result = ExcuteFunctionAndGetListData(sql);
            return result;
        }

        public dataReturn getPOByID(int po_id)
        {
            string sql = $"SELECT po.*,s.status, mr.mr_no,mr.order_to,mr.die_no, mr.part_no,mr.part_name, mr.estimate_cost, mr.unit, mr.clasification, draw_his, ecn_no, cav_qty,spl.supplier_code, spl.supplier_name ,m.model_name  FROM po_dies po  " +
                         $"INNER JOIN mr ON mr.mr_id = po.mr_id  " +
                         $"INNER JOIN po_status_category s ON s.po_status_id = po.po_status_id " +
                         $"INNER JOIN suppliers spl ON spl.supplier_id = mr.supplier_id  " +
                         $"INNER JOIN models m ON m.model_id = mr.model_id" +
                        $" WHERE po_id = {po_id}";
            var output = ExcuteQueryAndGetData(sql);
            return output;
        }

        public dataReturn getSumarizePOPending()
        {
            //**** go to store procudure
            string sql = $"SELECT * from sumarize_po_pending()";
            var result = ExcuteFunctionAndGetListData(sql);

            return result;
        }



        //FRO DIE TRANSFER
        public dataReturn getSumarizeDTFPending()
        {
            //**** go to store procudure
            string sql = $"SELECT * from sumarize_dtf_pending()";
            var result = ExcuteFunctionAndGetListData(sql);

            return result;
        }

        public dataReturn getDTFList(string search, string? supplier_id, string? mr_type_id, int? page = 1, int? pageSize = 10)
        {
            //**** go to store procudure
            string sql = $"SELECT * from get_list_dtf_after_search('{search}','{supplier_id}','{mr_type_id}',{page},{pageSize})";

            var result = ExcuteFunctionAndGetListData(sql);
            return result;
        }

        public dataReturn getDTFByID(int dtf_id)
        {
            string sql = $"SELECT dtf.*,old_spl.supplier_code as current_location, new_spl.supplier_code as new_location, t.*, s.*  FROM dtf " +
                         $"INNER JOIN dtf_status_category s ON s.dtf_status_id = dtf.dtf_status_id  " +
                         $"INNER JOIN dtf_type_category t ON t.dtf_type_id = dtf.dtf_type_id  " +
                         $"INNER JOIN suppliers old_spl ON old_spl.supplier_id = dtf.current_location_id   " +
                         $"INNER JOIN suppliers new_spl ON new_spl.supplier_id = dtf.new_location_id  " +
                        $" WHERE dtf_id = {dtf_id}";
            var output = ExcuteQueryAndGetData(sql);
            return output;
        }

        public dataReturn getMASTERList(string search, string table, int? page = 1, int? pageSize = 10)
        {
            //**** go to store procudure
            string sql = $"SELECT * from search_any_column_in_table('{search}', '{table}')";

            var result = ExcuteFunctionAndGetListData(sql);
            return result;
        }


        // DSUM
        public dataReturn getSumarizeDSUMPending()
        {
            //**** go to store procudure
            string sql = $"SELECT * from sumarize_dsum_pending()";
            var result = ExcuteFunctionAndGetListData(sql);

            return result;
        }

        public dataReturn getDSUMList(string search, string? supplier_id, string? model_id, int? page = 1, int? pageSize = 10)
        {
            //**** go to store procudure
            string sql = $"SELECT * from get_list_dsum_after_search('{search}','{supplier_id}','{model_id}',{page},{pageSize})";

            var result = ExcuteFunctionAndGetListData(sql);
            return result;
        }






    }

}
