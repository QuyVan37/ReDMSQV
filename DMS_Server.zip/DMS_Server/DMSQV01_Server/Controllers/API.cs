﻿using DMSQV01_Server.Data;
using Microsoft.AspNetCore.Mvc;
using System.Text;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using System.Security.Claims;
using Microsoft.AspNetCore.SignalR;
using Microsoft.AspNetCore.Http;


namespace DMSQV01_Server.Controllers
{

    public class API : Controller
    {
        DB_Store_Procudure db = new DB_Store_Procudure();
        public JsonResult api_DMSGradeCategory()
        {
            var result = db.getDMSGradeCatergory();
            return Json(result);
        }

        public JsonResult api_DMSRoleCategory()
        {
            var result = db.getDMSRoleCatergory();
            return Json(result);
        }


    }
}
