﻿using DMSQV01_Server.Data;
using Microsoft.AspNetCore.Mvc;
using System.Text;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using System.Security.Claims;
using Microsoft.AspNetCore.SignalR;
using Microsoft.AspNetCore.Http;

namespace DMSQV01_Server.Controllers
{
    public class authorization : Controller
    {
        DB_Store_Procudure db = new DB_Store_Procudure();
        public IActionResult Index()
        {
            return View();
        }


        public async Task<JsonResult> api_login(string code, string password)
        {
            // Kiểm tra user có tồn tại hau ko?
            // nếu user ID > 0 là tồn tại và tạo cookie trả về client + thông tin users + status = true
            // nếu user = 0 ko tồn tại user, trả về client status = false và user = null
            bool status = false;
            var checkUser = (List<Dictionary<string, object>>)db.ExistUser(code, password);
            var user_id = (int)checkUser[0].Values.ToList()[0];
            
            if (user_id > 0) // có tồn tại user này rồi
            {
                // tạo cookie
                var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, user_id.ToString())
                };
                var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity));
                status = true;
                //HttpContext.Session.SetString("user_id", user_id.ToString());
                //var isCookiePresent = Request.Cookies.ToList();
            }
            var output = new
            {
                status = status,
                user = api_getUserProfile(user_id),
            };
            return Json(output);
        }



        public async Task<JsonResult> api_logout()
        {
            // clear cookie and session
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            HttpContext.Session.Clear();
            return Json(true);
        }


        public JsonResult api_isLoginAndReturnUserProfile()
        {
            bool isLogin = true;
            // Lấy user_id dùng từ claim cookie
           var user_id = HttpContext.User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value;

            // Lấy các thông tin khác nếu cần
            var userInfor = HttpContext.User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier)?.Value;

            if(user_id == null)
            {
                user_id = "0";
                isLogin = false;
            }

           
            var output = new
            {
                status = isLogin,
                user = api_getUserProfile(int.Parse(user_id)),
            };

            return Json(output);
        }


        public object api_getUserProfile(int user_id)
        {
            var user = db.getUserProfile(user_id);
            return user;
        }








    }
}
