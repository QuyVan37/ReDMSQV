﻿using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Mvc;
using Npgsql;
using System;
using System.Data.Common;
using System.Security.Cryptography.X509Certificates;
namespace DMSQV01_Server.Data
{

    public class DB_Store_Procudure
    {

        //START*** Cấu hình kết nối đến Postgress **//
        string connectionString = "Host=localhost;Username=postgres;Password=sa;Database=DMS";



        private List<Dictionary<string, object>> GetDataFromDatabase(string sql)
        {

            List<Dictionary<string, object>> data = new List<Dictionary<string, object>>();
            using (var connection = GetConnection())
            {
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = sql;
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var row = new Dictionary<string, object>();
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                row.Add(reader.GetName(i), reader.GetValue(i));
                            }
                            data.Add(row);
                        }
                    }
                    connection.Close();
                }
            }
            return data;
        }


        private DbConnection GetConnection()
        {

            var connection = new NpgsqlConnection(connectionString);
            connection.Open();
            return connection;
        }

        //END*** Cấu hình kết nối đến Postgress **//

        public List<Dictionary<string, object>> ExistUser(string code, string password)
        {
            string sql = $"SELECT CASE WHEN EXISTS ( SELECT 1  FROM users u WHERE user_code = '{code}' and password = '{password}')" +
                $"THEN (SELECT u.user_id FROM users u WHERE user_code = '{code}' and password = '{password}') ELSE 0 END AS result;";

            var resutl = GetDataFromDatabase(sql);
            // nếu ko tồn tại thì return 0, nếu tồn tại user thì return user_id
            return resutl;
        }

        public object getUserProfile(int user_id)
        {
            string sql = $"SELECT u.*,d.*,c.tpi_role_id, c.mr_role_id, c.po_role_id, c.die_role_id, c.dtf_role_id, c.dsum_role_id, c.dispose_role_id,c.dcf_role_id from userrole c " +
                $"inner join users u on c.user_id = u.user_id  " +
                $"inner join  department d on c.dept_id = d.dept_id " +
                $"where c.user_id = {user_id}";

            var resutl = GetDataFromDatabase(sql);
            return resutl;
        }

        public object getDMSGradeCatergory()
        {
            string sql = $"SELECT * FROM gradecategory";
                var result = GetDataFromDatabase(sql);
            return result;
        }

        public object getDMSRoleCatergory()
        {
            string sql = $"SELECT * FROM rolecategory";
            var result = GetDataFromDatabase(sql);
            return result;
        }

    }
}

