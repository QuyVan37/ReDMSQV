﻿using DMSQV_API.Data;
using Microsoft.AspNetCore.Mvc;

namespace DMSQV_API.Controllers
{
    public class CommonAPI : Controller
    {
        DBConnector db = new DBConnector();
        public JsonResult api_DMSGradeCategory()
        {
            var result = db.getDMSGradeCatergory();
            return Json(result);
        }

        public JsonResult api_DMSRoleCategory()
        {
            var result = db.getDMSRoleCatergory();
            return Json(result);
        }

        public JsonResult api_GetListDept()
        {
            var result = db.getListDept();
            return Json(result);
        }

        public JsonResult api_GetMRTypeCategory()
        {
            var result = db.getMRTypeCategory();
            return Json(result);
        }

        public JsonResult api_GetSupplierList()
        {
            var result = db.getSupplierList();
            return Json(result);
        }

        // add 28.Sept.2024
        public JsonResult api_GetModelList()
        {
            var result = db.getModelList();
            return Json(result);
        }

        public JsonResult api_GetListProcessCode()
        {
            var result = db.getListProcessCode();
            return Json(result);
        }
        public JsonResult api_GetDieStatusCategory()
        {
            var result = db.getDieStatusCategory();
            return Json(result);
        }

        public JsonResult api_GetDieCheckResultCategory()
        {
            var result = db.getDieCheckResultCategory();
            return Json(result);
        }






    }
}
