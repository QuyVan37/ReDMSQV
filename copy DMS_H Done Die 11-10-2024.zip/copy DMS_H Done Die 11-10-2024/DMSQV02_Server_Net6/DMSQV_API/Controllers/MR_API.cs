﻿using DMSQV_API.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using static DMSQV_API.Data.DBConnector;

namespace DMSQV_API.Controllers
{
    public class MR_API : Controller
    {
        DBConnector db = new DBConnector();
        Authen authen = new Authen();
        CommonFunction commonFunction = new CommonFunction();
        public int[] flowProgressLBP = { 2, 3, 4, 5, 6, 7, 8, 13, 14 };
        public int[] flowProgressCRG = { 16, 4, 5, 6, 7, 8, 13, 14 };
        public int[] flowProgressDMT = { 2, 3, 8, 13, 14 };
        public int[] flowProgressPE1 = { 15, 4, 5, 6, 7, 8, 13, 14 };
        public JsonResult api_getMRList(string search, string? supplier_id, string? mr_type_id, int? page = 1, int? pageSize = 50)
        {
            search = search?.Trim();
            bool status = false;
            string msg = "";
            var islogin = authen.isLoginAndReturnUserProfile(HttpContext);

            dataReturn data = new dataReturn();
            if (islogin.status)
            {
                data = db.getMRList(search, supplier_id, mr_type_id, page, pageSize);
                status = true;
            }
            else
            {
                msg = "Please login!";
                status = false;
            }


        exit:
            var output = new
            {
                status = status,
                msg = msg,
                recordsTotal = data.totalCount,
                recordsFiltered = data.totalCount,
                page = page,
                pageSize = pageSize,
                Data = data.data,
            };
            return Json(output);
        }

        public JsonResult api_getSumarizeMRPending()
        {
            var result = db.getSumarizeMRPending();
            return Json(result);
        }

        public JsonResult api_isExistMR(string part_no, string dim)
        {
            var result = new
            {
                status = true,
                msg = DateTime.Now + "MR was issue by NVQ on 11-11-2024, MRNo: 123456"
            };
            return Json(result);
        }

        public JsonResult api_issueMR(IFormCollection data)
        {
            var result = new
            {
                status = true,
                msg = DateTime.Now + "MR was issue by NVQ on 11-11-2024, MRNo: 123456"
            };
            return Json(result);
        }
        public JsonResult api_issueMRByExcel(IFormCollection file)
        {
            var result = new
            {
                status = true,
                msg = DateTime.Now + "MR was issue by NVQ on 11-11-2024, MRNo: 123456"
            };
            return Json(result);
        }

        public JsonResult api_checkAndApproveMR(string mRIDs, string check_comment, string check_is_de_die, string check_no_of_die_component, string check_die_maker, string check_make_location, string check_die_special)
        {
            string msg = "";
            bool status = false;
            List<int> success = new List<int>();
            List<string> fail = new List<string>();
            var userLogin = authen.isLoginAndReturnUserProfile(HttpContext);
            if (!userLogin.status)
            {
                status = false;
                msg = "Please login in!";
                goto exit;
            }

            bool isChecker = userLogin.dataUsers.Any(e => new[] { "PAE", "PE1", "CRG", "PLAN", "PUR" }.Contains(e.dept_name) && new[] { "QV" }.Contains(e.factory) && new[] { 3 }.Contains(e.mr_role_id));
            bool isApprover = userLogin.dataUsers.Any(e => new[] { "PAE", "PE1", "CRG", "PLAN", "PUR" }.Contains(e.dept_name) && new[] { "QV" }.Contains(e.factory) && new[] { 4 }.Contains(e.mr_role_id));
            if (isChecker || isApprover)
            {
                string[] arrayMRIDs = mRIDs.Split(',');
                foreach (var id in arrayMRIDs)
                {
                    var currentStatusRespose = db.getCurrentMRStatus(int.Parse(id));
                    bool isPAETurn = userLogin.dataUsers.Any(e => new[] { "PAE" }.Contains(e.dept_name) && currentStatusRespose.dept_res.Contains(e.dept_name) && currentStatusRespose.mr_role_id_res.Equals(e.mr_role_id));
                    bool isOtherDeptTurn = userLogin.dataUsers.Any(e => new[] { "PE", "CRG", "PLAN", "PUR" }.Contains(e.dept_name) && currentStatusRespose.dept_res.Contains(e.dept_name) && currentStatusRespose.mr_role_id_res.Equals(e.mr_role_id));
                    check_comment = String.IsNullOrWhiteSpace(check_comment) ? "" : DateTime.Now.ToString("yyyy/MM/dd ") + userLogin.dataUsers[0].user_name + ": " + check_comment;
                    
                    if (isPAETurn)
                    {
                        int nextStatusID = 0;
                        if (currentStatusRespose.belong.Contains("DMT"))
                        {
                             nextStatusID = flowProgressDMT[Array.IndexOf(flowProgressDMT, currentStatusRespose.statusID) + 1];
                        } else
                        {
                            nextStatusID = flowProgressLBP[Array.IndexOf(flowProgressLBP, currentStatusRespose.statusID) + 1];
                        }
                     
                        var arrayParameter = new[] { check_is_de_die, check_no_of_die_component, check_die_maker, check_make_location };
                        bool isPass = commonFunction.checkArrayHasAnyElementNullOrEmpty(arrayParameter);
                        if (!isPass)
                        {
                            string subSQL = "";
                            if (isChecker)
                            {
                                subSQL = $"pae_check_by='{userLogin.dataUsers[0].user_name}'," +
                                              $"pae_check_date = '{DateTime.Now}',";
                            }
                            if (isApprover)
                            {
                                subSQL = $"pae_app_by='{userLogin.dataUsers[0].user_name}'," +
                                              $"pae_app_date = '{DateTime.Now}',";
                            }
                            string sql = $"UPDATE mr " +
                                              $"SET  " +
                                              $"status_id= {nextStatusID}," +
                                              $"is_de_die = '{check_is_de_die}'," +
                                              $"no_of_die_component = '{int.Parse(check_no_of_die_component)}'," +
                                              $"die_maker = '{check_die_maker}'," +
                                              $"make_location= '{check_make_location}'," +
                                              $"die_special = '{check_die_special}'," +
                                                 subSQL +
                                              $"note = 'mr.note || {check_comment}' " +
                                              $"WHERE mr_id = {int.Parse(id)}";

                            db.ExcuteQueryAndGetData(sql);
                            status = true;
                            success.Add(int.Parse(id));
                        }
                        else
                        {
                            status = false;
                            msg = "Please input enough information!";
                            goto exit;
                        }
                    }
                    if (isOtherDeptTurn)
                    {
                        int nextStatusID = 0;
                        string subSQL = "";
                        bool isPETurn = userLogin.dataUsers.Any(e => new[] { "PE" }.Contains(e.dept_name) && currentStatusRespose.dept_res.Contains(e.dept_name));
                        bool isCRGTurn = userLogin.dataUsers.Any(e => new[] { "CRG" }.Contains(e.dept_name) && currentStatusRespose.dept_res.Contains(e.dept_name));
                        bool isPLANTurn = userLogin.dataUsers.Any(e => new[] { "PLAN" }.Contains(e.dept_name) && currentStatusRespose.dept_res.Contains(e.dept_name));
                        bool isPURTurn = userLogin.dataUsers.Any(e => new[] { "PUR" }.Contains(e.dept_name) && currentStatusRespose.dept_res.Contains(e.dept_name));

                        if (isPETurn)
                        {
                            nextStatusID = flowProgressPE1[Array.IndexOf(flowProgressPE1, currentStatusRespose.statusID) + 1];
                            if (isChecker)
                            {
                                subSQL = $"pae_check_by='{userLogin.dataUsers[0].user_name}'," +
                                  $"pae_check_date = '{DateTime.Now}',";
                            }
                            if (isApprover)
                            {
                                subSQL = $"pae_app_by='{userLogin.dataUsers[0].user_name}'," +
                                   $"pae_app_date = '{DateTime.Now}',";
                            }
                        }
                        if (isPETurn)
                        {
                            nextStatusID = flowProgressCRG[Array.IndexOf(flowProgressCRG, currentStatusRespose.statusID) + 1];
                            if (isChecker)
                            {
                                subSQL = $"pae_check_by='{userLogin.dataUsers[0].user_name}'," +
                                  $"pae_check_date = '{DateTime.Now}',";
                            }
                            if (isApprover)
                            {
                                subSQL = $"pae_app_by='{userLogin.dataUsers[0].user_name}'," +
                                   $"pae_app_date = '{DateTime.Now}',";
                            }
                        }

                        if (isPLANTurn)
                        {
                            nextStatusID = flowProgressCRG[Array.IndexOf(flowProgressCRG, currentStatusRespose.statusID) + 1];
                            if (isChecker)
                            {
                                subSQL = $"plan_check_by='{userLogin.dataUsers[0].user_name}'," +
                                  $"plan_check_date = '{DateTime.Now}',";
                            }
                            if (isApprover)
                            {
                                subSQL = $"plan_app_by='{userLogin.dataUsers[0].user_name}'," +
                                   $"plan_app_date = '{DateTime.Now}',";
                            }
                        }

                        if (isPURTurn)
                        {
                            nextStatusID = flowProgressCRG[Array.IndexOf(flowProgressCRG, currentStatusRespose.statusID) + 1];
                            if (isChecker)
                            {
                                subSQL = $"pur_check_by='{userLogin.dataUsers[0].user_name}'," +
                                  $"pur_check_date = '{DateTime.Now}',";
                            }
                            if (isApprover)
                            {
                                subSQL = $"pur_app_by='{userLogin.dataUsers[0].user_name}'," +
                                   $"pur_app_date = '{DateTime.Now}',";
                            }
                        }


                        string sql = $"UPDATE mr " +
                                             $"SET  " +
                                             $"status_id= {nextStatusID}" +
                                             subSQL +
                                             $"note = 'mr.note || {check_comment}' " +
                                             $"WHERE mr_id = {int.Parse(id)}";

                        db.ExcuteQueryAndGetData(sql);
                        status = true;
                        success.Add(int.Parse(id));
                    }
                    if (isPAETurn == false && isOtherDeptTurn == false)
                    {
                        status = false;
                        fail.Add("MRNo: " + currentStatusRespose.MRNo + " is not your turn CHECK/APPROVE");
                    }

                }

            }
            else
            {
                status = false;
                msg = "You do not has permision to check MR";
                goto exit;
            }

        exit:
            var result = new
            {
                status = status,
                msg = msg,
                success = success,
                fail = fail,
            };
            return Json(result);
        }
        public JsonResult api_approveMR(string mRIDs, string comment)
        {
            var result = new
            {
                status = true,
                msg = DateTime.Now + "MR was issue by NVQ on 11-11-2024, MRNo: 123456"
            };
            return Json(result);
        }

        public JsonResult api_rejectMR(string mRIDs, string comment)
        {
            var result = new
            {
                status = true,
                msg = DateTime.Now + "MR was issue by NVQ on 11-11-2024, MRNo: 123456"
            };
            return Json(result);
        }

        public JsonResult api_getMRByID(int id)
        {

            bool status = false;
            string msg = "";
            var islogin = authen.isLoginAndReturnUserProfile(HttpContext);

            dataReturn data = new dataReturn();
            if (islogin.status)
            {
                data = db.getMRByID(id);
                status = true;
            }
            else
            {
                msg = "Please login!";
                status = false;
            }


        exit:
            var output = new
            {
                status = status,
                msg = msg,
                Data = data.data,
            };
            return Json(output);
        }

        public JsonResult api_getMRStatusResponByID(int id)
        {

            bool status = false;
            string msg = "";
            var islogin = authen.isLoginAndReturnUserProfile(HttpContext);

            dataReturn data = new dataReturn();
            if (islogin.status)
            {
                data = db.getMRStatusResponByID(id);
                status = true;
            }
            else
            {
                msg = "Please login!";
                status = false;
            }


        exit:
            var output = new
            {
                status = status,
                msg = msg,
                Data = data.data,
            };
            return Json(output);
        }
    }
}
