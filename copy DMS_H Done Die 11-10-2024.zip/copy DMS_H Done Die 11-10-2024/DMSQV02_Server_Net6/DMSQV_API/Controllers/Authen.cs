﻿using DMSQV_API.Data;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using DMSQV_API.Models;
using System.Reflection.Metadata;
using static DMSQV_API.Data.DBConnector;
using System.Data;

namespace DMSQV_API.Controllers
{
    public class Authen : Controller
    {
        DBConnector db = new DBConnector();
        CommonFunction commonfunction = new CommonFunction();
        SendEmail sendEmail = new SendEmail();
        public async Task<JsonResult> api_login(string code, string password)
        {
            // Kiểm tra user có tồn tại hau ko?
            // nếu user ID > 0 là tồn tại và tạo cookie trả về client + thông tin users + status = true
            // nếu user = 0 ko tồn tại user, trả về client status = false và user = null
            bool status = false;
            string encodePW = encodePassword.EncodePasswordMd5(password);
            var result = db.ExistUser(code, encodePW);
            var user_id = (int)result.data[0].Values.ToList()[0];

            if (user_id > 0) // có tồn tại user này rồi
            {
                // tạo cookie
                var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, user_id.ToString())
                };
                var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity));
                status = true;
                //HttpContext.Session.SetString("user_id", user_id.ToString());
                //var isCookiePresent = Request.Cookies.ToList();
            }
            var output = new
            {
                status = status,
                user = api_getUserProfile(user_id),
            };
            return Json(output);
        }

        public async Task<JsonResult> api_logout()
        {
            // clear cookie and session
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            HttpContext.Session.Clear();
            return Json(true);
        }

        // goi tu controller khac
        public CheckUserLogin isLoginAndReturnUserProfile(HttpContext httpcontext)
        {
            
            bool isLogin = true;
            // Lấy user_id dùng từ claim cookie
            var user_id = httpcontext.User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value;

            // Lấy các thông tin khác nếu cần
            var userInfor = httpcontext.User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier)?.Value;

            if (user_id == null)
            {
                user_id = "0";
                isLogin = false;
            }


            var output = new CheckUserLogin
            {
                status = isLogin,
                dataUsers = db.getUserProfile(int.Parse(user_id)),
            };

            return output;
        }

        //goi truc tiep tu view
        public CheckUserLogin api_isLoginAndReturnUserProfile()
        {

            var output = isLoginAndReturnUserProfile(HttpContext);
            return output;
        }
        public List<user> api_getUserProfile(int user_id)
        {
            List<user> dataUsers = db.getUserProfile(user_id);
            return dataUsers;
        }

        public object api_resetPW(string user_code)
        {
            bool status = false;
            string newPW = encodePassword.RandomString(6);
            string encodePW = encodePassword.EncodePasswordMd5(newPW);
            var result = db.resetPW(user_code, encodePW);
            if (result.rowEffected > 0)
            {
                status = true;
                sendEmail.sendEmailResetPW(user_code, newPW);
            }
            var output = new
            {
                status = status,
                data = result
            };

            return Json(output);
        }

        public object api_createNewAccount(string user_code, string user_name, string password, string buyer_code, string grade_id, string email, string dept_id)
        {
            bool status = false;
            string msg = "";
            var arrayParameter = new[] { user_code, user_name, password, grade_id, email, dept_id };
            int grade_id_int = int.Parse(grade_id);
            string[] dept_ids = dept_id.Split(',');
            bool testResult = commonfunction.checkArrayHasAnyElementNullOrEmpty(arrayParameter);
            if (!testResult)
            {
                var isExistUser = db.isExistEmployeeCode(user_code);
                if (isExistUser)
                {
                    status = false;
                    msg = $"This Employee Code {user_code} already register account, Please reset PW if you forgot";
                }
                else // tao tai khoan moi
                {
                    var result = db.CreateNewDMSAccount(user_code, user_name, password, buyer_code, grade_id_int, email, dept_ids);

                    status = true;
                    msg = "Create sucess! Please wait Admin verify you account!";
                }
            }
            else
            {
                status = false;
                msg = "Please input all information!";
            }

            var output = new
            {
                status = status,
                msg = msg,
            };
            return Json(output);
        }


        public object api_changeUserProfile(string user_name, string user_code, int grade_id, string buyer_code, string email)
        {
            bool status = false;
            string msg = "";
            var islogin = isLoginAndReturnUserProfile(HttpContext);
            if (islogin.status)
            {

                if (islogin.dataUsers[0].user_code != user_code) // user đang thay đổi user_code => phải check xem code mới đã có chưa
                {
                    // ktra use code mới
                    bool isExistUser_code = db.isExistEmployeeCode(user_code);
                    if (isExistUser_code) // đã có user code này
                    {
                        status = false;
                        msg = "code " + user_code + " already exist!";
                        goto exit;
                    }
                }
                else // cho phep edit profile
                {
                    string sql = $"UPDATE public.users SET user_name='{user_name}', user_code='{user_code}', buyer_code='{buyer_code}', grade_id={grade_id}, email='{email}' WHERE user_id = {islogin.dataUsers[0].user_id}";
                    var result = db.ExcuteQueryAndGetData(sql);
                    if (result.rowEffected > 0)
                    {
                        status = true;
                        msg = "Change Profile success!";

                    }
                }

            }

        exit:
            var output = new
            {
                status = status,
                msg = msg,
                dataUser = db.getUserProfile(islogin.dataUsers[0].user_id)
            };
            return Json(output);

        }

        // update 1.Sept.2024: all
        public object api_getListUsers(string? user_name, string? user_code, string? dept_id, int? page = 1, int? pageSize = 10)
        {
            user_name = user_name?.Trim();
            user_code = user_code?.Trim();
            bool status = false;
            string msg = "";
            var islogin = isLoginAndReturnUserProfile(HttpContext);

            dataReturn data = new dataReturn();
            if (islogin.status)
            {
                if (islogin.dataUsers[0].is_admin == false)
                {
                    msg = "You are not admin!";
                    status = false;
                    goto exit;
                }

                data = db.getListUser(user_name, user_code, dept_id, page, pageSize);
                status = true;
            }
            else
            {
                msg = "Please login!";
                status = false;
            }


        exit:
            var output = new
            {
                status = status,
                msg = msg,
                recordsTotal = data.totalCount,
                recordsFiltered = data.totalCount,
                page = page,
                pageSize = pageSize,
                Data = data.data,
            };
            return Json(output);
        }

        // update 1.Sept.2024: all
        public object api_getUserProfileByID(int user_id)
        {
            bool status = false;
            string msg = "";
            dataReturn roles = new dataReturn();
            dataReturn userProfile = new dataReturn();
            var islogin = isLoginAndReturnUserProfile(HttpContext);
            if (islogin.status)
            {
                if (islogin.dataUsers[0].is_admin == false)
                {
                    msg = "You are not admin!";
                    status = false;
                    goto exit;
                }

                string sqlGetUserProfile = $"select * from users where user_id = {user_id}";
                string sqlGetRoles = $"select ur.*, d.dept_name, d.factory from userrole ur INNER JOIN department d on ur.dept_id = d.dept_id where user_id = {user_id}";
                userProfile = db.ExcuteQueryAndGetData(sqlGetUserProfile);
                roles = db.ExcuteQueryAndGetData(sqlGetRoles);
                status = true;
            }
            else
            {
                msg = "Please login!";
                status = false;
            }

        exit:
            var output = new
            {
                status = status,
                msg = msg,
                userProfile = userProfile.data[0],
                roles = roles.data
            };
            return Json(output);
        }

        // update 1.Sept.2024: all
        public object api_changeOrAddRoleForUser(int user_id, int dept_id, int mr_role_id, int tpi_role_id, int po_role_id, int die_role_id, int dtf_role_id, int dsum_role_id, int dispose_role_id, int dcf_role_id)
        {
            bool status = false;
            string msg = "Success";
            // chỉ admin mới được thao tác api này
            // xử lí data và update hoặc change role cho users
            var islogin = isLoginAndReturnUserProfile(HttpContext);
            if (islogin.status)
            {
                if (islogin.dataUsers[0].is_admin == false)
                {
                    msg = "You are not admin!";
                    status = false;
                    goto exit;
                }

                // update neu role for dept đã tồn tại và add new nếu chưa có 
                string sql = $"INSERT INTO userrole (user_id, dept_id, mr_role_id, tpi_role_id,po_role_id, die_role_id, dtf_role_id, dsum_role_id,dispose_role_id, dcf_role_id )" +
                    $"values ({user_id}, {dept_id}, {mr_role_id}, {tpi_role_id}, {po_role_id},{die_role_id},{dtf_role_id},{dsum_role_id},{dispose_role_id},{dcf_role_id})" +
                    $"ON CONFLICT(user_id, dept_id)" +
                    $"DO update set " +
                    $"mr_role_id = {mr_role_id}," +
                    $"tpi_role_id = {tpi_role_id}," +
                    $"po_role_id = {po_role_id}," +
                    $"die_role_id = {die_role_id}," +
                    $"dtf_role_id = {dtf_role_id}," +
                    $"dsum_role_id = {dsum_role_id}," +
                    $"dispose_role_id = {dispose_role_id}," +
                    $"dcf_role_id = {dcf_role_id};";
                  


                db.ExcuteQueryAndGetData(sql);
                status = true;
            }
            else
            {
                msg = "Please login!";
                status = false;
            }
        exit:
            var output = new
            {
                status = status,
                msg = msg,
            };

            return Json(output);
        }

        // update 1.Sept.2024: all
        public object api_adminVerifyUser(string action, int user_id, string user_name, string user_code, string buyer_code, int grade_id, string email, string lock_reason, string is_admin , string is_active , string is_delete )
        {
            is_admin = is_admin == "on" ? "true" : "false";
            is_active = is_active == "on" ? "true" : "false";
            is_delete = is_delete == "on" ? "true" : "false";
            bool status = false;
            string msg = "Success";
            // chỉ admin mới được thao tác api này
            // xử lí data và update hoặc change role cho users
            var islogin = isLoginAndReturnUserProfile(HttpContext);
            if (islogin.status)
            {
                if (islogin.dataUsers[0].is_admin == false)
                {
                    msg = "You are not admin!";
                    status = false;
                    goto exit;
                }

                // update neu role for dept đã tồn tại và add new nếu chưa có 
                string sql = $"UPDATE users set " +
                                $"user_name = '{user_name}'," +
                                $"user_code = '{user_code}'," +
                                $"buyer_code =' {buyer_code}'," +
                                $"grade_id = {grade_id}," +
                                $"email = '{email}'," +
                                $"lock_reason = '{lock_reason}'," +
                                $"is_admin = '{is_admin}'," +
                                $"is_active = '{is_active}'," +
                                $"is_delete = '{is_delete}' " +
                                $" WHERE user_id = {user_id}";
                //try
                //{
                    db.ExcuteQueryAndGetData(sql);
                    status = true;
                    if (action.Contains("verif"))
                    {
                        sendEmail.sendEmailVerifiedUsers(user_id);
                    }
                //}
                //catch
                //{
                //    status = false;
                //    msg = "Error, data was not save!";
                //}
               
            }
            else
            {
                msg = "Please login!";
                status = false;
            }
        exit:
            var output = new
            {
                status = status,
                msg = msg,
            };

            return Json(output);
        }


    }
}
