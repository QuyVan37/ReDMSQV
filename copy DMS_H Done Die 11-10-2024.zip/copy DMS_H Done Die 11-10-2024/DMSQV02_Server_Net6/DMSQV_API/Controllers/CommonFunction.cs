﻿using DMSQV_API.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualBasic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;

namespace DMSQV_API.Controllers
{
    public class CommonFunction : Controller
    {
        DBConnector db = new DBConnector();

        public bool checkArrayHasAnyElementNullOrEmpty<T>(T[] array)
        {
            if ((array == null || array.Length == 0))
            {
                return true;
            }
            else
            {
                return array.Any(item => item == null);
            }

        }

        // 06.OCT.2024 TẠO DIE, PART VÀ COMMON TỪ MANUAL VÀ TỪ MR ISSUE
        public class createDieResult
        {
            public bool status { set; get; }
            public string msg { set; get; }
        }
        public class manualINPUTDieInfor
        {
            public string partNo { get; set; }
            public string dieCode { get; set; }
            public int modelID { get; set; }
            public int supplierID { get; set; }
            public int processCodeID { get; set; }
            public DateTime targetOK { get; set; }

        }
        public class dieInfoNeedConfig
        {
            public int suffix { set; get; }
            public int dieStatusID { set; get; }
            public string dieClasify { set; get; }
            public string belong { set; get; }
            public bool isOfficial { set; get; }
            public bool isCancel { set; get; }
            public bool isActive { set; get; }
            public bool isClose { set; get; }


        }

        

        public string genarateDieClasify(string dieCode)
        {
            dieCode = dieCode.Replace(" ", "").Trim();
            string output = "INVALID"; // 11A
            if (dieCode == null)
            {
                output = "INVALID";
                goto exit;
            }
           
            if (dieCode.Length != 3)
            {
                output = "INVALID";
                goto exit;
            }

            dieCode = dieCode.ToUpper().Trim();

            if (dieCode == "11A")
            {
                output = "New";
                goto exit;
            }
            if (new[] { "2", "3", "4", "8" }.Contains(dieCode[1].ToString())) //12A,12B,13A,14A
            {
                output = "Renewal";
                goto exit;
            }
            if (dieCode[0] != '1' && dieCode[1] == '1' && dieCode[2] == 'A')
            {
                output = "Additional";
                goto exit;
            }
            output = "INVALID";
        exit:
            return output;

        }

        public List<createDieResult> genarateAndUpdateNEWDIE(manualINPUTDieInfor? manual, Dictionary<string, object>? MR, Dictionary<string, object>? PO, HttpContext httpcontext)
        {
            bool status = false;
            List<createDieResult> output = new List<createDieResult>();
            // xử lí dữ liệu
            var userLogin = new Authen().isLoginAndReturnUserProfile(httpcontext).dataUsers;
            if (manual != null)
            {
                dieInfoNeedConfig config = new dieInfoNeedConfig();
                config.dieClasify = genarateDieClasify(manual.dieCode);
                if (config.dieClasify.Contains("INVALID"))
                {
                    output.Add(new createDieResult
                    {
                        status = false,
                        msg = "Die No/ Dim is not correct!"
                    });
                    goto exit;
                }
               
                config.suffix = 1;
                config.dieStatusID = 1;
                config.belong = "LBP";
                config.isOfficial = false;
                config.isCancel = false;
                config.isActive = true;
                config.isClose = false;
                string source = $"Manual create on {DateTime.Now} by {userLogin[0].user_name}";
                int dieID = AddOrUpdateDIE(config, manual, null, null);
                int partID = AddOrUpdatePART(manual.partNo, null, null);
                int commonID = AddOrUpdateCOMMONTABLE(partID, dieID, source, false, false);
                status = commonID > 0;
                output.Add(new createDieResult
                {
                    status = status,
                    msg = status == true ? $"Succes Add Die {manual.partNo} - {manual.dieCode}" : $"Fail Add Die {manual.partNo} - {manual.dieCode}"
                });
            }
            if (MR != null)
            {
                //3.3 kiểm tra số component lớn hơn 1 và add die và common tương ứng.
                //3.4 Kiểm tra commonpart và add Part và Common tương ứng
                //3.5 Kiểm tra family part và add Part và Common tương ứng
                //3.6 trường hợp vừa component lớn hơn 1 và có commonpart và family part
                int NoOfComponent = 1;
                int.TryParse(MR["no_of_die_component"].ToString(), out NoOfComponent);

                string partNoOrginal = MR["part_no"].ToString();
                string commonPart = MR["common_part"].ToString();
                string familyPart = MR["family_part"].ToString();
                string allPart = $"{partNoOrginal},{commonPart},{familyPart}";
                string[] arrayOfAllPart = allPart.Split(',');

                string noteFamily = String.IsNullOrWhiteSpace(MR["family_part"].ToString()) ? "" : MR["family_part"].ToString().Length > 7 ? $"{MR["part_no"].ToString()} family die with {MR["family_part"].ToString()} " : "";
                string noteCommon = String.IsNullOrWhiteSpace(MR["common_part"].ToString()) ? "" : MR["common_part"].ToString().Length > 7 ? $"{MR["part_no"].ToString()} common die with {MR["common_part"].ToString()} " : "";
                string source = $"From MR [{MR["mr_no"]}]";

                // add comom for original part
                for (int i = 1; i <= NoOfComponent; i++)
                {
                    int dieID = 0;
                    // create config
                    bool isOfficial = false;
                    string PoDate = "";
                    string PayDate = "";
                    if (PO != null)
                    {
                        PoDate = PO["podate"].ToString();
                        PayDate = PO["payment_date"]?.ToString();
                        isOfficial = String.IsNullOrWhiteSpace(PoDate) ? false : true;
                      
                    }
                    dieInfoNeedConfig config = new dieInfoNeedConfig();
                    config.dieClasify = genarateDieClasify(MR["clasification"]?.ToString());
                    config.suffix = i;
                    config.dieStatusID = String.IsNullOrWhiteSpace(PayDate) ? 1 : 2;
                    config.belong = new[] { "INHOUSE", "LBP"}.Contains(MR["belong"].ToString()) ? "LBP" : (new[] { "CRG" }.Contains(MR["belong"].ToString())? "CRG" : "OTHER");
                    config.isOfficial = isOfficial;
                    config.isCancel = false;
                    config.isActive = true;
                    config.isClose = false;
                    if (config.dieClasify.Contains("INVALID"))  // MR Modify
                    {
                        // MR modify có thể add common part 
                        // Lúc này DieID sẽ là die đã tồn tại đang issue MR để modify
                        string sqlGetDieID = $"SELECT die_id FROM dies WhERE dieno = '{MR["die_no"]}'";
                        dieID = int.Parse(db.ExcuteQueryAndGetData(sqlGetDieID).data[0]["die_id"].ToString());
                    } else
                    // ADD DIE
                    {

                        dieID = AddOrUpdateDIE(config, null, MR, PO);
                    }
                   
                    // ADD PART AND COMMON
                    foreach (var raw_part in arrayOfAllPart)
                    {
                        string part = raw_part.Replace(" ", "").Trim();
                        if (part.Length >= 8 && part.Length <= 12)
                        {
                            string note = "";
                            bool isCommon = false;
                            bool isFamaily = false;
                            part = part.Length == 8 ? $"{part}-000" : part.PadRight(12, '0');
                            if (commonPart.Contains(raw_part))
                            {
                                isCommon = true;
                                note = noteCommon;
                            }
                            if (familyPart.Contains(raw_part))
                            {
                                isFamaily = true;
                                note = noteFamily;
                            }
                            int partID = AddOrUpdatePART(part, MR["part_name"].ToString(), note);
                            int commonID = AddOrUpdateCOMMONTABLE(partID, dieID, source, isCommon, isFamaily);
                            status = commonID > 0;
                            output.Add(new createDieResult
                            {
                                status = status,
                                msg = status == true ? $"Succes Added/Updated Die Info {MR["part_no"]} - {MR["clasification"]}" : $"Fail Add/Update Die {MR["part_no"]} - {MR["clasification"]}"
                            });
                        }
                    }
                }
            }

        exit:
            return output;
        }

        public int AddOrUpdateDIE(dieInfoNeedConfig config, manualINPUTDieInfor? manual, Dictionary<string, object>? MR, Dictionary<string, object>? PO)
        {
            //1: ADD DIE
            //1.1: Kiểm tra die đã tồn tại chưa
            //1.2: Add hoặc Edit => Lấy die_id
            int dieID = 0;
            string sql = "";
            string formattedSuffix = config.suffix.ToString().PadLeft(3, '0');
            string dieNo = "";

            if (manual != null)
            {
                dieNo = manual.partNo + "-" + manual.dieCode + "-" + formattedSuffix;
                sql = $"INSERT INTO dies (dieno, part_no_original,die_code, process_code_id, die_classify, belong, model_id, supplier_id, die_status_id, is_official, is_cancel, is_active, is_closed)  " +
                          $"VALUES ('{dieNo}','{manual.partNo}','{manual.dieCode}','{manual.processCodeID}','{config.dieClasify}','{config.belong}','{manual.modelID}','{manual.supplierID}','{config.dieStatusID}', '{config.isOfficial}', '{config.isCancel}','{config.isActive}', '{config.isClose}' )  " +
                          $"ON CONFLICT (dieno)  " +
                          $"DO UPDATE  " +
                          $"SET  " +
                              $"part_no_original = '{manual.partNo}', " +
                              $"die_code = '{manual.dieCode}', " +
                              $"process_code_id = '{manual.processCodeID}', " +
                              $"die_classify = '{config.dieClasify}', " +
                              $"belong = '{config.belong}', " +
                              $"model_id = '{manual.modelID}'::int, " +
                              $"supplier_id = '{manual.supplierID}'::int, " +
                              $"die_status_id = '{config.dieStatusID}', " +
                              $"is_official = '{config.isOfficial}', " +
                              $"is_cancel = '{config.isCancel}', " +
                              $"is_active = '{config.isActive}', " +
                              $"is_closed = '{config.isClose}' " +
                              $"RETURNING die_id";
            }

            if (MR != null)
            {
                string subQLPO = "";
                dieNo = MR["part_no"] + "-" + MR["clasification"] + "-" + formattedSuffix;
                if (PO != null)
                {
                    string subPayDate = String.IsNullOrEmpty(PO["payment_date"]?.ToString()) ? "" : $" start_use = '{PO["payment_date"]}', ";
                    string subWarranty = String.IsNullOrEmpty(PO["warranty_shot"]?.ToString()) ? "" : $" die_warranty_short = '{PO["warranty_shot"]}', ";
                    string subPOdate = String.IsNullOrEmpty(MR["po_date"]?.ToString()) ? "" : $" po_date = '{MR["po_date"].ToString()}', ";
                    subQLPO = subPayDate + subWarranty + subPOdate;
                }

                string subQLDieCost = String.IsNullOrEmpty(MR["app_cost_exchange_usd"]?.ToString()) ? "" : $" die_cost_usd = '{MR["app_cost_exchange_usd"].ToString()}', ";
                sql = $"INSERT INTO dies (dieno, part_no_original,die_code, process_code_id, die_classify, belong, mc_size, cav_quantity, model_id, supplier_id, die_maker, die_make_location, special_spec, die_cost_usd, po_date,die_status_id, is_official, is_cancel, is_active, is_closed)  " +
                      $"VALUES ('{dieNo}','{MR["part_no"]}','{MR["clasification"]}','{MR["process_code_id"]}','{config.dieClasify}','{config.belong}','{MR["mc_size"]}','{MR["cav_qty"]}','{MR["model_id"]}','{MR["supplier_id"]}','{MR["die_maker"]}', '{MR["make_location"]}', '{MR["die_special"]}', '{MR["app_cost_exchange_usd"]}','{MR["po_date"]}', '{config.dieStatusID}', '{config.isOfficial}', '{config.isCancel}','{config.isActive}', '{config.isClose}' )  " +
                      $"ON CONFLICT (dieno)  " +
                      $"DO UPDATE  " +
                      $"SET  " +
                          $"part_no_original = '{MR["part_no"]}', " +
                          $"die_code = '{MR["clasification"]}', " +
                          $"process_code_id = '{MR["process_code_id"]}', " +
                          $"die_classify = '{config.dieClasify}', " +
                          $"belong = '{config.belong}', " +
                          $"mc_size = '{MR["mc_size"]}'::int, " +
                          $"cav_quantity = '{MR["cav_qty"]}'::int, " +
                          $"model_id = '{MR["model_id"]}'::int, " +
                          $"supplier_id = '{MR["supplier_id"]}'::int, " +
                          $"die_maker = '{MR["die_maker"]}', " +
                          $"die_make_location = '{MR["make_location"]}', " +
                          $"special_spec = '{MR["die_special"] + System.Environment.NewLine}' || dies.special_spec, " +
                          $" {subQLDieCost} " +
                          $" {subQLPO} " +
                          $"die_status_id = '{config.dieStatusID}', " +
                          $"is_official = '{config.isOfficial}', " +
                          $"is_cancel = '{config.isCancel}', " +
                          $"is_active = '{config.isActive}', " +
                          $"is_closed = '{config.isClose}' " +
                          $"RETURNING die_id";
            }

            dieID = int.Parse(db.ExcuteQueryAndGetData(sql).data[0]["die_id"].ToString());

            return dieID;
        }

        public int AddOrUpdatePART(string partNo, string? partName, string? note)
        {
            //2.1 Kiểm tra đã tồn tại part này chưa?
            //2.2 Add hoặc Edit => Lấy part_id
            int partID = 0;
            string sql = $"INSERT INTO parts (part_no, part_name, note)" +
                         $"VALUES ('{partNo.ToUpper()}','{partName}','{note}') " +
                         $"ON CONFLICT (part_no) " +
                         $"DO UPDATE  " +
                         $"SET part_name = '{partName}', " +
                         $"note = '{note}' " +
                         $"RETURNING part_id";
            partID = int.Parse(db.ExcuteQueryAndGetData(sql).data[0]["part_id"].ToString());
            return partID;
        }

        public int AddOrUpdateCOMMONTABLE(int partID, int dieID, string sourceFrom, bool isCommon, bool isFamily)
        {
            //3.1 Kiểm tra đã có common này chưa,
            //3.2 Add hoặc edit
            int commonID = 0;
            string sql = $"INSERT INTO common_die (die_id, part_id, is_active, issue_date, source_from, is_common_part, is_family_die) " +
                $"VALUES({dieID},{partID},true, '{DateTime.Now}', '{sourceFrom}', '{isCommon}', '{isFamily}') " +
                $"ON CONFLICT(die_id, part_id) " +
                $"DO UPDATE " +
                $"set is_active = true, " +
                $" is_common_part = {isCommon}, " +
                $" is_family_die = {isFamily}, " +
                $"source_from = '{DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss ") + sourceFrom + System.Environment.NewLine}' || common_die.source_from " +
                $"RETURNING common_id ";
            var dataResult = db.ExcuteQueryAndGetData(sql).data[0];
            commonID = int.Parse(dataResult["common_id"].ToString());
            return commonID;
        }


    }
}
