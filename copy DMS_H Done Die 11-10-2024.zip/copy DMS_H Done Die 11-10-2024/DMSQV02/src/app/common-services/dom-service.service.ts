import { Injectable } from '@angular/core';

import moment from 'moment';
import { AppAPIService } from '../API-Services/app-api.service';
import { AuthenService } from '../API-Services/authen.service';
import { group } from '@angular/animations';
import { ChartApexService } from './chart.apex.service';
declare var $: any;
declare var bootstrap: any;
declare function selectjs(): any
@Injectable({
  providedIn: 'root'
})
export class DOMServiceService {

  constructor(
    private APIservices: AppAPIService,
    private Authen: AuthenService,
    private chartService: ChartApexService

  ) { }
  onloading(selector: string) {
    $(document).find(selector).addClass('disabled')
    $(document).find(selector).children('.spinner-border').remove()
    $(document).find(selector).append(
      `
        <span class="spinner-border spinner-border-sm" aria-hidden="true"></span>
      `)
  }

  onloaded(selector: string) {
    $(document).find(selector).children('.spinner-border').remove()
    $(document).find(selector).removeClass('disabled')
  }

  fieldSorter(fields: any[]) {
    return function (a: any, b: any) {
      return fields
        .map(function (o) {
          var dir = 1;
          if (o[0] === '-') {
            dir = -1;
            o = o.substring(1);
          }
          if (a[o] > b[o]) return dir;
          if (a[o] < b[o]) return -(dir);
          return 0;
        })
        .reduce(function firstNonZeroValue(p, n) {
          return p ? p : n;
        }, 0);
    };
  }
  createOptionElement(
    listOption: any[] | undefined,
    fields_view: Array<string>,
    Field_value: string,
    selected_Value: string
  ): string {
    let option = '<option value="">---</option>';
    listOption?.forEach(e => {
      let view: Array<string> = [];
      fields_view.forEach(f => {
        view.push(e[f]);
      });
      option += `<option ${e[Field_value] === selected_Value ? 'selected' : ''} value="${e[Field_value]}">${view.join('-')}</option>`;
    });
    return option;
  }

  appendToElement(selector: string, content: string) {
    $(selector).empty().append(content)
  }


  showAlertMassage(massage: string | undefined, isSucces: boolean) {

    // massageType: success or faill
    let bg_color = "danger"
    if (isSucces) bg_color = 'success'
    //1. Loại bỏ modal ra khỏi DOM nếu có
    $(document).find('#modelAlertMassage').remove()
    //2. add modal vào DOM
    $('.content').append(
      `
     <div class="modal fade" id="modelAlertMassage" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
     <div class="modal-dialog">
         <div class="modal-content">
         <div class="modal-header bg-${bg_color} text-white">
             <h1 class="modal-title fs-5" id="exampleModalLabel">System massage</h1>
             <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
         </div>
         <div class="modal-body">
             ${massage}
         </div>
         <div class="modal-footer">
             <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
         </div>
         </div>
     </div>
     </div>
     `
    )

    // 3. show modal
    const modalMassage = new bootstrap.Modal('#modelAlertMassage', {
      keyboard: false
    })
    modalMassage.show()
  }

  showUserInActiveWaning(msg: string) {
    //1. Loại bỏ modal ra khỏi DOM nếu có
    $(document).find('#modelAlertMassage').remove()

    $('.content').append(
      `
        <div class="modal fade" id="modalWarningUserNotActive" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header bg-danger">
                <h1 class="modal-title fs-5" id="staticBackdropLabel">Waring: You account was not active!</h1>
              </div>
              <div class="modal-body">
                  ${msg}

              </div>
                <div class="modal-footer">
                  <a href="/login">Login other account</a>
                </div>
            </div>
          </div>
        </div>
     `
    )
    // 3. show modal
    const modalMassage = new bootstrap.Modal('#modalWarningUserNotActive', {
      keyboard: false
    })
    modalMassage.show()

  }

  pagination(page: number = 1, pageSize: number = 0, totalRecords: number = 0, selector: string) {

    let previousePage = page - 1;
    let nextPage = page + 1;
    let firstPage = 1;
    let lastPage = Number.isNaN(Math.ceil(totalRecords / pageSize)) ? 1 : Math.ceil(totalRecords / pageSize);
    nextPage = nextPage > lastPage ? lastPage : lastPage == 0 ? 0 : nextPage

    let pagination = `
      
      <ul class="pagination m-0">
        <li class="page-item page-link page-data disabled">${totalRecords} records found</li>
        <li class="page-item ${previousePage == 0 ? "disabled" : ""}">
         <span class="cursor page-link page-data" data-page = ${previousePage} >Previous</span>
        </li>
        ${previousePage >= 1 ?
        `<li class="page-item">
             <span class="cursor page-link page-data" data-page = ${firstPage}  href="#">${firstPage}</span>
          </li>
          <li class="page-item page-link page-data disabled">...</li>
          ` : ''}
         
          ${page > 1 ?
        ` <li class="page-item">
              <span class="cursor page-link page-data" data-page = ${previousePage} href="#">${previousePage}</span>
              </li>
            ` : ''}
        
        <li class="page-item">
         <span class="cursor page-link page-data active" data-page = ${page} href="#">${page}</span>
        </li>
        ${nextPage == page || nextPage == 0 ? "" :
        `
            <li class="page-item">
             <span class="cursor page-link page-data" data-page = ${nextPage} href="#">${nextPage}</span>
            </li>
          `
      }
        ${lastPage - nextPage >= 1 ?
        `
          <li class="page-item page-link page-data disabled">...</li>
          <li class="page-item">
             <span class="cursor page-link page-data" data-page = ${lastPage} href="#">${lastPage}</span>
            </li>
          
          ` : ''}
        
            <li class="page-item">
             <span class="cursor page-link page-data ${nextPage == page || nextPage == 0 ? 'disabled' : ''}"  data-page = ${nextPage} href="#">Next</span>
            </li>
        
      </ul>

    `
    $(selector).empty().append(pagination)

  }


  async renderModalUserDetail(userProfile: any) {
    let listGrade = await this.APIservices.getGradeCategory().toPromise()
    let listDept = await this.APIservices.getListDept().toPromise()
    let listRole = await this.APIservices.getRolesCategory().toPromise()
    let user = userProfile.userProfile;
    let roles = userProfile.roles;
    let depts = roles.map((e: any) => {
      return e.dept_name + '-' + e.factory
    });

    //1. Loại bỏ modal ra khỏi DOM nếu có
    $(document).find('#showmodalDetail').remove()
    $('.content').append(`
        <div class="modal fade" id="showmodalDetail" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">User ${user.user_name}</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <form action="" method="post" id="form_user_information">
                  <div class="row g-2">
                    <div hidden class="nice-form-group col-sm-12 col-md-2">
                      <label>User_id</label>
                      <input type="text" hidden name="user_id" value='${user.user_id}'>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <label>Name</label>
                      <input type="text" name="user_name" value='${user.user_name}'>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <label>Code</label>
                      <input type="text" name="user_code" value='${user.user_code}'>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <label>Buyer code</label>
                      <input type="text" name="buyer_code" value='${user.buyer_code}'>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <label>Grade</label>
                      <select name="grade_id">
                        ${this.createOptionElement(listGrade?.data, ["grade_name"], 'grade_id', user.grade_id)}
                      </select>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <label>Email</label>
                      <input type="email" name="email" value='${user.email}'>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <label>Lock Reason</label>
                      <input type="text" name="lock_reason" value='${user.lock_reason}'>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <label>Last_online</label>
                      <input type="text" disabled name="last_online" value='${moment(user.last_online).format('YYYY/MM/DD HH:mm:ss A')}'>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <label>Create Date</label>
                      <input type="text" disabled name="create_date" value='${moment(user.create_date).format('YYYY/MM/DD HH:mm:ss A')}'>
                    </div>
                  </div>
                  <div class="row">
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <input name="is_admin" type="checkbox" id="isAdmin" ${user.is_admin ? "checked" : ""} class="switch" />
                      <label for="isAdmin">Admin</label>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <input name="is_active" type="checkbox" id="is_Active" ${user.is_active ? "checked" : ""} class="switch" />
                      <label for="is_Active">Active</label>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <input name="is_delete" type="checkbox" id="is_Delete" ${user.is_delete ? "checked" : ""} class="switch" />
                      <label for="is_Delete">Delecte</label>
                    </div>

                  </div>
                 
                </form>
                <hr>
                <div>
                  This user was set roles for 2 depts: <span class="fw-bold">${depts}</span>
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <form action="" method="post" id="form_update_role">
                      <div class="row">

                        <div class="row g-2">
                          <div class="nice-form-group col-md-12">
                            <label>Department</label>
                            <select name="dept_id" class='selectjs'>
                            ${this.createOptionElement(listDept?.data, ["dept_name", 'factory'], 'dept_id', roles[0].dept_id)}
                            </select>
                          </div>
                          <div class="nice-form-group col-sm-12 col-md-3">
                            <label>MR Role</label>
                            <select name="mr_role_id">
                             ${this.createOptionElement(listRole?.data, ["role_name"], 'role_id', roles[0].mr_role_id)}
                            </select>
                          </div>
                          <div class="nice-form-group col-sm-12 col-md-3">
                            <label>PO Role</label>
                            <select name="po_role_id">
                             ${this.createOptionElement(listRole?.data, ["role_name"], 'role_id', roles[0].po_role_id)}
                            </select>
                          </div>
                          <div class="nice-form-group col-sm-12 col-md-3">
                            <label>TPI Role</label>
                            <select name="tpi_role_id">
                             ${this.createOptionElement(listRole?.data, ["role_name"], 'role_id', roles[0].tpi_role_id)}
                            </select>
                          </div>
                          <div class="nice-form-group col-sm-12 col-md-3">
                            <label>Die Role</label>
                            <select name="die_role_id">
                             ${this.createOptionElement(listRole?.data, ["role_name"], 'role_id', roles[0].die_role_id)}
                            </select>
                          </div>
                          <div class="nice-form-group col-sm-12 col-md-3">
                            <label>Transfer (DTF)</label>
                            <select name="dtf_role_id">
                             ${this.createOptionElement(listRole?.data, ["role_name"], 'role_id', roles[0].dtf_role_id)}
                            </select>
                          </div>
                          <div class="nice-form-group col-sm-12 col-md-3">
                            <label>DSUM (DFM)</label>
                            <select name="dsum_role_id">
                             ${this.createOptionElement(listRole?.data, ["role_name"], 'role_id', roles[0].dsum_role_id)}
                            </select>
                          </div>
                          <div class="nice-form-group col-sm-12 col-md-3">
                            <label>Dispose</label>
                            <select name="dispose_role_id">
                             ${this.createOptionElement(listRole?.data, ["role_name"], 'role_id', roles[0].dispose_role_id)}
                            </select>
                          </div>
                          <div class="nice-form-group col-sm-12 col-md-3">
                            <label>DCF</label>
                            <select name="dcf_role_id">
                             ${this.createOptionElement(listRole?.data, ["role_name"], 'role_id', roles[0].dcf_role_id)}
                              </select>
                          </div>
                        </div>
                      </div>
                      <div class="d-flex justify-content-end mt-2">
                        <span data-user-id="${user.user_id}" class="btn btn-primary btn_admin_change_user_role">Change Role</span>
                      </div>
                    
                    </form>
                  </div>
                </div>

              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" action="save" class="btn btn-primary  btn_admin_verified_users">Save
                  changes</button>
                <button type="button" action="verify" class="btn btn-primary btn_admin_verified_users" ">Verified</button>
                 
              </div>
            </div>
          </div>
        </div>
    
    
    
    `)

    const modalMassage = new bootstrap.Modal('#showmodalDetail', {
      keyboard: false
    })
    modalMassage.show()
  }

  async renderModalMRDetail(mr_id: number) {

    let data = await this.APIservices.getMRById(mr_id).toPromise();
    let mrTypeCategory = await this.APIservices.getMRTypeCategory().toPromise()
    let suppliers = await this.APIservices.getSupplierList().toPromise()


    let mr: any = data?.data[0];
    let statusRes = await this.APIservices.getMRStatusRespon(mr.status_id).toPromise()
    let users = this.Authen.isLogined().user
    let isAdmin = users[0].is_admin
    let userDeptsAndRole: { dept_name: any, factory: any, mr_role_id: any, grade_id: number }[] = []

    users.forEach((e: any) => {
      userDeptsAndRole.push({
        dept_name: e.dept_name,
        factory: e.factory,
        mr_role_id: e.mr_role_id,
        grade_id: e.grade_id
      })

    })



    let listTPIattach: any = []
    let listDFM: any = []
    if (mr.tpi_id) {
      let listIDs = mr.tpi_id.split(',')
      listIDs.forEach((e: any, index: number) => {
        listTPIattach.push(`[<a target="_blank" href="/tpi/${e}">TPI ${index + 1}</a>]`)
      })
    }
    if (mr.dfm_id) {
      let listIDs = mr.dfm_id.split(',')
      listIDs.forEach((e: any, index: number) => {
        listDFM.push(`[<a target="_blank" href="/dsum/${e}">DFM ${index + 1}</a>]`)
      })
    }

    // Phân quyền
    let isChecker = userDeptsAndRole.some((e: any) => { return ["PAE", "PE1", "CRG", "PLAN", "PUR"].includes(e.dept_name) && ["QV"].includes(e.factory) && [3].includes(e.mr_role_id) })
    let isApprover = userDeptsAndRole.some((e: any) => { return ["PAE", "PE1", "CRG", "PLAN", "PUR"].includes(e.dept_name) && ["QV"].includes(e.factory) && [4, 5].includes(e.mr_role_id) })
    let isYourTurn = userDeptsAndRole.some((e: any) => { return statusRes?.data[0].dept_res.includes(e.dept_name) && statusRes?.data[0].mr_role_id_res <= e.mr_role_id })
    let isShowPermit = (isChecker || isApprover) && isYourTurn
    let isPAETurn = userDeptsAndRole.some((e: any) => { return ["PAE"].includes(e.dept_name) && statusRes?.data[0].dept_res.includes("PAE") })
    let permitContentForPAE = `
      <form action="" method="post" id="form_PAE_Check_MR" class="checkMR">
        <div class="responseTitle">${statusRes?.data[0].dept_res} Check</div>
        <div class="row">
            <div class='col-10'>
              <div class="row g-2">
                <div class="nice-form-group col-sm-12 col-md-2">
                  <label>DE Die</label>
                  <select name="check_is_de_die">
                    <option  value="N">No</option>
                    <option ${mr.is_de_die ? "selected" : ""} value="Y">Yes</option>
                  </select>
                </div>
                <div class="nice-form-group col-sm-12 col-md-2">
                  <label>Die Component</label>
                  <input  type='text' name='check_no_of_die_component' value='${mr.no_of_die_component}' />
                </div>
                <div class="nice-form-group col-sm-12 col-md-2">
                  <label>Die Maker</label>
                  <input  type='text' name='check_die_maker' value='${mr.order_to}' />
                </div>
                <div class="nice-form-group col-sm-12 col-md-2">
                  <label>Location</label>
                  <input  type='text' name='check_make_location' placeholder="VN,CN,JP,..." value='${mr.make_location}' />
                </div>
                <div class="nice-form-group col-sm-12 col-md-4">
                  <label> Die_special</label>
                  <input  type='text' name='check_die_special' placeholder="HC,H&C, Printing,..." value='${mr.die_special}' />
                </div>
                <div class="nice-form-group  col-md-12">
                  <label>Comment</label>
                  <textarea type='text' name='check_comment' placeholder=""></textarea>
                </div>
              </div>
            </div>
            <div class='col-2'>
               <div class="d-grid gap-2 mt-4 align-self-end">
               ${isChecker ? ` <button class="btn btn-primary btn_check_MR" data-mr-id="${mr.mr_id}" type="button">CHECK</button>` : ""}
               ${isApprover ? ` <button class="btn btn-success btn_Approve_MR" data-mr-id="${mr.mr_id}" type="button">APPROVE</button>` : ""}
                <button class="btn btn-danger btn_reject_MR" type="button" data-mr-id="${mr.mr_id}" >REJECT</button>
              </div>
            </div>
            
          </div>
            
      </from>
    
    `
    let OtherDeptCheck = `
      <form action="" method="post" id="form_Other_dept_Check_MR" class="checkMR">
        <div class="responseTitle">${statusRes?.data[0].dept_res} Check</div>
        <div class="row">
            <div class='col-10'>
              <div class="row g-2">
                <div class="nice-form-group  col-md-12">
                  <label>Comment</label>
                  <textarea type='text' name='check_comment' placeholder=""></textarea>
                </div>
              </div>
            </div>
            <div class='col-2'>
               <div class="d-grid gap-2 mt-4">
                ${isChecker ? ` <button class="btn btn-primary btn_check_MR" data-mr-id="${mr.mr_id}" type="button">CHECK</button>` : ""}
                ${isApprover ? ` <button class="btn btn-success btn_Approve_MR" data-mr-id="${mr.mr_id}" type="button">APPROVE</button>` : ""}
                <button class="btn btn-danger btn_reject_MR" type="button" data-mr-id="${mr.mr_id}" >REJECT</button>
              </div>
            </div>
            
          </div>
            
      </from>
    `
    //1. Loại bỏ modal ra khỏi DOM nếu có
    $(document).find('#showModalMRDetail').remove()
    $('.content').append(`
        <div class="modal fade" id="showModalMRDetail" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-xl">
            <div class="modal-content">
              <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">MRNo: <span title='click to download MR form' class='cursor text-primary download-mr' data-mr-id = '${mr.mr_id}'>${mr.mr_no}</span> </h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <form action="" method="post" id="form_mr_information">
                  <div class="row g-2">
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>MR Type</label>
                      <select ${isAdmin ? "" : "disabled"} name='mr_type_id'>
                          ${this.createOptionElement(mrTypeCategory?.data, ["type"], "mr_type_id", mr.type_id)}
                      </select>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Location</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='location' value='${mr.location}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>PDD</label>
                      <input ${isAdmin ? "" : "disabled"} type='date' name='pdd' value='${moment(mr.pdd).format('YYYY-MM-DD')}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>G/L Account</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='gl_account' value='${mr.gl_account}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Budget Code</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='budget_code' value='${mr.budget_code}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Asset No</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='asset_number' value='${mr.asset_number}' />
                    </div>
                    
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Part No</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='part_no' value='${mr.part_no}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Part Name</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='part_name' value='${mr.part_name}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Model</label>
                      <select ${isAdmin ? "" : "disabled"} name='model_id' class='${isAdmin ? "selectjs" : ""}'>
                        ${this.createOptionElement(mrTypeCategory?.data, ["type"], "mr_type_id", mr.type_id)}
                      </select>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Dim</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='clasification' value='${mr.clasification}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>CAV Qty</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='cav_qty' value='${mr.cav_qty}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>MC Size</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='mc_size' value='${mr.mc_size}' />
                    </div>
                    
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Die_ID</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='die_no' value='${mr.die_no}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Supplier</label>
                      <select ${isAdmin ? "" : "disabled"} name='supplier_id' class='${isAdmin ? "selectjs" : ""}'>
                        ${this.createOptionElement(suppliers?.data, ["supplier_code", 'supplier_name'], "supplier_id", mr.supplier_id)}
                      </select>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Order To</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='order_to' value='${mr.order_to}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Draw His</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='draw_his' value='${mr.draw_his}' />
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>ECN No</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='ecn_no' value='${mr.ecn_no}' />
                    </div> 
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>DE-Die</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='is_de_die' value='${mr.is_de_die === '' ? "-" : mr.is_de_die ? "Y" : "N"}' />
                    </div> 
                    <div class="nice-form-group col-sm-12 col-md-4">
                      <label>Reason</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='reason' value='${mr.reason}' />
                    </div>   
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Estimate Cost</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='estimate_cost' value='${mr.estimate_cost}' />
                    </div>  
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Approved Cost</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='app_cost' value='${mr.app_cost}' />
                    </div>  
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Unit</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='unit' value='${mr.unit}' />
                    </div> 
                    
                    <div class="nice-form-group col-sm-12 col-md-2">
                      <label>Component</label>
                      <input ${isAdmin ? "" : "disabled"} type='text' name='no_of_die_component' value='${mr.no_of_die_component}' />
                    </div> 
                  </div>
                  <div class="row">
                    <div class="col-md-6 mt-1">
                      <div class="row g-2">
                        <div class="nice-form-group col-sm-12 col-md-4">
                          <label>Sucess Die ID</label>
                          <input ${isAdmin ? "" : "disabled"} type='text' name='sucess_die_id' value='${mr.sucess_die_id}' />
                        </div> 
                        <div class="nice-form-group col-sm-12 col-md-4">
                          <label>Sucess Part No</label>
                          <input ${isAdmin ? "" : "disabled"} type='text' name='sucess_part_no' value='${mr.sucess_part_no}' />
                        </div> 
                        <div class="nice-form-group col-sm-12 col-md-4">
                          <label>Disposed Die ID</label>
                          <input ${isAdmin ? "" : "disabled"} type='text' name='dispose_die_id' value='${mr.dispose_die_id}' />
                        </div>
                        <div class="nice-form-group col-sm-12 col-md-12">
                          <label>Common parts</label>
                          <input ${isAdmin ? "" : "disabled"} type='text' name='common_part' value='${mr.common_part}' title='separate by [,]' placeholder="RC5-1234-000,RC53456-000,...." />
                        </div>
                        <div class="nice-form-group col-sm-12 col-md-12">
                          <label>Family parts</label>
                          <input ${isAdmin ? "" : "disabled"} type='text' name='family_part' value='${mr.family_part}' title='separate by [,]' placeholder="RC5-1234-000,RC53456-000,...." />
                        </div>
                      </div>
                    </div>
                      <div class="col-md-6">
                        <div class="nice-form-group">
                          <label>Remark</label>
                          <textarea ${isAdmin ? "" : "disabled"}  rows="5" name='note'>${mr.note}</textarea>
                        </div> 
                        <div>
                          Attachments/ References
                        </div>
                        <span>
                          ${mr.pur_attach ? `[<span title="click to download" class='cursor text-primary download-att' data-att-path="${mr.pur_attach}">PUR Attach</span>]` : ""}
                        </span>
                        <span>
                          ${listTPIattach ? listTPIattach : ""}
                        </span>
                      </div>
                    </div>
                 
                </form>
                <table class="table table-sm table-bordered border-primary text-center mt-1" style="font-size:0.75rem">
                  <thead>
                    <tr>
                      <th colspan="8"> PROGRESS</th>
                    </tr>
                    <tr>
                      <th colspan="2" width="25%">Requested</th>
                      <th colspan="2" width="25%">${mr.belong.includes("CRG") ? "CRG" : mr.belong.includes("LBP") ? "PAE" : "PE"}</th>
                      <th colspan="2" width="25%">PLAN</th>
                      <th colspan="2" width="25%">PUR</th>
                    </tr>
                  <thead>
                  <tbody class="text-left">
                      <tr>
                        <td>Issued/Requested</td>
                        <td>${mr.request_by}</td>
                        <td>Checked</td>
                        <td>${mr.pae_check_by}</td>
                        <td>Checked</td>
                        <td>${mr.plan_check_by}</td>
                         <td>Checked</td>
                        <td>${mr.pur_check_by}</td>
                      </tr>
                      <tr>
                        <td>Date</td>
                        <td> ${mr.request_date ? moment(mr.request_date).format("MM/DD/YYYY") : ""}</td>
                        <td>Date</td>
                        <td> ${mr.pae_check_date ? moment(mr.pae_check_date).format("MM/DD/YYYY") : ""}</td>
                        <td>Date</td>
                        <td> ${mr.plan_check_date ? moment(mr.plan_check_date).format("MM/DD/YYYY") : ""}</td>
                        <td>Date</td>
                        <td> ${mr.pur_check_date ? moment(mr.pur_check_date).format("MM/DD/YYYY") : ""}</td>
                      </tr>
                       <tr>
                        <td></td>
                        <td></td>
                        <td>Approved</td>
                        <td>${mr.pae_app_by}</td>
                        <td>Approved</td>
                        <td>${mr.plan_app_by}</td>
                         <td>Approved</td>
                        <td>${mr.pur_app_by}</td>
                      </tr>
                       <tr>
                        <td></td>
                        <td></td>
                        <td>Date</td>
                        <td> ${mr.pae_check_date ? moment(mr.pae_app_date).format("MM/DD/YYYY") : ""}</td>
                        <td>Date</td>
                        <td> ${mr.plan_check_date ? moment(mr.plan_app_date).format("MM/DD/YYYY") : ""}</td>
                         <td>Date</td>
                        <td> ${mr.pur_check_date ? moment(mr.pur_app_date).format("MM/DD/YYYY") : ""}</td>
                      </tr>
                  </tbody>
                </table>
                ${isShowPermit ? isPAETurn ? permitContentForPAE : OtherDeptCheck : ""}
              </div>
            </div>
          </div>
        </div>
    
    `)



    const modalMassage = new bootstrap.Modal('#showModalMRDetail', {
      keyboard: false
    })
    modalMassage.show()
    selectjs()
  }


  selectAll(checkboxName: string, isSelectAll: boolean) {
    if (isSelectAll) {
      $(`input[name=${checkboxName}]:checkbox`).each(function (this: HTMLInputElement) {
        $(this).prop('checked', true);
      });
    } else {
      $(`input[name=${checkboxName}]:checkbox`).each(function (this: HTMLInputElement) {
        $(this).prop('checked', false);
      });
    }
  };

  getSelectedID(checkboxName: string) {
    var selectedIDs: any = [];
    $(`input[name=${checkboxName}]:checkbox:checked`).each(function (this: HTMLElement) {
      selectedIDs.push($(this).val());
    });
    return selectedIDs
  }


  async showModalDieDetail(die_ids: number[], die_role_id: number, isOpenModal: boolean) {

    $('.area_render_die_detail').empty()
    let _that = this
    let allMid_PS: any = [];
    let capacity: any = [];
    for (let i = 0; i < die_ids.length; i++) {
      let dieInfor = await _that.APIservices.getDieDetail(die_ids[i]).toPromise()
      allMid_PS.push(dieInfor?.mid_ps)
      _that.renderModalDieDetail(dieInfor, die_role_id)
      let elementRenderChartScore = `#renderChartScoreForID_${dieInfor?.dieInfo.die_id}`
      _that.chartService.renderChartDieScoreByID(elementRenderChartScore, dieInfor?.dieScore)
    }

    // render Chart
    this.chartService.renderChartDieDetail(allMid_PS, capacity)

    // Open modal
    if (isOpenModal) {
      const modalMassage = new bootstrap.Modal('#modal_show_die_detail', {
        keyboard: true
      })
      modalMassage.show()
    }



  }

  async renderModalDieDetail(dieInfor: any, die_role_id: number) {
    let configShowDieInfo = [
      { isAdminEdit: true, isEdit: false, name: 'texture_type', valueType: 'text', displayName: 'Texture Type', isHiden: 0, group: '2.DSUM', order: 1 },
      { isAdminEdit: true, isEdit: false, name: 'is_new_master_gear', valueType: 'boolan', displayName: 'Is New Master Gear', isHiden: 0, group: '2.DSUM', order: 2 },
      { isAdminEdit: true, isEdit: false, name: 'core_cav_material', valueType: 'text', displayName: 'Core Cav Material', isHiden: 0, group: '2.DSUM', order: 3 },
      { isAdminEdit: true, isEdit: false, name: 'slider_material', valueType: 'text', displayName: 'Slider Material', isHiden: 0, group: '2.DSUM', order: 4 },
      { isAdminEdit: true, isEdit: false, name: 'lifter_material', valueType: 'text', displayName: 'Lifter Material', isHiden: 0, group: '2.DSUM', order: 5 },
      { isAdminEdit: true, isEdit: false, name: 'gate_type', valueType: 'text', displayName: 'Gate Type', isHiden: 0, group: '2.DSUM', order: 6 },
      { isAdminEdit: true, isEdit: false, name: 'hot_runner', valueType: 'text', displayName: 'Hot Runner', isHiden: 0, group: '2.DSUM', order: 7 },
      { isAdminEdit: true, isEdit: false, name: 'is_stacking', valueType: 'boolan', displayName: 'Is Stacking', isHiden: 0, group: '2.DSUM', order: 8 },
      { isAdminEdit: true, isEdit: false, name: 'is_shaft_kashime', valueType: 'boolan', displayName: 'Is Shaft Kashime', isHiden: 0, group: '2.DSUM', order: 9 },
      { isAdminEdit: true, isEdit: false, name: 'is_burring_kashime', valueType: 'boolan', displayName: 'Is Burring Kashime', isHiden: 0, group: '2.DSUM', order: 10 },
      { isAdminEdit: true, isEdit: false, name: 'spm_progressive', valueType: 'boolan', displayName: 'Spm Progressive', isHiden: 0, group: '2.DSUM', order: 11 },
      { isAdminEdit: true, isEdit: false, name: 'spm_single', valueType: 'boolan', displayName: 'Spm Single', isHiden: 0, group: '2.DSUM', order: 12 },
      { isAdminEdit: true, isEdit: false, name: 'pxno_of_state', valueType: 'number', displayName: 'No Of State', isHiden: 0, group: '2.DSUM', order: 13 },
      { isAdminEdit: true, isEdit: false, name: 'puch_holder', valueType: 'text', displayName: 'Puch Holder', isHiden: 0, group: '2.DSUM', order: 14 },
      { isAdminEdit: true, isEdit: false, name: 'punch_backing_plate', valueType: 'text', displayName: 'Punch Backing Plate', isHiden: 0, group: '2.DSUM', order: 15 },
      { isAdminEdit: true, isEdit: false, name: 'punch_plate', valueType: 'text', displayName: 'Punch Plate', isHiden: 0, group: '2.DSUM', order: 16 },
      { isAdminEdit: true, isEdit: false, name: 'punch', valueType: 'text', displayName: 'Punch', isHiden: 0, group: '2.DSUM', order: 17 },
      { isAdminEdit: true, isEdit: false, name: 'insert_block', valueType: 'text', displayName: 'Insert Block', isHiden: 0, group: '2.DSUM', order: 18 },
      { isAdminEdit: true, isEdit: false, name: 'stripper_backing_plate', valueType: 'text', displayName: 'Stripper Backing Plate', isHiden: 0, group: '2.DSUM', order: 19 },
      { isAdminEdit: true, isEdit: false, name: 'stripper_plate', valueType: 'text', displayName: 'Stripper Plate', isHiden: 0, group: '2.DSUM', order: 20 },
      { isAdminEdit: true, isEdit: false, name: 'die_plate', valueType: 'text', displayName: 'Die Plate', isHiden: 0, group: '2.DSUM', order: 21 },
      { isAdminEdit: true, isEdit: false, name: 'die_backing_plate', valueType: 'text', displayName: 'Die Backing Plate', isHiden: 0, group: '2.DSUM', order: 22 },
      { isAdminEdit: true, isEdit: false, name: 'die_holder', valueType: 'text', displayName: 'Die Holder', isHiden: 0, group: '2.DSUM', order: 23 },
      { isAdminEdit: true, isEdit: false, name: 'geta_plate', valueType: 'text', displayName: 'Geta Plate', isHiden: 0, group: '2.DSUM', order: 24 },
      { isAdminEdit: true, isEdit: false, name: 'sub_plate', valueType: 'text', displayName: 'Sub Plate', isHiden: 0, group: '2.DSUM', order: 25 },
      { isAdminEdit: true, isEdit: false, name: 'no_of_q', valueType: 'number', displayName: 'No Of Q', isHiden: 0, group: '2.DSUM', order: 25 },
      { isAdminEdit: true, isEdit: false, name: 'no_of_c', valueType: 'number', displayName: 'No Of C', isHiden: 0, group: '2.DSUM', order: 26 },
      { isAdminEdit: true, isEdit: false, name: 'no_of_d', valueType: 'number', displayName: 'No Of D', isHiden: 0, group: '2.DSUM', order: 27 },
      { isAdminEdit: true, isEdit: false, name: 'po_date', valueType: 'date', displayName: 'Po Date', isHiden: 0, group: '2.DSUM', order: 28 },
      { isAdminEdit: true, isEdit: false, name: 'lead_time_make_die', valueType: 'text', displayName: 'Lead Time Make Die', isHiden: 0, group: '2.DSUM', order: 29 },
      { isAdminEdit: true, isEdit: false, name: 'target_ok_date', valueType: 'date', displayName: 'Target Ok Date', isHiden: 0, group: '2.DSUM', order: 30 },
      { isAdminEdit: true, isEdit: false, name: 'is_official', valueType: 'boolan', displayName: 'Is Official', isHiden: 0, group: '2.DSUM', order: 31 },
      { isAdminEdit: true, isEdit: true, name: 't0_plan', valueType: 'date', displayName: 'T0 Plan', isHiden: 0, group: '3.FA', order: 1 },
      { isAdminEdit: true, isEdit: true, name: 't0_actual', valueType: 'date', displayName: 'T0 Actual', isHiden: 0, group: '3.FA', order: 2 },
      { isAdminEdit: true, isEdit: true, name: 't0_result', valueType: 'text', displayName: 'T0 Result', isHiden: 0, group: '3.FA', order: 3 },
      { isAdminEdit: true, isEdit: true, name: 't0_solve_method', valueType: 'text', displayName: 'T0 Solve Method', isHiden: 0, group: '3.FA', order: 4 },
      { isAdminEdit: true, isEdit: true, name: 'prekk_plan', valueType: 'date', displayName: 'Prekk Plan', isHiden: 0, group: '3.FA', order: 5 },
      { isAdminEdit: true, isEdit: true, name: 'prekk_result', valueType: 'text', displayName: 'Prekk Result', isHiden: 0, group: '3.FA', order: 6 },
      { isAdminEdit: true, isEdit: true, name: 'texture_meeting_date', valueType: 'date', displayName: 'Texture Meeting Date', isHiden: 0, group: '3.FA', order: 7 },
      { isAdminEdit: true, isEdit: true, name: 'texture_go_date', valueType: 'date', displayName: 'Texture Go Date', isHiden: 0, group: '3.FA', order: 8 },
      { isAdminEdit: true, isEdit: true, name: 's0_plan', valueType: 'date', displayName: 'S0 Plan', isHiden: 0, group: '3.FA', order: 9 },
      { isAdminEdit: true, isEdit: true, name: 's0_result', valueType: 'text', displayName: 'S0 Result', isHiden: 0, group: '3.FA', order: 10 },
      { isAdminEdit: true, isEdit: true, name: 's0_solve_method', valueType: 'text', displayName: 'S0 Solve Method', isHiden: 0, group: '3.FA', order: 11 },
      { isAdminEdit: true, isEdit: true, name: 'texture_app_date', valueType: 'date', displayName: 'Texture App Date', isHiden: 0, group: '3.FA', order: 12 },
      { isAdminEdit: true, isEdit: true, name: 'texture_jp_hp_app_result', valueType: 'text', displayName: 'Texture Jp Hp App Result', isHiden: 0, group: '3.FA', order: 13 },
      { isAdminEdit: true, isEdit: true, name: 'texture_note', valueType: 'text', displayName: 'Texture Note', isHiden: 0, group: '3.FA', order: 14 },
      { isAdminEdit: true, isEdit: false, name: 'fa_sub_time', valueType: 'number', displayName: 'Fa Sub Time', isHiden: 0, group: '3.FA', order: 15 },
      { isAdminEdit: true, isEdit: true, name: 'fa_plan', valueType: 'date', displayName: 'FA Plan', isHiden: 0, group: '3.FA', order: 16 },
      { isAdminEdit: true, isEdit: true, name: 'fa_result', valueType: 'text', displayName: 'FA Result', isHiden: 0, group: '3.FA', order: 17 },
      { isAdminEdit: true, isEdit: true, name: 'fa_result_date', valueType: 'date', displayName: 'FA Result Date', isHiden: 0, group: '3.FA', order: 18 },
      { isAdminEdit: true, isEdit: true, name: 'fa_problem', valueType: 'text', displayName: 'FA Problem', isHiden: 0, group: '3.FA', order: 19 },
      { isAdminEdit: true, isEdit: true, name: 'fa_action_improve', valueType: 'text', displayName: 'FA Action Improve', isHiden: 0, group: '3.FA', order: 20 },
      { isAdminEdit: true, isEdit: true, name: 'first_lot_date', valueType: 'date', displayName: 'First Lot Date', isHiden: 0, group: '3.FA', order: 21 },
      { isAdminEdit: true, isEdit: false, name: 'die_check_result_id', valueType: 'select', displayName: 'Check Die (lastest)', isHiden: 0, group: '3.FA', order: 22 },
      { isAdminEdit: false, isEdit: false, name: 'check_review_date', valueType: 'date', displayName: 'Check Die Date', isHiden: 0, group: '3.FA', order: 23 },
      { isAdminEdit: true, isEdit: false, name: 'die_id', valueType: 'number', displayName: 'Die Id', isHiden: 1, group: '1.Info', order: 1 },
      { isAdminEdit: true, isEdit: false, name: 'dieno', valueType: 'text', displayName: 'Die No', isHiden: 1, group: '1.Info', order: 2 },
      { isAdminEdit: true, isEdit: false, name: 'die_status_id', valueType: 'select', displayName: 'Status', isHiden: 0, group: '1.Info', order: 3 },
      { isAdminEdit: false, isEdit: false, name: 'fixed_asset_no', valueType: 'text', displayName: 'Fixed Asset No', isHiden: 0, group: '1.Info', order: 4 },
      { isAdminEdit: true, isEdit: false, name: 'jig_using', valueType: 'boolan', displayName: 'Jig Using', isHiden: 0, group: '1.Info', order: 5 },
      { isAdminEdit: false, isEdit: false, name: 'die_classify', valueType: 'text', displayName: 'Die Classify', isHiden: 0, group: '1.Info', order: 6 },
      { isAdminEdit: true, isEdit: false, name: 'texture', valueType: 'boolan', displayName: 'Texture', isHiden: 0, group: '1.Info', order: 7 },
      { isAdminEdit: false, isEdit: false, name: 'process', valueType: 'text', displayName: 'Process', isHiden: 0, group: '1.Info', order: 8 },
      { isAdminEdit: false, isEdit: false, name: 'model', valueType: 'number', displayName: 'Model Id', isHiden: 1, group: '1.Info', order: 9 },
      { isAdminEdit: true, isEdit: false, name: 'model_id', valueType: 'select', displayName: 'Model Name', isHiden: 0, group: '1.Info', order: 10 },
      { isAdminEdit: true, isEdit: false, name: 'supplier', valueType: 'number', displayName: 'Supplier Id', isHiden: 1, group: '1.Info', order: 11 },
      { isAdminEdit: true, isEdit: false, name: 'supplier_id', valueType: 'select', displayName: 'Supplier Code', isHiden: 0, group: '1.Info', order: 12 },
      { isAdminEdit: false, isEdit: false, name: 'supplier_name', valueType: 'text', displayName: 'Supplier Name', isHiden: 0, group: '1.Info', order: 13 },
      { isAdminEdit: true, isEdit: false, name: 'die_maker', valueType: 'text', displayName: 'Die Maker', isHiden: 0, group: '1.Info', order: 14 },
      { isAdminEdit: true, isEdit: false, name: 'mc_size', valueType: 'number', displayName: 'MC Size', isHiden: 0, group: '1.Info', order: 16 },
      { isAdminEdit: true, isEdit: false, name: 'cav_quantity', valueType: 'number', displayName: 'Cav Quantity', isHiden: 0, group: '1.Info', order: 17 },
      { isAdminEdit: true, isEdit: false, name: 'cycle_time_sec', valueType: 'number', displayName: 'Cycle Time(s)', isHiden: 0, group: '1.Info', order: 18 },
      { isAdminEdit: true, isEdit: false, name: 'cycle_time_targetasdsum', valueType: 'number', displayName: 'Cycle Time DSUM(s)', isHiden: 0, group: '1.Info', order: 19 },
      { isAdminEdit: true, isEdit: false, name: 'die_cost_usd', valueType: 'number', displayName: 'Die Cost USD', isHiden: 0, group: '1.Info', order: 20 },
      { isAdminEdit: true, isEdit: false, name: 'die_make_location', valueType: 'text', displayName: 'Die Make Location', isHiden: 0, group: '1.Info', order: 21 },
      { isAdminEdit: true, isEdit: false, name: 'special_spec', valueType: 'text', displayName: 'Special Spec', isHiden: 0, group: '1.Info', order: 22 },
      { isAdminEdit: true, isEdit: false, name: 'pxno_of_component', valueType: 'number', displayName: 'No Of Component', isHiden: 0, group: '1.Info', order: 23 },
      { isAdminEdit: true, isEdit: false, name: 'family_die_with', valueType: 'text', displayName: 'Family Die With', isHiden: 0, group: '1.Info', order: 24 },
      { isAdminEdit: true, isEdit: false, name: 'common_part_with', valueType: 'text', displayName: 'Common Part With', isHiden: 0, group: '1.Info', order: 25 },
      { isAdminEdit: true, isEdit: false, name: 'start_use', valueType: 'date', displayName: 'Start Use', isHiden: 0, group: '1.Info', order: 26 },
      { isAdminEdit: true, isEdit: false, name: 'die_warranty_short', valueType: 'number', displayName: 'Die Warranty Short', isHiden: 0, group: '1.Info', order: 27 },
      { isAdminEdit: true, isEdit: false, name: 'warranty_shot_as_dsum', valueType: 'number', displayName: 'Warranty Shot As Dsum', isHiden: 0, group: '1.Info', order: 28 },
      { isAdminEdit: true, isEdit: false, name: 'pae_target_short', valueType: 'number', displayName: 'Pae Target Short', isHiden: 0, group: '1.Info', order: 29 },
      { isAdminEdit: true, isEdit: false, name: 'short', valueType: 'number', displayName: 'Short', isHiden: 0, group: '1.Info', order: 30 },
      { isAdminEdit: true, isEdit: false, name: 'record_date', valueType: 'date', displayName: 'Record Date', isHiden: 0, group: '1.Info', order: 31 },
      { isAdminEdit: true, isEdit: false, name: 'inventory_status', valueType: 'text', displayName: 'Inventory Status', isHiden: 0, group: '1.Info', order: 32 },
      { isAdminEdit: true, isEdit: false, name: 'remark_die_status_using', valueType: 'text', displayName: 'Remark Die Status Using', isHiden: 0, group: '1.Info', order: 33 },
      { isAdminEdit: true, isEdit: false, name: 'stop_date', valueType: 'date', displayName: 'Stop Date', isHiden: 0, group: '1.Info', order: 34 },
      { isAdminEdit: true, isEdit: false, name: 'supplier_proposal', valueType: 'boolan', displayName: 'Supplier Proposal', isHiden: 0, group: '1.Info', order: 35 },
      { isAdminEdit: true, isEdit: false, name: 'reason_proposal', valueType: 'text', displayName: 'Reason Proposal', isHiden: 0, group: '1.Info', order: 36 },
      { isAdminEdit: true, isEdit: false, name: 'genaral_information', valueType: 'text', displayName: 'Genaral Information', isHiden: 1, group: '1.Info', order: 37 },
      { isAdminEdit: true, isEdit: false, name: 'belong', valueType: 'text', displayName: 'Belong', isHiden: 0, group: '1.Info', order: 38 },
      { isAdminEdit: true, isEdit: false, name: 'progress', valueType: 'text', displayName: 'Progress', isHiden: 0, group: '1.Info', order: 1 },
    ]
    configShowDieInfo = configShowDieInfo.sort(this.fieldSorter(["group", "order"]))

    let dieInfoContent = "";
    let groupInfoContent = ""
    let groupCommonContent = ""
    let groupTPIContent = ""
    let groupDSUMContent = ""
    let groupMRContent = ""
    let groupDTFContent = ""
    let groupDISPOSEContent = ""
    //start basic infor
    let iconEdit = `
          <span class="p-2 cursor text-wrap edit_die_info" title="click to Edit">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil" viewBox="0 0 16 16">
              <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325"/>
            </svg> 
          </span>
        `

    let iconDisabledEdit = `
          <span class="p-2 disabled text-wrap">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2" viewBox="0 0 16 16">
              <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0"/>
            </svg>
          </span>
        `
    configShowDieInfo.forEach((e: any) => {

      for (const key in dieInfor?.dieInfo) {

        if (e.name == key && e.isHiden == 0) {
          groupInfoContent += `<li data-name="${e.name}" data-currentVal="${dieInfor?.dieInfo[key]}" data-die_id="${dieInfor?.dieInfo.die_id}" data-valueType="${e.valueType}" data-displayName="${e.displayName}" class="list-group-item p-1">
          ${e.isAdminEdit && die_role_id == 6 ? iconEdit : (e.isEdit && die_role_id >= 3 ? iconEdit : iconDisabledEdit)}
          ${e.displayName} :
          <span class="text-content">
              ${e.valueType == "date" ? moment(dieInfor?.dieInfo[key]).format("yyyy/MM/DD") : (e.valueType == "number" ? new Intl.NumberFormat().format(dieInfor?.dieInfo[key]) : dieInfor?.dieInfo[key])}
          </span>
          </li>`
        }
      };
    })

    groupInfoContent = `
            <li  class="list-group-item active sticky-top mt-0 ">
                ${dieInfor?.dieInfo.dieno} 
                <div class="die_detail_show_die_progress" data-die_id="${dieInfor?.dieInfo.die_id}">
                  ${dieInfor?.dieInfo.progress}
                </div>
            </li>
            <li  class="list-group-item" data-name="genaral_information" data-currentVal="${dieInfor?.dieInfo['genaral_information']}" data-die_id="${dieInfor?.dieInfo.die_id}" data-valueType="text">
                ${die_role_id >= 3 ? iconEdit : iconDisabledEdit} Genaral Information 
                <span class="nice-form-group mt-1">
                  <textarea class="text-content" disabled rows="5">${dieInfor?.dieInfo.genaral_information}</textarea>
                </span>
            </li>
            <li class="list-group-item">
              <div class="card">
                <div class="card-body" id="renderChartScoreForID_${dieInfor?.dieInfo.die_id}" style="width:100%; height:250px">

                </div>
              </div>
            </li>
           ${groupInfoContent}
    `
    //End basic infor

    //Start Common die
    for (const common of dieInfor?.common) {
      groupCommonContent += `
      <li class="list-group-item name="" value=""">
        ${common.part_no} | ${common.part_name} | ${common.material} | ${common.is_common_part ? "Common |" : ""}  ${common.is_family_die ? "Family" : ""}
      </li>`
    };
    groupCommonContent = `
        <li class="list-group-item active sticky-top">
          Common/Family Die
           <span  class='text-warning cursor add_common ${die_role_id == 6 ? '': 'd-none'}'  data-die_id="${dieInfor?.dieInfo.die_id}" >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-caret-right-fill" viewBox="0 0 16 16">
              <path d="m12.14 8.753-5.482 4.796c-.646.566-1.658.106-1.658-.753V3.204a1 1 0 0 1 1.659-.753l5.48 4.796a1 1 0 0 1 0 1.506z"/>
            </svg>
           Add Common</span>
        </li> 
        ${groupCommonContent}
    `
    //End Common Die

    // Start TPI
    for (const tpi of dieInfor?.tpi) {
      groupTPIContent += `
      <li class="list-group-item name="" value=""">
        ${tpi.tpi_no} | ${tpi.trouble_name} | ${tpi.status_type} | ${tpi.po_code} 
      </li>`
    };
    groupTPIContent = `
        <li class="list-group-item active sticky-top">TPI</li> 
        ${groupTPIContent}
    `
    //END TPI

    //Start DSUM
    for (const dfm of dieInfor?.dsum) {
      groupDSUMContent += `
      <li class="list-group-item name="" value=""">
        ${dfm.dsum_no ? dfm.dsum_no : "DSUM"} | ${dfm.status} 
      </li>`
    };
    groupDSUMContent = `
        <li class="list-group-item active sticky-top">DSUM</li> 
        ${groupDSUMContent}
    `
    //END DSUM

    //start MR
    for (const mr of dieInfor?.mrs) {
      groupMRContent += `
      <li class="list-group-item name="" value=""">
        ${mr.mr_no}| ${mr.mr_type}| ${mr.status}| ${new Intl.NumberFormat().format(mr.cost)}$
      </li>`
    };
    groupMRContent = `
        <li class="list-group-item active sticky-top">MR</li> 
        ${groupMRContent}
    `

    //End MR

    //Start DTF
    for (const dtf of dieInfor?.transfers) {
      groupDTFContent += `
      <li class="list-group-item name="" value=""">
        ${dtf.dtf_no} | ${dtf.status}| From  ${dtf.current_location} To ${dtf.new_location} at ${new Intl.NumberFormat().format(dtf.shot)}shots
      </li>`
    };
    groupDTFContent = `
        <li class="list-group-item active sticky-top">DIE TRANSFER(DTF)</li> 
        ${groupDTFContent}
    `
    //END DTF

    //Start Disposal
    for (const dis of dieInfor?.disposal) {
      groupDISPOSEContent += `
      <li class="list-group-item name="" value=""">
        ${dis.dis_no} | ${dis.decision}|  ${dis.physical_dispose_date ? "Physical " + moment(dis.physical_dispose_date).format("YYYY/MM/DD") : ""}
      </li>`
    };
    groupDISPOSEContent = `
        <li class="list-group-item active sticky-top">Disposal Die</li> 
        ${groupDISPOSEContent}
    `
    //End Disposal


    dieInfoContent = groupInfoContent + groupCommonContent + groupTPIContent + groupDSUMContent + groupMRContent + groupDTFContent + groupDISPOSEContent
    dieInfoContent = `
    <ul style="font-size:0.75rem" class="card list-group list-group col-md-4 p-0 overflow-auto area_die_detail">
      ${dieInfoContent}
    </ul>`


    $('.area_render_die_detail').append(dieInfoContent)
    // CSS
    $('.area_die_detail').css({ 'max-height': $('.area_render_die_detail').parent().parent().height() - 30 })
  }

  debounce(func: any, timeout = 300) {

    let timer: any;
    return (...args: any) => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        func.apply(this, args);
      }, timeout);
    };
  }


















}