import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { Injectable } from '@angular/core';
import { AppAPIService } from '../API-Services/app-api.service';
import { MrComponent } from '../pages/mr/mr.component';
import moment from 'moment';
const apexChart = import('apexcharts');
@Injectable({
  providedIn: 'root'
})
export class ChartApexService {

  constructor(
    private APIservices: AppAPIService,

  ) { }

  chartDieOptions = {
    series: [],
    chart: {
      height: 250,
      type: 'area',
      stacked: true,
    },
    dataLabels: {
      enabled: false,
      enabledOnSeries: undefined,
      // formatter: function (val:any, opts:any) {
      //     return (val/1000).toFixed(0)
      // },
    },
    annotations: {
      points: [{
        x: `_${moment().format('YYYYMM')}`,
        seriesIndex: 0,
        label: {
          borderColor: '#775DD0',
          offsetY: 0,
          style: {
            color: '#fff',
            background: '#775DD0',
          },
          text: 'Now here!',
        }
      },
      {
        x: `_${moment().format('YYYYMM')}`,
        y: 15000,
        seriesIndex: 0,
        label: {
          borderColor: '#775DD0',
          offsetY: 0,
          style: {
            color: '#fff',
            background: '#775DD0',
          },
          text: 'cap',
        }
      },
      {
        x: `_${moment().format('YYYYMM')}`,
        y: 10,
        seriesIndex: 0,
        label: {
          borderColor: '#775DD0',
          offsetY: 0,
          style: {
            color: '#fff',
            background: '#775DD0',
          },
          text: 'Die score',
        }
      }
      ]
    },
    stroke: {
      show: true,
      width: 3,
      curve: 'smooth'
    },
    plotOptions: {
      bar: {
        columnWidth: '50%'
      }
    },

    fill: {
      opacity: [0.85, 0.25, 1],
      gradient: {
        inverseColors: false,
        shade: 'light',
        type: "vertical",
        opacityFrom: 0.85,
        opacityTo: 0.55,
        stops: [0, 100, 100, 100]
      },
    },
    labels: [],
    markers: {
      size: 0
    },
    xaxis: {
      type: 'date'
    },
    yaxis: {
      title: {
        text: 'pcs',
      },
      labels: {
        /**
        * Allows users to apply a custom formatter function to yaxis labels.
        *
        * @param { String } value - The generated value of the y-axis tick
        * @param { index } index of the tick / currently executing iteration in yaxis labels array
        */
        // formatter: function(val:any, index:any) {
        //   return (val/1000).toFixed(0);
        // }
      }

    },
    tooltip: {
      shared: true,
      intersect: false,

    },
    legend: {
      show: true,
      showForSingleSeries: true,
      position: 'top',
    }
  };


  async renderChartDieDetail(ps_mid: any[], capacity: any[]) {

    let series: any = []
    let label: any = []
    ps_mid = ps_mid.flat()
    ps_mid = [...new Map(ps_mid.map(item => [item['partno'], item])).values()]


    ps_mid.forEach((e: any) => {
      let name = '[PS]' + e.partno.substring(0, 8)
      delete e.partno
      let data = Object.values(e);
      label = Object.keys(e);
      let dataSerie: any = {
        name: name,
        type: 'area',
        data: data
      }
      series.push(dataSerie)
    })


    //series.push(d)




    var options = this.chartDieOptions
    options.series = series

    options.labels = label

    $('#render_chart_die_detail').empty()
    var chart = new ApexCharts(document.querySelector("#render_chart_die_detail"), options);
    chart.render();
  }

  chartDieScoreOptions =
    {
      series: [],
      labels: [],
      chart: {
        height: 200,
        type: 'radar',
      },
      dataLabels: {
        enabled: true
      },
      plotOptions: {
        radar: {
          size: 80,
          polygons: {
            strokeColors: '#e9e9e9',
            fill: {
              colors: ['#f8f8f8', '#fff']
            }
          }
        }
      },
      title: {
        text: 'Die Risk Score'
      },
      colors: ['#FF4560'],
      markers: {
        size: 4,
        colors: ['#fff'],
        strokeColor: '#FF4560',
        strokeWidth: 2,
      },
      tooltip: {
        y: {
          // formatter: function(val) {
          //   return val
          // }
        }
      },
      xaxis: {
        categories: []
      },
      yaxis: {
        labels: {
          // formatter: function(val, i) {
          //   if (i % 2 === 0) {
          //     return val
          //   } else {
          //     return ''
          //   }
          // }
        }
      }
    };




  async renderChartDieScoreByID(elementArea: string, dataDieScore: any[]) {
    let series: any = []
    let dataseries: any = {
      name: 'Remain Score',
      data: [0, 0, 0, 0, 0, 0, 0, 0]
    }
    let data: any = []
    let labels: any = [];
    let warning: any = [];
    let totalRemainScore = 0;
    dataDieScore.sort((factor: any) => factor.factor_id).forEach((factor: any) => {
      if (factor.subtract_score === '') {
        warning.push(factor.condition_name)
      }
      let remainScore = parseInt(factor.base_score + factor.subtract_score)
      totalRemainScore += remainScore
      let labelName = factor.fator
      data.push(remainScore);
      labels.push(labelName);
    })
    if (warning.length > 0) {
      $(elementArea).empty().append(`<div class='fs-3'>GENARATE DIE SCORE ERROR!</div> <div>${warning.join('<br/>')}</div>`)
      return
    }
    dataseries.data = data
    series.push(dataseries)
    
    let option = this.chartDieScoreOptions
    option.series = series
    option.labels = labels;
    option.title.text = `Die Score: ${totalRemainScore}`
    $(elementArea).empty()
    var chart = new ApexCharts(document.querySelector(elementArea), option);
    chart.render();
  }

}
