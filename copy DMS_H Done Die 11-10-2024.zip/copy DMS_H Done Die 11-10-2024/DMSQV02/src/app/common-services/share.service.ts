import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ShareService {

  constructor() { }
  private callFunctionSource = new Subject<void>();
  callFunction$ = this.callFunctionSource.asObservable();

  triggerCallFunction() {
    this.callFunctionSource.next();
  }
  callRenderTableMR(){
    this.callFunctionSource.next();
  }
}
