import { Component, AfterViewInit, OnDestroy, Renderer2, ElementRef, OnInit, ViewChild, asNativeElements } from '@angular/core';
import { Config } from 'datatables.net';
import { AuthenService } from '../../API-Services/authen.service';
import { Router } from '@angular/router';
import { DOMServiceService } from '../../common-services/dom-service.service';
import { AppAPIService } from '../../API-Services/app-api.service';
import { Subject } from 'rxjs';

import moment from 'moment';
const apexChart = import('apexcharts');
declare var $: any;
declare var bootstrap: any;
declare var Validator: any;
declare var DataTable: any;

@Component({
  selector: 'app-dies',
  templateUrl: './dies.component.html',
  styleUrl: './dies.component.css'
})
export class DiesComponent {
  private eventListenerClick!: () => void;
  private eventListenerResize!: () => void;
  private eventListenerChange!: () => void;

  constructor(
    private authen: AuthenService,
    private router: Router,
    private DOMService: DOMServiceService,
    private APIservices: AppAPIService,
    private renderer: Renderer2,


  ) { }

  dept: string = JSON.parse(localStorage.getItem('user') ?? '')[0].dept_name
  userName: string = JSON.parse(localStorage.getItem('user') ?? '')[0].user_name
  die_role_id: number = 0;
  admin = false;
  searchParameter: any = {
    page: 1,
    search: '',
  }

  dtOptions: any = {
    serverSide: false,
    paging: false,
    ordering: false,
    select: true, keys: true,
    scrollY: '300',
    scrollX: true,
    fixedColumns: {
      left: 4,
      right: 0
    },
    rowId: 'die_id',
    searching: false,
    createdRow: (row: any, data: any, index: any) => {
      if (data.is_cancel || data.status.includes('Dispose')) {
        $(row).addClass('bg-secondary')
      } else {
        if (!data.is_official) {
          $(row).addClass('bg-warning-subtle');
          $(row).attr('title', 'This die not yet issue PO');
        } else {
          $(row).addClass('bg-light');
        }
      }

    },
    columns: [
      {
        title: `<label for='selectAll'>Select All </label><input class="selectAll" id='selectAll' type='checkbox'/>`,
        data: 'die_id',
        render:  (data: any, type: any, row: any) => {
          return `<input type='checkbox' value='${data}' name='row_die_id'/> 
                 <span data-die_id="${data}" class="admin_delete_die cursor text-danger ${this.die_role_id==6 ? "" : "d-none"}" title="Just delete die when you see that this die actualy dont exist"> &nbsp;&nbsp;
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                      <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z"/>
                      <path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z"/>
                    </svg>
                 </span>`
        }
      },
      {
        title: 'Classify',
        data: 'die_classify',
      },
      {
        title: 'Status',
        data: 'status',
        render: function (data: any, type: any, row: any) {
          return `<button style="min-width:150px" class="btn btn-sm btn-primary btn_show_modal_die_detail" data-die-id='${row.die_id}'>${data}</button>`
        }
      },
      {
        title: 'Progress',
        data: 'progress',
        render: function (data: any, type: any, row: any) {
          return `<span class="text-primary" >${data}</span>`
        }
      },
      {
        title: 'Die ID',
        data: 'dieno',
      },
      {
        title: 'Part No',
        data: 'part_no',
      },
      {
        title: 'Part Name',
        data: 'part_name',
      },

      {
        title: 'Supplier Code',
        data: 'supplier_code'
      },
      {
        title: 'Supplier',
        data: 'supplier_name'
      },
      {
        title: 'Model',
        data: 'model_name'
      },
      {
        title: 'Process Code',
        data: 'process'
      },
      {
        title: 'MC size',
        data: 'mc_size'
      },
      {
        title: 'Cav Qty',
        data: 'cav_quantity'
      },
      {
        title: 'Warranty(DSUM)',
        data: 'warranty_shot_as_dsum',
        render: function (data: any, type: any, row: any) {
          return data.toLocaleString('en-US');
        }
      },
      {
        title: 'Warranty(PO)',
        data: 'die_warranty_short',
        render: function (data: any, type: any, row: any) {
          return data.toLocaleString('en-US');
        }
      },
      {
        title: 'Short',
        data: 'short',
        render: function (data: any, type: any, row: any) {
          return data.toLocaleString('en-US');
        }
      },
      {
        title: 'Record Date',
        data: 'record_date',
        render: function (data: any, type: any, row: any) {
          return moment(data).format('YYYY/MM/DD') === 'Invalid date' ? "" : moment(data).format('YYYY/MM/DD')
        }
      },
      {
        title: 'Start use',
        data: 'start_use',
        render: function (data: any, type: any, row: any) {
          return moment(data).format('YYYY/MM/DD') === 'Invalid date' ? "" : moment(data).format('YYYY/MM/DD')
        }
      },
      {
        title: 'Stop Date',
        data: 'stop_date',
        render: function (data: any, type: any, row: any) {
          return moment(data).format('YYYY/MM/DD') === 'Invalid date' ? "" : moment(data).format('YYYY/MM/DD')
        }
      },

    ]
  };
  dtTrigger: Subject<any> = new Subject();

  ngOnInit(): void {
    this.authen.checkLoginAndHandle()
    this.die_role_id = this.authen.getRoleForFucntion('die_role_id')
    this.renderChartDie()
    let _that = this
    // start render
    //render search areas
    this.createModelOptionElement()
    this.createSupplierListOptionElement()
    this.createProcessCodeOptionElement()
    //rendertable
    this.renderTable(this.searchParameter)
    // Handle sự kiện click ngoài angular
    this.eventListenerClick = this.renderer.listen(document, "click", function (e) {
      //trường hợp user click vào page
      // => add page vào object searchParameter => render lại table
      let page = $(e.target).attr('data-page')
      if (page) {
        let isnewpage = _that.searchParameter.page != page
        if (isnewpage) {
          _that.searchParameter.page = page
          _that.renderTable(_that.searchParameter)
        }
      }

      //trường hợp user click vào Downloard MR form
      let isClickDownloadMR = $(e.target).hasClass('download-mr')
      if (isClickDownloadMR) {
        let mr_id = $(e.target).attr('data-mr-id')
        _that.downloadMRform(mr_id)
      }

      //trường hợp user click vào Show MR detail
      let isClickShowDie = $(e.target).hasClass('btn_show_modal_die_detail')
      if (isClickShowDie) {
        let die_id = $(e.target).attr('data-die-id')
        _that.showDieDetail(die_id)
      }


      //trường hợp user click vào selectAll
      let isClickSelectAll = $(e.target).hasClass('selectAll')
      if (isClickSelectAll) {

        let isSelectAll = $(e.target).prop('checked')
        _that.selectAll(isSelectAll)
      }

      //trường hợp user click vào edit_die_info
      let isClickEditDieInfor = $(e.target).closest('.edit_die_info').hasClass('edit_die_info')
      if (isClickEditDieInfor) {
        let parent = $(e.target).closest('.edit_die_info').parent()
        let displayName = $(parent).attr('data-displayName')
        let name = $(parent).attr('data-name')
        let currentVal = $(parent).attr('data-currentVal')
        let dieID = $(parent).attr('data-die_id')
        let valueType = $(parent).attr('data-valueType')
        $('#form_edit_die_info input[name=die_id]').val(dieID)
        $('#form_edit_die_info input[name=currentValue]').val(currentVal)
        $('#form_edit_die_info input[name=name]').val(name)
        let elementForNewValue = ''
        if (valueType == 'boolan') {
          elementForNewValue = `
              <label>New Value</label>
              <select name="newValue">
                <option value="">---</option>
                <option value="Y">YES</option>
                <option value="N">NO</option>
              </select>
          `
        }

        if (['text', 'date', 'number'].includes(valueType)) {
          elementForNewValue = `
            <label>New Value</label>
            <input name="newValue" type="${valueType}"  value="" />
          `
        }

        if (valueType == "select") {
          if (name.includes('model')) {
            elementForNewValue = `
              <label>New Value</label>
              <select name="newValue" data-field="model_id" class="selectjs">
              </select>
          `
            _that.createModelOptionElement()
          }

          if (name.includes('supplier')) {
            elementForNewValue = `
              <label>New Value</label>
              <select name="newValue" data-field="supplier_id" class="selectjs">
              </select>
          `
            _that.createSupplierListOptionElement()
          }

          if (name.includes('status')) {
            elementForNewValue = `
              <label>New Value</label>
              <select name="newValue" data-field="die_status_id" class="selectjs">
              </select>
          `
            _that.createDieStatusCategoryOptionElement()
          }

          if (name.includes('die_check_result')) {
            elementForNewValue = `
              <label>New Value</label>
              <select name="newValue" data-field="die_check_result_id">
              </select>
              <input class="mt-1" type="file" name="fileDieCheckReport" placeholder="Die Report(if any)">

          `
            _that.createDieCheckResultCategoryOptionElement()
          }
        }


        $('#form_edit_die_info .renderElementNewValue').empty().append(elementForNewValue)
        $('#edit_for_display_name').empty().append(displayName)
        // Open modal


        const modalMassage = new bootstrap.Modal('#modal_edit_die_info', {
          keyboard: true
        })
        modalMassage.show()

      }

      // click vao add common die
      let isClickAddCommonDie = $(e.target).hasClass('add_common')
      if (isClickAddCommonDie) {
        let die_id = $(e.target).attr('data-die_id')
        _that.renderModalAddCommon(die_id, true)

      }

      //admin Click delete common die
      let isClickDeleteCommonDie = $(e.target).closest('.delete_common_die').hasClass('delete_common_die')
      if(isClickDeleteCommonDie){
        let resultComfirm = confirm("Are you sure to delete common/family die relationship? After delete, if you want to recover, let add new")
        if(!resultComfirm){
          return
        }
        let die_id = $(e.target).closest('.delete_common_die').attr('data-die_id')
        let data = {
          isDeleteCommon: true,
          common_id : $(e.target).closest('.delete_common_die').attr('data-common_id')
        }
        let result = _that.APIservices.add_edit_deleteCommon(data).subscribe(res => {
          if (res.status == false) {
            _that.DOMService.showAlertMassage(res.msg, false)
          } else{
            _that.renderModalAddCommon(die_id, false)
          }
        })

      }

      // admin delete die
      let isClickDeleteDie = $(e.target).closest('.admin_delete_die').hasClass('admin_delete_die')
      if(isClickDeleteDie){
        let resultConfirm = confirm("Are you sure to delete this die?. After delete you will not see all common/family of this die also.")
        if(!resultConfirm){
          return
        }
        let data = {
          isDeleteDie : true,
          die_id : $(e.target).closest('.admin_delete_die').attr('data-die_id')
        }
        let result = _that.APIservices.add_edit_deleteCommon(data).subscribe(res => {
          if (res.status == false) {
            _that.DOMService.showAlertMassage(res.msg, false)
          } else{
            // remove khoi table
            $(`#${data.die_id}`).hide()
          }
        })
      }
    })


    this.eventListenerChange = this.renderer.listen(document, "change", function (e) {
      //truonh hop user click vao detail_render_search_result
      let isSearchPartResult = $(e.target).hasClass('detail_search_result_die_id')
      if (isSearchPartResult) {
        let die_ids = _that.DOMService.getSelectedID('detail_search_result_die_id')
        _that.DOMService.showModalDieDetail(die_ids, _that.die_role_id, false)

      }

      // use change die common relationship is_common or is_family
      let isChangeCommonRelation = $(e.target).hasClass('edit_common')
      if (isChangeCommonRelation) {
        let common_id = $(e.target).attr('data-common_id')
        let name = $(e.target).attr('name')
        let isChecked = $(e.target).prop('checked')
        let data = {
          common_id: common_id,
          [name]: isChecked
        }
        let result = _that.APIservices.add_edit_deleteCommon(data).subscribe(res => {
          if (res.status == false) {
            _that.DOMService.showAlertMassage(res.msg, false)
          }
        })
      }

    })

  }



  ngOnDestroy() {
    if (this.eventListenerClick) {
      this.eventListenerClick();
    }
    if (this.eventListenerChange) {
      this.eventListenerChange();
    }
  }

  async renderTable(searchParameter: any) {
    this.DOMService.onloading('.btn_search')
    let _that = this
    this.dtOptions.destroy = true,
      this.dtOptions.processing = true;
    let dataResult = await this.APIservices.getDieList(searchParameter).toPromise()
    if (dataResult?.status == false) {
      this.DOMService.showAlertMassage(dataResult.msg, false)
      return
    }
    this.dtOptions.data = dataResult?.data
    this.DOMService.pagination(dataResult?.page, dataResult?.pageSize, dataResult?.recordsTotal, '.render_paganation')
    this.dtTrigger.next(null)
    _that.DOMService.onloaded('.btn_search')
  }

  async createModelOptionElement() {
    let modelList = await this.APIservices.getModelList().toPromise()
    let result = this.DOMService.createOptionElement(modelList?.data, ["model_name"], "model_id", "")
    this.DOMService.appendToElement("select[name=model_id]", result)
    this.DOMService.appendToElement("select[data-field=model_id]", result)

  }

  async createSupplierListOptionElement() {
    let suppliers = await this.APIservices.getSupplierList().toPromise()
    let result = this.DOMService.createOptionElement(suppliers?.data, ["supplier_code", 'supplier_name'], "supplier_id", "")
    this.DOMService.appendToElement("select[name=supplier_id]", result)
    this.DOMService.appendToElement("select[data-field=supplier_id]", result)
  }

  async createDieStatusCategoryOptionElement() {
    let dieStatusCategory = await this.APIservices.getDieStatusCategory().toPromise()
    let result = this.DOMService.createOptionElement(dieStatusCategory?.data, ["type"], "die_status_id", "")
    this.DOMService.appendToElement("select[data-field=die_status_id]", result)
  }

  async createDieCheckResultCategoryOptionElement() {
    let dieCheckResultCategory = await this.APIservices.getDieCheckResultCategory().toPromise()
    let result = this.DOMService.createOptionElement(dieCheckResultCategory?.data, ["die_check_result"], "die_check_result_id", "")
    this.DOMService.appendToElement("select[data-field=die_check_result_id]", result)
  }



  async createProcessCodeOptionElement() {
    let listProcessCode = await this.APIservices.getListProcessCode().toPromise()
    let result = this.DOMService.createOptionElement(listProcessCode?.data, ["type"], "proces_id", "")
    this.DOMService.appendToElement("select[name=process_id]", result)
  }

  searchDie() {
    let _that = this
    Validator({
      form: '#form_Search',
      formGroupSelector: '.nice-form-group',
      rules: [

      ],
      onSubmit: async function (data: any) {
        _that.searchParameter = { ..._that.searchParameter, ...data }
        _that.renderTable(data)
      }
    })
  }

  async searchPart() {
    $('.detail_render_search_result').empty()
    let part = $('#searchPart').val()
    let searchResult = await this.APIservices.searchPartNo({ search: part }).toPromise()
    let resultContent = ''
    searchResult?.data.forEach((e: any) => {
      resultContent += `
        <li class="list-group-item">
            <label class="nice-form-group mt-1">
                <input type="checkbox" id="${e.die_id}" class="detail_search_result_die_id" name="detail_search_result_die_id" value="${e.die_id}" />
                <label class="cursor text-primary fw-bold" for="${e.die_id}"> ${e.dieno} [${e.status}]</label>
            </label>
        </li>     
      
      `
      $('.detail_render_search_result').empty().append(`
          <ul class="list-group">
            ${resultContent}
          </ul>
      `)
    })



  }

  showModelAddNewDie() {
    const modalMassage = new bootstrap.Modal('#modal_AddNewDie', {
      keyboard: true
    })
    modalMassage.show()
  }

  AddNewDieByExcel() {
    alert('add die by EXCEL')
  }

  addNewDie() {
    let _that = this

    Validator({
      form: '#form_add_new_die',
      formGroupSelector: '.nice-form-group',
      rules: [
        Validator.isRequired('input[name=part_no]'),
        //Validator.length('input[name=part_no]'),
        Validator.isRequired('input[name=die_code]'),
        // Validator.length('input[name=die_code]'),
        Validator.isRequired('select[name=process_id]'),
        Validator.isRequired('select[name=model_id]'),
        Validator.isRequired('select[name=supplier_id]'),
      ],
      onSubmit: async function (data: any) {
        _that.DOMService.onloading(".btn_submit_new_die")
        let result = await _that.APIservices.addNewDie(data).toPromise()
        if (result?.status) {
          $('#add_new_die_Warning').text(result.msg)
          $('#form_add_new_die')[0].reset()
        } else {
          $('#add_new_die_Warning').text(result?.msg)
        }
        _that.DOMService.onloaded(".btn_submit_new_die")
      }
    });
  }


  async handleInputFormIssueMR() {
    defaulInputDieNoProperty()
    let partNo = $('input[name=part_no]').val().trim().toUpperCase()
    let dim = $('input[name=dim]').val().trim().toUpperCase()
    let last2leterOfDim = dim.substring(1, 3)
    let dieNo = ''
    let mr_type_id

    // new
    if (dim == '11A') {
      dieNo = partNo + '-' + dim + '-001';
      mr_type_id = 1
    }
    // addi
    if (dim[0] != '1' && last2leterOfDim == '1A') {
      dieNo = partNo + '-' + dim + '-001';
      mr_type_id = 2
    }
    //renew ECN
    if (last2leterOfDim == '2A') {
      dieNo = partNo + '-' + dim + '-001';
      mr_type_id = 3
    }
    //renew factory
    if (last2leterOfDim == '3A') {
      dieNo = partNo + '-' + dim + '-001';
      mr_type_id = 4
    }
    //renew die life
    if (dim[1] == '4') {
      dieNo = partNo + '-' + dim + '-001';
      mr_type_id = 5
    }
    //ECN
    if (dim[1] == '5') {
      changeInputDieNoProperty()
      mr_type_id = 6
    }
    //Modify
    if (dim[1] == '6') {
      changeInputDieNoProperty()
      mr_type_id = 7
    }
    //Repair
    if (dim[1] == '7') {
      changeInputDieNoProperty()
      mr_type_id = 8
    }

    //modify Overseas
    if (dim[1] == '8') {
      changeInputDieNoProperty()
      mr_type_id = 9
    }

    //modify Overseas
    if (dim[1] == '9') {
      changeInputDieNoProperty()
      mr_type_id = 10
    }

    function changeInputDieNoProperty() {
      $('input[name=die_no]').prop('placeholder', 'Which die modify/ Repair?')
      $('input[name=die_no]').prop('disabled', false)

      let a = $('input[name=die_no]').parent().children('label').text('Modify/Repair for Die ID')
    }
    function defaulInputDieNoProperty() {
      $('input[name=die_no]').prop('placeholder', '')
      $('input[name=die_no]').prop('disabled', true)
      let a = $('input[name=die_no]').parent().children('label').text('Die ID')
    }

    // check MR exists or not?
    if (partNo.length == 12 && dim.length == 3) {
      let checkResult = await this.APIservices.isExistMR({ part_no: partNo, dim: dim }).toPromise()
      if (checkResult?.status) {
        $('#issue_MR_Warning').text('Systen Warning: ' + checkResult.msg)
      }
    } else {
      $('#issue_MR_Warning').text('')
    }


    $('input[name=die_no]').val(dieNo)
    $('input[name=mr_type_id]').val(mr_type_id)
  }

  showAllDie() {
    this.searchParameter = {
      page: 1,
      search: ''
    }
    $('#form_Search')[0].reset()
    this.renderTable(this.searchParameter)
  }

  showDieDetail(die_id: number) {
    this.DOMService.showModalDieDetail([die_id], this.die_role_id, true)
  }

  editDieInfo() {
    let _that = this
    Validator({
      form: '#form_edit_die_info',
      formGroupSelector: '.nice-form-group',
      rules: [

      ],
      onSubmit: async function (data: any) {
        console.log(data)
        let newValue = data.newValue
        if (data.name == 'genaral_information') {
          newValue = moment().format("YYYY/MM/DD") + ` ${_that.userName}: ` + newValue
          data.newValue = newValue;
          newValue = newValue + '\n' + data.currentValue
        }
        _that.DOMService.onloading(".btn_submit_edit_die_info")
        let result = await _that.APIservices.updateDieInfo(data).toPromise()
        if (result?.status) {
          let isSelectedOption = $('#form_edit_die_info .renderElementNewValue').has('select')

          if (isSelectedOption.length > 0) {
            newValue = $('#form_edit_die_info .renderElementNewValue').children('select').children('option:selected').text()
          }

          $(`li[data-name=${data.name}][data-die_id=${data.die_id}]`).find('.text-content').empty().text(newValue)
          $(`li[data-name=${data.name}][data-die_id=${data.die_id}]`).attr('data-currentVal', newValue)
          $(`.die_detail_show_die_progress[data-die_id=${data.die_id}]`).empty().text(result.progress)
          const modal = bootstrap.Modal.getInstance($('#modal_edit_die_info')).hide()
        } else {
          _that.DOMService.showAlertMassage(result?.msg, false)

        }
        _that.DOMService.onloaded(".btn_submit_edit_die_info")
      }
    });
  }

  addCommonDie() {
    let _that = this
    Validator({
      form: '#form_add_common_die',
      formGroupSelector: '.nice-form-group',
      rules: [
        Validator.isRequired('input[name=part_no]'),
        //Validator.length('input[name=part_no]'),
      ],
      onSubmit: async function (data: any) {

        _that.DOMService.onloading(".btn_submit_add_common_die")
        let result = await _that.APIservices.add_edit_deleteCommon(data).toPromise()
        if (result?.status) {
          $('#add_new_common_Warning').empty().append(result.msg)
          $('#form_add_common_die')[0].reset()
          _that.renderModalAddCommon(data.die_id, false)
        } else {
          $('#add_new_common_Warning').empty().append(result?.msg)
        }
        _that.DOMService.onloaded(".btn_submit_add_common_die")
      }
    });
  }

  renderModalAddCommon(die_id: number, isOpenModal: boolean) {
    $('#form_add_common_die')[0].reset()
    $('#add_new_common_Warning').empty()
    let dieInfor = this.APIservices.getDieDetail(die_id).subscribe(res => {
      let allCommon = res.common;
      $('#add_common_for_dieno').empty().append(res.dieInfo.dieno)
      $('#form_add_common_die input[name=die_id]').val(res.dieInfo.die_id)
      let content = '';
      allCommon.forEach((e: any) => {
        console.log(e)
        content += `
                      <li class="list-group-item d-flex justify-content-between align-items-start">
                          <div class="ms-2 me-auto ">
                            <div class="fw-bold">${e.part_no} ${e.part_name ? `<span class='fw-normal fs-6'>[${e.part_name}]</span>` : ''}</div>
                            <div class="row mt-1">
                              
                                <div class="nice-form-group mt-1 col-md-6">
                                    <input class="switch edit_common" data-common_id=${e.common_id} type="checkbox" ${e.is_family_die ? 'checked' : ''} name="is_family_die" id="form_add_common_die_is_family_${e.common_id}"
                                        value="${e.is_family_die ? 'true' : ''}" />
                                    <label for="form_add_common_die_is_family_${e.common_id}">Is Family</label>
                                </div>
                                  <div class="nice-form-group mt-1 col-md-6">
                                    <input class="switch edit_common" data-common_id=${e.common_id} type="checkbox" ${e.is_common_part ? 'checked' : ''} name="is_common_part" id="form_add_common_die_is_common_${e.common_id}"
                                       value="${e.is_common_part ? 'true' : ''}" />
                                    <label class='text-nowrap' for="form_add_common_die_is_common_${e.common_id}">Is Common/Cassette</label>
                                </div>
                            </div>
                          </div>
                          <span data-common_id=${e.common_id} data-die_id=${res.dieInfo.die_id} class="cursor text-danger fs-3 delete_common_die" title="Delete common/family">
                              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                                  <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z"/>
                                  <path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z"/>
                                </svg>
                          </span>
                      </li>
            
            
            `
      });

      $('#render-list-common-for-edit').empty().append(content)

    })

    if (isOpenModal) {
      const modalMassage = new bootstrap.Modal('#modal_add_common_die', {
        keyboard: true
      })
      modalMassage.show()
    }

  }

  chartOptions = {
    series: [],
    labels: [],
    annotations: {
      points: [{
        x: 'Bananas',
        seriesIndex: 0,
        label: {
          borderColor: '#775DD0',
          offsetY: 0,
          style: {
            color: '#fff',
            background: '#775DD0',
          },
          text: 'Bananas are good',
        }
      }]
    },
    chart: {
      height: 250,
      type: 'bar',
      stacked: true,
      stackType: '100%',
      events: {

        dataPointSelection: (event: any, chartContext: any, config: any) => {
          var seriesIndex = config.seriesIndex;
          var dataPointIndex = config.dataPointIndex;
          var qty = chartContext.w.config.series[seriesIndex].data[dataPointIndex];
          var die_classify = chartContext.w.globals.seriesNames[seriesIndex];
          var progress = chartContext.w.globals.categoryLabels[dataPointIndex];
          this.searchParameter.die_classify = die_classify;
          this.searchParameter.progress = progress;
          this.searchParameter.page = 1;
          this.renderTable(this.searchParameter)

        },
      }

    },
    plotOptions: {
      bar: {
        columnWidth: '50%',
      }
    },
    dataLabels: {
      enabled: false
    },
    stroke: {
      width: 0
    },
    grid: {
      row: {
        colors: ['#fff', '#f2f2f2']
      }
    },
    xaxis: {
      categories: [],
      labels: {
        rotate: -45,
        style: {
          colors: [],
          fontSize: '10px',
          fontFamily: 'Helvetica, Arial, sans-serif',
          fontWeight: 400,
        },
      },
      tickPlacement: 'on',

    },
    yaxis: {
      title: {
        text: 'Dies',
      },
    },
    fill: {
      type: 'gradient',
      gradient: {
        shade: 'light',
        type: "horizontal",
        shadeIntensity: 0.25,
        gradientToColors: undefined,
        inverseColors: true,
        opacityFrom: 0.85,
        opacityTo: 0.85,
        stops: [50, 0, 100]
      },
    },
    legend: {
      show: true,
      showForSingleSeries: true,
      position: 'top',
      horizontalAlign: 'center',
    }
  }

  async renderChartDie() {
    let _that = this
    let dieProgress = await this.APIservices.getSumarizeDieProgress().toPromise()
    let listProgress = dieProgress?.data.filter((e: any) => !e.progress.includes('[MP]'))
    console.log(dieProgress)
    // Transform data to match ApexCharts format
    let seriesData: any = [];
    let categories: any = [];
    let dataName: any = []

    listProgress.forEach((e: any) => {
      dataName.push(e.die_classify);
      categories.push(e.progress);
    })
    categories = [...new Set(categories)]
    dataName = [...new Set(dataName)]
    for (let i = 0; i < dataName.length; i++) {
      let data: any = [];
      for (let j = 0; j < categories.length; j++) {
        let count = 0;
        listProgress.forEach((e: any) => {
          if (e.die_classify == dataName[i] && e.progress == categories[j]) {
            count += e.count
          }
        })
        data.push(count)
      }
      seriesData.push({
        name: dataName[i],
        data: data
      })
    }
    var options = this.chartOptions
    options.series = seriesData
    options.xaxis.categories = categories

    $('#render_chart_box').empty()
    var chart = new ApexCharts(document.querySelector("#render_chart_box"), options);
    chart.render();
  }


  downloadMRform(mr_id: number) {
    alert('download MR_id: ' + mr_id)
  }











  selectAll(isSelectAll: boolean) {
    this.DOMService.selectAll('row_die_id', isSelectAll)
  }

  getSelectedIDs() {

    return this.DOMService.getSelectedID('row_die_id')
  }



}
