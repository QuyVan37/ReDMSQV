
CREATE OR REPLACE FUNCTION public.update_die_progress(
	p_die_id integer)
    RETURNS text
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    o_progress text;
BEGIN
    -- Update the 'progress' column with complex CASE logic
	-- disable triggger trước khi update progress
		do $$
		<<disabled_trigger>>
		declare
		  test1 text;
		begin
		   -- disable triggger
		 	ALTER TABLE dies
			DISABLE TRIGGER update_die_trigger;
			test1:= 'test1';
		   raise notice 'đã disable trigger is %', test1;
		end disabled_trigger $$;
    UPDATE dies
    SET progress = 
		CASE 
	      ....
    	END
    FROM dies d
    -- (your existing JOINs here)
	...
    WHERE dies.die_id = d.die_id and dies.die_id = p_die_id;
-- enable triggger sau khi update progress
    -- Check progress and update status if necessary
    SELECT progress INTO o_progress FROM dies WHERE die_id = p_die_id;
    -- Log the current progress
    RAISE NOTICE 'Current progress: %', o_progress;

   IF o_progress = 'MP_Main' THEN
   RAISE NOTICE 'Entered IF block';
  
   UPDATE dies SET die_status_id = 3 WHERE die_id = p_die_id;
   END IF;
    -- Log the updated progress
    RAISE NOTICE 'Updated progress: %', o_progress;
    RETURN o_progress::text;
END;
$BODY$;
