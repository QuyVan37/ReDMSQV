import { Component } from '@angular/core';

@Component({
  selector: 'app-po',
  templateUrl: './po.component.html',
  styleUrl: './po.component.css'
})
export class PoComponent {

}
