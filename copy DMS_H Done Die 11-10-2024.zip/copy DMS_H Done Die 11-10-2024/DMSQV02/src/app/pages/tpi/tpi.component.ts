import { Component } from '@angular/core';

@Component({
  selector: 'app-tpi',
  templateUrl: './tpi.component.html',
  styleUrl: './tpi.component.css'
})
export class TpiComponent {

}
