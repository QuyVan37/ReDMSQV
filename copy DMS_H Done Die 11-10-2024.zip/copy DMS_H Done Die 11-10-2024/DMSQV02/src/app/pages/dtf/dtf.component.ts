import { Component } from '@angular/core';

@Component({
  selector: 'app-dtf',
  templateUrl: './dtf.component.html',
  styleUrl: './dtf.component.css'
})
export class DtfComponent {

}
