import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DtfComponent } from './dtf.component';

describe('DtfComponent', () => {
  let component: DtfComponent;
  let fixture: ComponentFixture<DtfComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DtfComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DtfComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
