import { Component, AfterViewInit, OnDestroy, Renderer2, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Config } from 'datatables.net';
import { AuthenService } from '../../API-Services/authen.service';
import { Router } from '@angular/router';
import { DOMServiceService } from '../../common-services/dom-service.service';
import { AppAPIService } from '../../API-Services/app-api.service';
import { Subject } from 'rxjs';

import moment from 'moment';
const apexChart = import('apexcharts');
declare var $: any;
declare var bootstrap: any;
declare var Validator: any;
declare var DataTable: any;


@Component({
  selector: 'app-mr',
  templateUrl: './mr.component.html',
  styleUrl: './mr.component.css',
  host: { ngSkipHydration: 'true' },
})
export class MrComponent {
  private eventListener!: () => void;

  constructor(
    private authen: AuthenService,
    private router: Router,
    private DOMService: DOMServiceService,
    private APIservices: AppAPIService,
    private renderer: Renderer2,


  ) { }







  dept: string = JSON.parse(localStorage.getItem('user') ?? '')[0].dept_name
  mr_role_id: number = 0;
  admin = false;
  searchParameter = {
    page: 1,
    search: '',
  }

  dtOptions: any = {
    serverSide: false,
    paging: false,
    ordering: false,
    select: true, keys: true,
    scrollY: '300',
    scrollX: true,
    fixedColumns: {
      left: 3,
      right: 0
    },
    rowId: 'mr_id',
    searching: false,
    createdRow: (row: any, data: any, index: any) => {
      // if (data[5].replace(/[\$,]/g, '') * 1 > 150000) {
      //     row.querySelector(':nth-child(6)').classList.add('highlight');
      // }

    },
    columns: [
      {
        title: `<label for='selectAll'>Select All </label><input class="selectAll" id='selectAll' type='checkbox'/>`,
        data: 'mr_id',
        render: function (data: any, type: any, row: any) {
          return `<input type='checkbox' value='${data}' name='row_mr_id'/> `
        }
      },
      {
        title: 'MRNo',
        data: 'mr_no',
        render: function (data: any, type: any, row: any) {
          return `<span title='click to download MR form' class='cursor text-primary download-mr' (click)="test()" data-mr-id = '${row.mr_id}'>${data}</span>`
        }
      },
      {
        title: 'Part No',
        data: 'part_no',
      },
      {
        title: 'Dim',
        data: 'clasification'
      },
      {
        title: 'DieID',
        data: 'die_no'
      },
      {
        title: 'Status',
        data: 'status',
        render: function (data: any, type: any, row: any) {
          return `<button style="min-width:150px" class="btn btn-sm btn-primary btn_show_modal_MR_detail" data-mr-id='${row.mr_id}'>${data}</button>`
        }
      },
      {
        title: 'Order To',
        data: 'order_to'
      },
      {
        title: 'vendor',
        data: 'supplier_code'
      },
      {
        title: 'Model',
        data: 'model_name'
      },
      {
        title: 'Process Code',
        data: 'process_code'
      },
      {
        title: 'Reason',
        data: 'reason'
      },
      {
        title: 'ECN No',
        data: 'ecn_no'
      },
      {
        title: 'His',
        data: 'draw_his'
      },
      {
        title: 'PDD',
        data: 'pdd',
        render: function (data: any, type: any, row: any) {
          return moment(data).format('YYYY/MM/DD')
        }
      },
      {
        title: 'Request',
        data: 'request_by'
      },
      {
        title: 'Date',
        data: 'request_date',
        render: function (data: any, type: any, row: any) {
          return moment(data).format('YYYY/MM/DD hh:mm A')
        }
      },
    ]
  };
  dtTrigger: Subject<any> = new Subject();
  ngOnInit(): void {
    this.authen.checkLoginAndHandle()
    this.mr_role_id = this.authen.getRoleForFucntion('mr_role_id')
    this.renderChartMR()
    let _that = this
    // start render
    //render search areas
    this.createMRtypeOptionElement()
    this.createSupplierListOptionElement()

    //rendertable
    this.renderTable(this.searchParameter)
    // Handle sự kiện click ngoài angular
    this.eventListener = this.renderer.listen(document, "click", function (e) {
      //trường hợp user click vào page
      // => add page vào object searchParameter => render lại table
      let page = $(e.target).attr('data-page')
      if (page) {
        let isnewpage = _that.searchParameter.page != page
        if (isnewpage) {
          _that.searchParameter.page = page
          _that.renderTable(_that.searchParameter)
        }
      }

      //trường hợp user click vào Downloard MR form
      let isClickDownloadMR = $(e.target).hasClass('download-mr')
      if (isClickDownloadMR) {
        let mr_id = $(e.target).attr('data-mr-id')
        _that.downloadMRform(mr_id)
      }

      //trường hợp user click vào Show MR detail
      let isClickShowMR = $(e.target).hasClass('btn_show_modal_MR_detail')
      if (isClickShowMR) {
        let mr_id = $(e.target).attr('data-mr-id')
        _that.showMRDetail(mr_id)
      }

      //trường hợp user click vào btn_check_MR
      let isClickApprovekMR = $(e.target).hasClass('btn_Approve_MR')
      if (isClickApprovekMR) {
        let mr_id = $(e.target).attr('data-mr-id')
        _that.approveMR(mr_id)
      }

      //trường hợp user click vào btn_check_MR
      let isClickCheckMR = $(e.target).hasClass('btn_check_MR')
      if (isClickCheckMR) {
        let mr_id = $(e.target).attr('data-mr-id')
        _that.checkMR(mr_id)
      }

      //trường hợp user click vào btn_check_MR
      let isClickRejectMR = $(e.target).hasClass('btn_reject_MR')
      if (isClickRejectMR) {
        let mr_id = $(e.target).attr('data-mr-id')
        _that.rejectMR(mr_id)
      }

      //trường hợp user click vào selectAll
      let isClickSelectAll = $(e.target).hasClass('selectAll')
      if (isClickSelectAll) {

        let isSelectAll = $(e.target).prop('checked')
        _that.selectAll(isSelectAll)
      }
    })






  }



  ngOnDestroy() {
    if (this.eventListener) {
      this.eventListener();
    }
  }

  async renderTable(searchParameter: any) {
    this.DOMService.onloading('.btn_search')
    let _that = this
    this.dtOptions.destroy = true,
      this.dtOptions.processing = true;
    let dataResult = await this.APIservices.getMRList(searchParameter).toPromise()
    if (dataResult?.status == false) {
      this.DOMService.showAlertMassage(dataResult.msg, false)
      return
    }
    this.dtOptions.data = dataResult?.data
    this.DOMService.pagination(dataResult?.page, dataResult?.pageSize, dataResult?.recordsTotal, '.render_paganation')
    this.dtTrigger.next(null)
    _that.DOMService.onloaded('.btn_search')
  }

  async createMRtypeOptionElement() {
    let mrTypeCategory = await this.APIservices.getMRTypeCategory().toPromise()
    let result = this.DOMService.createOptionElement(mrTypeCategory?.data, ["type"], "mr_type_id", "")
    this.DOMService.appendToElement("select[name=mr_type_id]", result)
  }

  async createSupplierListOptionElement() {
    let suppliers = await this.APIservices.getSupplierList().toPromise()
    let result = this.DOMService.createOptionElement(suppliers?.data, ["supplier_code", 'supplier_name'], "supplier_id", "")
    this.DOMService.appendToElement("select[name=supplier_id]", result)
  }

  searchMR() {
    let _that = this
    Validator({
      form: '#form_Search',
      formGroupSelector: '.nice-form-group',
      rules: [

      ],
      onSubmit: async function (data: any) {
        _that.searchParameter = { ..._that.searchParameter, ...data }
        _that.renderTable(data)

      }
    })
  }


  showModelIsueMR() {
    const modalMassage = new bootstrap.Modal('#modal_issueMR', {
      keyboard: true
    })
    modalMassage.show()
  }


  async handleInputFormIssueMR() {
    defaulInputDieNoProperty()
    let partNo = $('input[name=part_no]').val().trim().toUpperCase()
    let dim = $('input[name=dim]').val().trim().toUpperCase()
    let last2leterOfDim = dim.substring(1, 3)
    let dieNo = ''
    let mr_type_id

    // new
    if (dim == '11A') {
      dieNo = partNo + '-' + dim + '-001';
      mr_type_id = 1
    }
    // addi
    if (dim[0] != '1' && last2leterOfDim == '1A') {
      dieNo = partNo + '-' + dim + '-001';
      mr_type_id = 2
    }
    //renew ECN
    if (last2leterOfDim == '2A') {
      dieNo = partNo + '-' + dim + '-001';
      mr_type_id = 3
    }
    //renew factory
    if (last2leterOfDim == '3A') {
      dieNo = partNo + '-' + dim + '-001';
      mr_type_id = 4
    }
    //renew die life
    if (dim[1] == '4') {
      dieNo = partNo + '-' + dim + '-001';
      mr_type_id = 5
    }
    //ECN
    if (dim[1] == '5') {
      changeInputDieNoProperty()
      mr_type_id = 6
    }
    //Modify
    if (dim[1] == '6') {
      changeInputDieNoProperty()
      mr_type_id = 7
    }
    //Repair
    if (dim[1] == '7') {
      changeInputDieNoProperty()
      mr_type_id = 8
    }

    //modify Overseas
    if (dim[1] == '8') {
      changeInputDieNoProperty()
      mr_type_id = 9
    }

    //modify Overseas
    if (dim[1] == '9') {
      changeInputDieNoProperty()
      mr_type_id = 10
    }

    function changeInputDieNoProperty() {
      $('input[name=die_no]').prop('placeholder', 'Which die modify/ Repair?')
      $('input[name=die_no]').prop('disabled', false)

      let a = $('input[name=die_no]').parent().children('label').text('Modify/Repair for Die ID')
    }
    function defaulInputDieNoProperty() {
      $('input[name=die_no]').prop('placeholder', '')
      $('input[name=die_no]').prop('disabled', true)
      let a = $('input[name=die_no]').parent().children('label').text('Die ID')
    }

    // check MR exists or not?
    if (partNo.length == 12 && dim.length == 3) {
      let checkResult = await this.APIservices.isExistMR({ part_no: partNo, dim: dim }).toPromise()
      if (checkResult?.status) {
        $('#issue_MR_Warning').text('Systen Warning: ' + checkResult.msg)
      }
    } else {
      $('#issue_MR_Warning').text('')
    }


    $('input[name=die_no]').val(dieNo)
    $('input[name=mr_type_id]').val(mr_type_id)
  }

  issueMR() {

    let _that = this

    Validator({
      form: '#form_issue_MR',
      formGroupSelector: '.nice-form-group',
      rules: [
        // Validator.isRequired('input[name=belong]'),
        // Validator.isRequired('input[name=part_no]'),
        // Validator.isLength('input[name=part_no]', 12),
        // Validator.isRequired('input[name=dim]'),
        // Validator.isLength('input[name=dim]', 3),
        // Validator.isRequired('input[name=die_no]'),
        // Validator.isLength('input[name=die_no]', 20),
        // Validator.isRequired('input[name=part_name]'),
        // Validator.isRequired('select[name=process_code_id]'),
        // Validator.isRequired('input[name=ecn_no]'),
        // Validator.isLength('input[name=ecn_no]',13),
        // Validator.isRequired('input[name=his]'),
        // Validator.isLength('input[name=his]',3),
        // Validator.isRequired('select[name=model_id]'),
        // Validator.isRequired('select[name=supplier_id]'),
        // Validator.isRequired('select[name=order_to]'),
        // Validator.isRequired('input[name=pdd]'),
        // Validator.isRequired('input[name=estmate_code]'),
        // Validator.isNumber('input[name=estmate_code]'),
        // Validator.isRequired('select[name=unit]'),
        // Validator.isRequired('input[name=mc_size]'),
        // Validator.isNumber('input[name=mc_size]'),
        // Validator.isRequired('input[name=cav_qty]'),
        // Validator.isNumber('input[name=cav_qty]'),
        // Validator.isRequired('input[name=reason]'),

      ],
      onSubmit: async function (data: any) {
        _that.DOMService.onloading(".btn_submit_MR")
        let result = await _that.APIservices.issueMR(data).toPromise()
        if (result?.status) {
          _that.DOMService.showAlertMassage(result.msg, true)
        } else {
          _that.DOMService.showAlertMassage(result?.msg, false)
        }
        _that.DOMService.onloaded(".btn_submit_MR")
      }
    });

  }

  issueMRByExcel() {
    this.DOMService.onloading(".btn_issueMR_excel")
    let file = $('input[name=file_issue_MR_Excel]')[0].files[0]
    let formData = new FormData()
    formData.append('file', file)
    this.APIservices.issueMRByExcel(formData).toPromise();


    this.DOMService.onloaded(".btn_issueMR_excel")
  }

  checkMR(mr_id: number | undefined) {
    console.log('dsdsd')
    let _that = this
    if (mr_id) { //check one by one
      let users = this.authen.isLogined().user
      let isPAE = users.some((e: any) => { return ["PAE"].includes(e.dept_name) })
      if (isPAE) {
        Validator({
          form: '#form_PAE_Check_MR',
          formGroupSelector: '.nice-form-group',
          rules: [
            Validator.isRequired('select[name=check_is_de_die]'),
            Validator.isRequired('input[name=check_no_of_die_component]'),
            Validator.isNumber('input[name=check_no_of_die_component]'),
            Validator.isRequired('input[name=check_die_maker]'),
            Validator.isRequired('input[name=check_make_location]'),
          ],
          onSubmit: async function (data: any) {
            data.mRIDs = mr_id
            _that.DOMService.onloading(".btn_check_MR")
            let result = await _that.APIservices.checkAndapproveMR(data).toPromise()
           
            if (result?.success.length !== 0) {
              result?.success.forEach((mr_id: any) => {
                $(`#${mr_id}`).css('display', 'none')
              })
              const modal = bootstrap.Modal.getInstance($('#showModalMRDetail')).hide()
              _that.renderChartMR()
            }
            
            _that.DOMService.onloaded(".btn_check_MR")
          }
        })
      } else {
        _that.DOMService.onloading(".btn_check_MR")
        let data = {
          mRIDs: mr_id,
          check_comment: $('input[name=check_comment]').val()
        }
        let result = _that.APIservices.checkAndapproveMR(data).toPromise()
        _that.DOMService.onloaded(".btn_check_MR")
      }

    } else { // mutipli check
      // function này show modal confirm trước khi approve
      let mrSelected: any = this.getSelectedIDs()
      if (!mrSelected.length) {
        this.DOMService.showAlertMassage("You need select MR which you one to take action", false)
        return
      }
      if (this.authen.isLogined().user[0].dept_name.includes("PAE")) {
        this.DOMService.showAlertMassage("PAE need check MR one by one", false)
        return
      }
      $('#label_confirming').text('You are checking for ' + mrSelected.length + ' MR(s)')
      const modalMassage = new bootstrap.Modal('#modal_approve_confirm', {
        keyboard: true
      })
      modalMassage.show()
    }
  }

  approveMR(mr_id: number | undefined) {
    if (mr_id) { // one by one approve
      alert("Approve MR")
    } else { // muitipli Approve
      // function này show modal confirm trước khi approve
      let mrSelected: any = this.getSelectedIDs()
      $('#label_confirming').text('You are approving for ' + mrSelected.length + ' MR(s)')
      const modalMassage = new bootstrap.Modal('#modal_approve_confirm', {
        keyboard: true
      })
      modalMassage.show()
    }

  }


  async confirmApproveMR() {
    this.DOMService.onloading('.btn_confirm_approve')
    let mrSelected: any = this.getSelectedIDs()
    let comment = $('#approver_comment').val()
    if (mrSelected.length == 0) {
      this.DOMService.showAlertMassage('Please select MR which you want to approve!', false)
      this.DOMService.onloaded('.btn_confirm_approve')
      return
    }

    let approveResult = await this.APIservices.checkAndapproveMR({ mRIDs: mrSelected, check_comment: comment }).toPromise()
    this.DOMService.onloaded('.btn_confirm_approve')
    const modal = bootstrap.Modal.getInstance($('#modal_approve_confirm')).hide()
  }


  rejectMR(mr_id: number | undefined) {

    if (mr_id) { // one by on reject
      alert("reject MR")
    } else { // mutipli reject
      // function này show modal confirm trước khi approve
      let mrSelected: any = [1, 2, 3]
      $('#label_reject_confirming').text('You are rejecting for ' + mrSelected.length + ' MR(s)')
      const modalMassage = new bootstrap.Modal('#modal_reject_confirm', {
        keyboard: true
      })
      modalMassage.show()
    }
  }

  async confirmRejectMR() {
    this.DOMService.onloading('.btn_confirm_reject')
    let mrSelected: any[] = [1, 2, 3]
    let comment = $('#approver_comment').val()
    if (mrSelected.length == 0) {
      this.DOMService.showAlertMassage('Please select MR which you want to approve!', false)
      this.DOMService.onloaded('.btn_confirm_reject')
      return
    }

    let rejectResult = await this.APIservices.rejectMR({ mRIDs: mrSelected, comment: comment }).toPromise()

    this.DOMService.onloaded('.btn_confirm_reject')
    const modal = bootstrap.Modal.getInstance($('#modal_reject_confirm')).hide()
  }

  chartOptions = {
    series: [],
    annotations: {
      points: [{
        x: 'Oranges',
        seriesIndex: 0,
        label: {
          borderColor: '#775DD0',
          offsetY: 0,
          style: {
            color: '#fff',
            background: '#775DD0',
          },
          text: 'Bananas are good',
        }
      }]
    },
    chart: {
      height: 200,
      type: 'bar',
      events: {
        dataPointSelection: async (event: any, chartContext: any, opts: any) => {
          let index = opts.dataPointIndex
          let data = await opts.w.config.xaxis.categories[index]
          let qty = opts.w.config.series[0].data[index]
          this.renderTable({ search: data })
        }
      },
    },
    plotOptions: {
      bar: {
        columnWidth: '60%',
      }
    },
    dataLabels: {
      enabled: true,
      textAnchor: 'middle',
      offsetY: 0,
      style: {
        fontFamily: 'Helvetica, Arial, sans-serif',
        fontWeight: 'bold',
        colors: ['#000']
      }
    },
    stroke: {
      width: 0
    },
    grid: {
      row: {
        colors: ['#fff', '#f2f2f2']
      }
    },
    xaxis: {
      labels: {
        rotate: -25
      },
      categories: []
    },
    yaxis: {
      title: {
        text: 'MR',
      },
    },
    fill: {
      type: 'gradient',
      gradient: {
        shade: 'light',
        type: "horizontal",
        shadeIntensity: 0.25,
        gradientToColors: undefined,
        inverseColors: true,
        opacityFrom: 0.85,
        opacityTo: 0.85,
        stops: [50, 0, 100]
      },
    },

  };


  async renderChartMR() {
    let mrPending = await this.APIservices.getSumarizeMRPending().toPromise()

    let data: any = [];
    let category: any = []
    mrPending?.data.forEach((e: any) => {
      data.push(e.qty)
      category.push(e.status)
    });

    let series: any = [{
      name: 'MR',
      data: data
    }]
    //let category:any = ['W-PAE', 'W-PE1', 'W-PUR', 'W-ddd']
    var options = this.chartOptions
    options.series = series
    options.xaxis.categories = category

    $('#render_chart_box').empty()
    var chart = new ApexCharts(document.querySelector("#render_chart_box"), options);
    chart.render();
  }

  distroyChart() {
    var options = this.chartOptions
    var chart = new ApexCharts(document.querySelector("#render_chart_box"), options);
    chart.destroy()
  }

  downloadMRform(mr_id: number) {
    alert('download MR_id: ' + mr_id)
  }

  showMRDetail(mr_id: number) {
    this.DOMService.renderModalMRDetail(mr_id)
  }

  selectAll(isSelectAll: boolean) {
    this.DOMService.selectAll('row_mr_id', isSelectAll)
  }

  getSelectedIDs() {

    return this.DOMService.getSelectedID('row_mr_id')
  }

}
