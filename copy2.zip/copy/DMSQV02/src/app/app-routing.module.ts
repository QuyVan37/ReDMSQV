import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { MrComponent } from './pages/mr/mr.component';
import { authenticatorGuard } from './authen/authenticator.guard';
import { PageNotFoundComponent } from './pages/page-not-found/page-not-found.component';
import { LoginComponent } from './pages/login/login.component';
import { DiesComponent } from './pages/dies/dies.component';
import { BudgetComponent } from './pages/budget/budget.component';
import { TpiComponent } from './pages/tpi/tpi.component';
import { PoComponent } from './pages/po/po.component';
import { DcfComponent } from './pages/dcf/dcf.component';
import { DtfComponent } from './pages/dtf/dtf.component';
import { DisposeComponent } from './pages/dispose/dispose.component';
import { AdminComponent } from './pages/admin/admin.component';
import { MasterComponent } from './pages/master/master.component';


const routes: Routes = [
  {path: '', component: HomeComponent, canActivate: [authenticatorGuard]},
  {path: 'Home', component: HomeComponent, canActivate: [authenticatorGuard]},
  {path: 'Die', component: DiesComponent, canActivate: [authenticatorGuard]},
  {path: 'Budget', component: BudgetComponent, canActivate: [authenticatorGuard]},
  {path: 'MR', component: MrComponent, canActivate: [authenticatorGuard]},
  {path: 'PO', component: PoComponent, canActivate: [authenticatorGuard]},
  {path: 'TPI', component: TpiComponent, canActivate: [authenticatorGuard]},
  {path: 'DCF', component: DcfComponent, canActivate: [authenticatorGuard]},
  {path: 'DTF', component: DtfComponent, canActivate: [authenticatorGuard]},
  {path: 'Dispose', component: DisposeComponent, canActivate: [authenticatorGuard]},
  {path: 'Admin', component: AdminComponent, canActivate: [authenticatorGuard]},
  {path: 'Master', component: MasterComponent, canActivate: [authenticatorGuard]},
  {path: 'login', component: LoginComponent},



  {path: '**', component: PageNotFoundComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
