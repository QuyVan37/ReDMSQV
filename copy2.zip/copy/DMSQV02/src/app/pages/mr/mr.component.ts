import { Component, AfterViewInit, OnDestroy, Renderer2, ElementRef, OnInit, ViewChild, provideExperimentalZonelessChangeDetection } from '@angular/core';
import { Config } from 'datatables.net';
import { AuthenService } from '../../API-Services/authen.service';
import { Router } from '@angular/router';
import { DOMServiceService } from '../../common-services/dom-service.service';
import { AppAPIService } from '../../API-Services/app-api.service';
import { Subject } from 'rxjs';
import moment from 'moment';
declare var $: any;
declare var bootstrap: any;
declare var Validator: any;
declare var DataTable: any;

@Component({
  selector: 'app-mr',
  templateUrl: './mr.component.html',
  styleUrl: './mr.component.css'
})
export class MrComponent {
  constructor(private authen: AuthenService,
    private router: Router,
    private DOMService: DOMServiceService,
    private APIservices: AppAPIService,
    private renderer: Renderer2,

  ) { }
  searchParameter = {
    page: 1,
    search: null,
  }


  dtOptions: any = {
    serverSide: false,
    paging: false,
    ordering: false,
    select: true, keys: true,
    scrollY: '300',
    scrollX: true,
    fixedColumns: {
      left: 2,
      right: 0
    },
    searching: false,
    columns: [
      {
        title: 'MRNo',
        data: 'mr_no',
        render: function (data: any, type: any, row: any) {
          return `<button class="btn btn-sm btn-primary btn_show_modal_MR_detail" data-user-id='${row.mr_id}'>${data}</button>`
        }
      },
      {
        title: 'Part No',
        data: 'part_no',
      },
      {
        title: 'Dim',
        data: 'dim'
      },
      {
        title: 'Die ID',
        data: 'die_no'
      },

    ]
  };
  dtTrigger: Subject<any> = new Subject();
  ngOnInit(): void {
    let _that = this
    // start render
    this.renderTable(this.searchParameter)

    // Handle sự kiện click ngoài angular
    this.renderer.listen(document, "click", function (e) {





    })

    //Handle sự kiện on change ngoài angular
    //3. Trường hợp admin chọn dept cho user
    //> show role hiện có nếu đã setup, hiện --- nếu dept chưa setup role
    this.renderer.listen(document, "change", function (e: any) {

    })



  }



  async renderTable(searchParameter: any) {
    this.DOMService.onloading('.btn_search')
    let _that = this
    this.dtOptions.destroy = true,
      this.dtOptions.processing = true;
    let dataResult = await this.authen.getListUser(searchParameter).toPromise()
    if (dataResult?.status == false) {
      this.DOMService.showAlertMassage(dataResult.msg, false)
      return
    }
    this.dtOptions.data = dataResult?.data
    this.DOMService.pagination(dataResult?.page, dataResult?.pageSize, dataResult?.recordsTotal, '.render_paganation')
    this.dtTrigger.next(null)
    _that.DOMService.onloaded('.btn_search')
  }



  searchMR() {
    let _that = this
    Validator({
      form: '#form_Search',
      formGroupSelector: '.nice-form-group',
      rules: [

      ],
      onSubmit: async function (data: any) {
        _that.renderTable(data)
      }
    })
  }


  async showModalUserDetail(user_id: number) {
    let userProfile = await this.authen.getUserProfileByID(user_id).toPromise()
    if (userProfile?.status == false) {
      this.DOMService.showAlertMassage(userProfile.msg, false)
      return
    }
    this.DOMService.renderModalUserDetail(userProfile)
  }














}
