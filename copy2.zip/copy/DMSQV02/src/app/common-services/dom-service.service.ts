import { Injectable } from '@angular/core';

import moment from 'moment';
import { AppAPIService } from '../API-Services/app-api.service';
declare var $: any;
declare var bootstrap: any;
@Injectable({
  providedIn: 'root'
})
export class DOMServiceService {

  constructor( 
    private APIservices: AppAPIService,

  ) { }
  onloading(selector: string) {
    console.log(selector)
    $(document).find(selector).addClass('disabled')
    $(document).find(selector).children('.spinner-border').remove()
    $(document).find(selector).append(
      `
        <span class="spinner-border spinner-border-sm" aria-hidden="true"></span>
      `)
  }

  onloaded(selector: string) {
    $(document).find(selector).children('.spinner-border').remove()
    $(document).find(selector).removeClass('disabled')
  }


  createOptionElement(
    listOption: any[] | undefined,
    fields_view: Array<string>,
    Field_value: string,
    selected_Value: string
  ): string {
    let option = '<option value="">---</option>';
    listOption?.forEach(e => {
      let view: Array<string> = [];
      fields_view.forEach(f => {
        view.push(e[f]);
      });
      option += `<option ${e[Field_value] === selected_Value ? 'selected' : ''} value="${e[Field_value]}">${view.join('-')}</option>`;
    });
    return option;
  }

  appendToElement(selector: string, content: string) {
    $(selector).empty().append(content)
  }


  showAlertMassage(massage: string | undefined, isSucces: boolean) {

    // massageType: success or faill
    let bg_color = "danger"
    if (isSucces) bg_color = 'success'
    //1. Loại bỏ modal ra khỏi DOM nếu có
    $(document).find('#modelAlertMassage').remove()
    //2. add modal vào DOM
    $('.content').append(
      `
     <div class="modal fade" id="modelAlertMassage" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
     <div class="modal-dialog">
         <div class="modal-content">
         <div class="modal-header bg-${bg_color} text-white">
             <h1 class="modal-title fs-5" id="exampleModalLabel">System massage</h1>
             <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
         </div>
         <div class="modal-body">
             ${massage}
         </div>
         <div class="modal-footer">
             <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
         </div>
         </div>
     </div>
     </div>
     `
    )

    // 3. show modal
    const modalMassage = new bootstrap.Modal('#modelAlertMassage', {
      keyboard: false
    })
    modalMassage.show()
  }

  showUserInActiveWaning(msg: string) {
    //1. Loại bỏ modal ra khỏi DOM nếu có
    $(document).find('#modelAlertMassage').remove()
   
    $('.content').append(
      `
        <div class="modal fade" id="modalWarningUserNotActive" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header bg-danger">
                <h1 class="modal-title fs-5" id="staticBackdropLabel">Waring: You account was not active!</h1>
              </div>
              <div class="modal-body">
                  ${msg}

              </div>
                <div class="modal-footer">
                  <a href="/login">Login other account</a>
                </div>
            </div>
          </div>
        </div>
     `
    )
    // 3. show modal
    const modalMassage = new bootstrap.Modal('#modalWarningUserNotActive', {
      keyboard: false
    })
    modalMassage.show()

  }

  pagination(page: number = 1, pageSize: number = 0, totalRecords: number = 0, selector: string) {

    let previousePage = page - 1;
    let nextPage = page + 1;
    let firstPage = 1;
    let lastPage = Math.ceil(totalRecords / pageSize);
    nextPage = nextPage > lastPage ? lastPage : nextPage

    let pagination = `
      <ul class="pagination m-0">
        <li class="page-item ${previousePage == 0 ? "disabled" : ""}">
         <span class="cursor page-link page-data" data-page = ${previousePage} >Previous</span>
        </li>
        ${previousePage >= 1 ?
        `<li class="page-item">
             <span class="cursor page-link page-data" data-page = ${firstPage}  href="#">${firstPage}</span>
          </li>
          <li class="page-item page-link page-data disabled">...</li>
          ` : ''}
         
          ${page > 1 ?
        ` <li class="page-item">
              <span class="cursor page-link page-data" data-page = ${previousePage} href="#">${previousePage}</span>
              </li>
            ` : ''}
        
        <li class="page-item">
         <span class="cursor page-link page-data active" data-page = ${page} href="#">${page}</span>
        </li>
        ${nextPage == page ? "" :
        `
            <li class="page-item">
             <span class="cursor page-link page-data" data-page = ${nextPage} href="#">${nextPage}</span>
            </li>
          `
      }
        ${lastPage - nextPage >= 1 ?
        `
          <li class="page-item page-link page-data disabled">...</li>
          <li class="page-item">
             <span class="cursor page-link page-data" data-page = ${lastPage} href="#">${lastPage}</span>
            </li>
          
          ` : ''}
        
            <li class="page-item">
             <span class="cursor page-link page-data ${nextPage == page ? 'disabled' : ''}"  data-page = ${nextPage} href="#">Next</span>
            </li>
        
      </ul>

    `
    $(selector).empty().append(pagination)

  }

 
  async renderModalUserDetail(userProfile: any){
    let listGrade = await this.APIservices.getGradeCategory().toPromise()
    let listDept = await this.APIservices.getListDept().toPromise()
    let listRole = await this.APIservices.getRolesCategory().toPromise()
    let user = userProfile.userProfile;
    let roles = userProfile.roles;
    //1. Loại bỏ modal ra khỏi DOM nếu có
    $(document).find('#showmodalDetail').remove()
    $('.content').append( `
        <div class="modal fade" id="showmodalDetail" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">User ${user.user_name}</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <form action="" method="post" id="form_user_information">
                  <div class="row g-2">
                    <input type="text" hidden name="user_id" value='${user.user_id}'>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <label>Name</label>
                      <input type="text" name="user_name" value='${user.user_name}'>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <label>Code</label>
                      <input type="text" name="user_code" value='${user.user_code}'>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <label>Buyer code</label>
                      <input type="text" name="buyer_code" value='${user.buyer_code}'>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <label>Grade</label>
                      <select name="grade_id">
                        ${this.createOptionElement(listGrade?.data,["grade_name"], 'grade_id', user.grade_id)}
                      </select>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <label>Email</label>
                      <input type="email" name="email" value='${user.email}'>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <label>Lock Reason</label>
                      <input type="text" name="lock_reason" value='${user.lock_reason}'>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <label>Last_online</label>
                      <input type="text" disabled name="last_online" value='${moment(user.last_online).format('YYYY/MM/DD HH:mm:ss A')}'>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <label>Create Date</label>
                      <input type="text" disabled name="create_date" value='${moment(user.create_date).format('YYYY/MM/DD HH:mm:ss A')}'>
                    </div>
                  </div>
                  <div class="row">
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <input name="is_admin" type="checkbox" id="isAdmin" ${user.is_admin ? "checked": ""} class="switch" />
                      <label for="isAdmin">Admin</label>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <input name="is_active" type="checkbox" id="is_Active" ${user.is_active ? "checked": ""} class="switch" />
                      <label for="is_Active">Active</label>
                    </div>
                    <div class="nice-form-group col-sm-12 col-md-3">
                      <input name="is_delete" type="checkbox" id="is_Delete" ${user.is_delete ? "checked": ""} class="switch" />
                      <label for="is_Delete">Delecte</label>
                    </div>
                  </div>
                </form>
                <hr>
                <div>
                  This user was set roles for 2 depts: <span class="fw-bold">PAE_QV, PAE_TS</span>
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <form action="" method="post" id="form_update_role">
                      <div class="row">

                        <div class="row g-2">
                          <div class="nice-form-group col-md-12">
                            <label>Department</label>
                            <select name="dept_id">
                            ${this.createOptionElement(listDept?.data,["dept_name", 'factory'], 'dept_id', roles[0].dept_id)}
                            </select>
                          </div>
                          <div class="nice-form-group col-sm-12 col-md-3">
                            <label>MR Role</label>
                            <select name="mr_role_id">
                             ${this.createOptionElement(listRole?.data,["role_name"], 'role_id', roles[0].mr_role_id)}
                            </select>
                          </div>
                          <div class="nice-form-group col-sm-12 col-md-3">
                            <label>PO Role</label>
                            <select name="po_role_id">
                             ${this.createOptionElement(listRole?.data,["role_name"], 'role_id', roles[0].po_role_id)}
                            </select>
                          </div>
                          <div class="nice-form-group col-sm-12 col-md-3">
                            <label>TPI Role</label>
                            <select name="tpi_role_id">
                             ${this.createOptionElement(listRole?.data,["role_name"], 'role_id', roles[0].tpi_role_id)}
                            </select>
                          </div>
                          <div class="nice-form-group col-sm-12 col-md-3">
                            <label>Die Role</label>
                            <select name="die_role_id">
                             ${this.createOptionElement(listRole?.data,["role_name"], 'role_id', roles[0].die_role_id)}
                            </select>
                          </div>
                          <div class="nice-form-group col-sm-12 col-md-3">
                            <label>Transfer (DTF)</label>
                            <select name="dtf_role_id">
                             ${this.createOptionElement(listRole?.data,["role_name"], 'role_id', roles[0].dtf_role_id)}
                            </select>
                          </div>
                          <div class="nice-form-group col-sm-12 col-md-3">
                            <label>DSUM (DFM)</label>
                            <select name="dsum_role_id">
                             ${this.createOptionElement(listRole?.data,["role_name"], 'role_id', roles[0].dsum_role_id)}
                            </select>
                          </div>
                          <div class="nice-form-group col-sm-12 col-md-3">
                            <label>Dispose</label>
                            <select name="dispose_role_id">
                             ${this.createOptionElement(listRole?.data,["role_name"], 'role_id', roles[0].dispose_role_id)}
                            </select>
                          </div>
                          <div class="nice-form-group col-sm-12 col-md-3">
                            <label>DCF</label>
                            <select name="dcf_role_id">
                             ${this.createOptionElement(listRole?.data,["role_name"], 'role_id', roles[0].dcf_role_id)}
                              </select>
                          </div>
                        </div>
                      </div>
                      <div class="d-flex justify-content-end mt-2">
                        <span data-user-id="${user.user_id}" class="btn btn-primary btn_admin_change_user_role">Change Role</span>
                      </div>
                    
                    </form>
                  </div>
                </div>

              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" action="save" class="btn btn-primary  btn_admin_verified_users">Save
                  changes</button>
                <button type="button" action="verify" class="btn btn-primary btn_admin_verified_users" ">Verified</button>
                 
              </div>
            </div>
          </div>
        </div>
    
    
    
    `)
    
    const modalMassage = new bootstrap.Modal('#showmodalDetail', {
      keyboard: false
    })
    modalMassage.show()
  }








}