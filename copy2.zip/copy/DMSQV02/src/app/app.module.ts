import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { HomeComponent } from './pages/home/home.component';
import { PageNotFoundComponent } from './pages/page-not-found/page-not-found.component';
import { MainLayoutComponent } from './pages/main-layout/main-layout.component';
import { provideHttpClient, withFetch } from '@angular/common/http';
import { LoginComponent } from './pages/login/login.component';
import { PoComponent } from './pages/po/po.component';
import { DiesComponent } from './pages/dies/dies.component';
import { BudgetComponent } from './pages/budget/budget.component';
import { TpiComponent } from './pages/tpi/tpi.component';
import { DtfComponent } from './pages/dtf/dtf.component';
import { DcfComponent } from './pages/dcf/dcf.component';
import { DisposeComponent } from './pages/dispose/dispose.component';
import { AdminComponent } from './pages/admin/admin.component';
import { MasterComponent } from './pages/master/master.component';
import { DataTablesModule } from "angular-datatables";
import { MrComponent } from './pages/mr/mr.component';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    PageNotFoundComponent,
    MainLayoutComponent,
    LoginComponent,
    PoComponent,
    DiesComponent,
    BudgetComponent,
    TpiComponent,
    DtfComponent,
    DcfComponent,
    DisposeComponent,
    AdminComponent,
    MasterComponent,
    MrComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    DataTablesModule
   
  ],
  providers: [
    provideClientHydration(),
    provideHttpClient(withFetch())
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
