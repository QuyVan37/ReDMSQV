﻿using DMSQV_API.Data;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using DMSQV_API.Models;
using System.Reflection.Metadata;
using static DMSQV_API.Data.DBConnector;

namespace DMSQV_API.Controllers
{
    public class Authen : Controller
    {
        DBConnector db = new DBConnector();
        CommonFunction commonfunction = new CommonFunction();
        SendEmail sendEmail = new SendEmail();
        public async Task<JsonResult> api_login(string code, string password)
        {
            // Kiểm tra user có tồn tại hau ko?
            // nếu user ID > 0 là tồn tại và tạo cookie trả về client + thông tin users + status = true
            // nếu user = 0 ko tồn tại user, trả về client status = false và user = null
            bool status = false;
            string encodePW = encodePassword.EncodePasswordMd5(password);
            var result = db.ExistUser(code, encodePW);
            var user_id = (int)result.data[0].Values.ToList()[0];

            if (user_id > 0) // có tồn tại user này rồi
            {
                // tạo cookie
                var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, user_id.ToString())
                };
                var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity));
                status = true;
                //HttpContext.Session.SetString("user_id", user_id.ToString());
                //var isCookiePresent = Request.Cookies.ToList();
            }
            var output = new
            {
                status = status,
                user = api_getUserProfile(user_id),
            };
            return Json(output);
        }

        public async Task<JsonResult> api_logout()
        {
            // clear cookie and session
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            HttpContext.Session.Clear();
            return Json(true);
        }


        public CheckUserLogin api_isLoginAndReturnUserProfile()
        {
            bool isLogin = true;
            // Lấy user_id dùng từ claim cookie
            var user_id = HttpContext.User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value;

            // Lấy các thông tin khác nếu cần
            var userInfor = HttpContext.User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier)?.Value;

            if (user_id == null)
            {
                user_id = "0";
                isLogin = false;
            }


            var output = new CheckUserLogin
            {
                status = isLogin,
                dataUsers = db.getUserProfile(int.Parse(user_id)),
            };

            return output;
        }


        public List<user> api_getUserProfile(int user_id)
        {
            List<user> dataUsers = db.getUserProfile(user_id);
            return dataUsers;
        }

        public object api_resetPW(string user_code)
        {
            bool status = false;
            string newPW = encodePassword.RandomString(6);
            string encodePW = encodePassword.EncodePasswordMd5(newPW);
            var result = db.resetPW(user_code, encodePW);
            if (result.rowEffected > 0)
            {
                status = true;
                sendEmail.sendEmailResetPW(user_code, newPW);
            }
            var output = new
            {
                status = status,
                data = result
            };

            return Json(output);
        }

        public object api_createNewAccount(string user_code, string user_name, string password, string buyer_code, string grade_id, string email, string dept_id)
        {
            bool status = false;
            string msg = "";
            var arrayParameter = new[] { user_code, user_name, password, grade_id, email, dept_id };
            int grade_id_int = int.Parse(grade_id);
            string[] dept_ids = dept_id.Split(',');
            bool testResult = commonfunction.checkArrayHasAnyElementNullOrEmpty(arrayParameter);
            if (!testResult)
            {
                var isExistUser = db.isExistEmployeeCode(user_code);
                if (isExistUser)
                {
                    status = false;
                    msg = $"This Employee Code {user_code} already register account, Please reset PW if you forgot";
                }
                else // tao tai khoan moi
                {
                    var result = db.CreateNewDMSAccount(user_code, user_name, password, buyer_code, grade_id_int, email, dept_ids);

                    status = true;
                    msg = "Create sucess! Please wait Admin verify you account!";
                }
            }
            else
            {
                status = false;
                msg = "Please input all information!";
            }

            var output = new
            {
                status = status,
                msg = msg,
            };
            return Json(output);
        }


        public object api_changeUserProfile(string user_name, string user_code, int grade_id, string buyer_code, string email)
        {
            bool status = false;
            string msg = "";
            var islogin = api_isLoginAndReturnUserProfile();
            if (islogin.status)
            {

                if (islogin.dataUsers[0].user_code != user_code) // user đang thay đổi user_code => phải check xem code mới đã có chưa
                {
                    // ktra use code mới
                    bool isExistUser_code = db.isExistEmployeeCode(user_code);
                    if (isExistUser_code) // đã có user code này
                    {
                        status = false;
                        msg = "code " + user_code + " already exist!";
                        goto exit;
                    }
                }
                else // cho phep edit profile
                {
                    string sql = $"UPDATE public.users SET user_name='{user_name}', user_code='{user_code}', buyer_code='{buyer_code}', grade_id={grade_id}, email='{email}' WHERE user_id = {islogin.dataUsers[0].user_id}";
                    var result = db.ExcuteQueryAndGetData(sql);
                    if (result.rowEffected > 0)
                    {
                        status = true;
                        msg = "Change Profile success!";

                    }
                }

            }

        exit:
            var output = new
            {
                status = status,
                msg = msg,
                dataUser = db.getUserProfile(islogin.dataUsers[0].user_id)
            };
            return Json(output);

        }

        // NEED UPDATE ACTUAL RESULT API
        public object api_getListUsers(string user_name, string user_code, int dept_id, int? page = 1, int? pageSize = 10)
        {
            bool status = false;
            string msg = "";
            var islogin = api_isLoginAndReturnUserProfile();
            List<object> data = new List<object>();
            if (islogin.status)
            {
                if (islogin.dataUsers[0].is_admin == false)
                {
                    msg = "You are not admin!";
                    status = false;
                    goto exit;
                }
                // đoạn này giả lập. Thực tế phỉa lấy data từ database
                for (int i = 0; i < 100; i++)
                {
                    // lấy dữ liệu từ database các trường thông tin này
                    var user = new 
                    {
                        user_id = 7,
                        user_name = "Nguyen Van Quy " + i ,
                        user_code =  "443975",
                        buyer_code = "",
                        grade_name = "G5",
                        email = "quy.nguyen324@canon.mail",
                        is_admin = true,
                        is_verified = true,
                        is_active = true,
                        is_delete = false,
                        lock_reason = "6 months not login!",
                        last_online = DateTime.Now,
                        create_date = DateTime.Now.AddDays(-1),
                        //....
                    };
                    data.Add(user);
                }
                status = true;
            }
            else
            {
                msg = "Please login!";
                status = false;
            }


        exit:
            var output = new
            {
                status = status,
                msg = msg,
                recordsTotal = 100, // sửa theo thực tế từ database
                recordsFiltered = 100, // sửa theo thực tế từ database
                page = page,
                pageSize = pageSize,
                Data = data,
            };
            return Json(output);
        }

        // NEED UPDATE ACTUAL RESULT API
        public object api_getUserProfileByID(int user_id)
        {
            bool status = false;
            string msg = "";
            dataReturn roles = new dataReturn();
            dataReturn userProfile = new dataReturn();
            var islogin = api_isLoginAndReturnUserProfile();
            if (islogin.status)
            {
                if (islogin.dataUsers[0].is_admin == false)
                {
                    msg = "You are not admin!";
                    status = false;
                    goto exit;
                }
                // đoạn này giả lập. Thực tế phỉa lấy data từ database
                string sqlGetUserProfile = $"select * from users where user_id = {user_id}";
                string sqlGetRoles = $"select * from userrole where user_id = {user_id}";
                 userProfile = db.ExcuteQueryAndGetData(sqlGetUserProfile);
                 roles = db.ExcuteQueryAndGetData(sqlGetRoles);
                status = true;
            }
            else
            {
                msg = "Please login!";
                status = false;
            }

        exit:
            var output = new
            {
                status = status,
                msg = msg,
                userProfile = userProfile.data[0],
                roles = roles.data
            };
            return Json(output);
        }

        // NEED UPDATE ACTUAL RESULT API
        public object api_changeOrAddRoleForUser(int user_id, int dept_id, int mr_role_id, int tpi_role_id, int po_role_id, int die_role_id, int dtf_role_id, int dsum_role_id, int dispose_role_id, int dcf_role_id)
        {
            bool status = true;
            string msg = "test";
            // chỉ admin mới được thao tác api này
            // xử lí data và update hoặc change role cho users

            var output = new
            {
                status = status,
                msg = msg,
            };

            return Json(output);
        }


        public object api_adminVerifyUser(int user_id, string user_name, string user_code, string buyer_code, int grade_id, string email, string lock_reason, string action )
        {
            bool status = true;
            string msg = "test";
            // chỉ admin mới được thao tác api này
            // xử lí data và update hoặc change role cho users

            var output = new
            {
                status = status,
                msg = msg,
            };

            return Json(output);
        }


    }
}
