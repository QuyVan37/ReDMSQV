﻿using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace DMSQV_API.Controllers
{
    public class CommonFunction : Controller
    {
        public bool checkArrayHasAnyElementNullOrEmpty<T>(T[] array)
        {
            if ((array == null || array.Length == 0))
            {
                return true;
            } else
            {
                return array.Any(item => item == null);
            }
           
        }
    }
}
