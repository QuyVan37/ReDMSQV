import { Injectable } from '@angular/core';
import { Observable , throwError} from 'rxjs';
import { HttpClient, HttpHeaders, HttpParams,HttpErrorResponse  } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { Router , UrlTree} from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AppAPIService {

  constructor(private http: HttpClient) { }
  private apiAuthenURL = 'http://localhost:5201/API';

  getGradeCategory():Observable<any[]> {
    return this.http.get<any[]>(this.apiAuthenURL + '/api_DMSGradeCategory', { withCredentials: true })
  }

  getRolesCategory():Observable<any[]> {
    return this.http.get<any[]>(this.apiAuthenURL + '/api_DMSRoleCategory', { withCredentials: true })
  }






}
