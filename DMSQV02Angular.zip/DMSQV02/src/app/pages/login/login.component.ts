import { Component } from '@angular/core';
import { AuthenService } from '../../API-Services/authen.service';
import { Router } from '@angular/router';
import { FormControl, FormGroup } from '@angular/forms';
import { DataTrasferService } from '../../common-services/data-transfer.service';
import { DOMServiceService } from '../../common-services/dom-service.service';
import { CookieService } from 'ngx-cookie-service';
import * as moment from 'moment';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  public massage = ""
  constructor(private authen: AuthenService,
    private router: Router,
    private dataTrasferService: DataTrasferService,
    private DOMServiceService : DOMServiceService,
    private cookieService : CookieService,
  
  ) { }


  loginForm: FormGroup = new FormGroup({
    code: new FormControl('443975'),
    password: new FormControl('1')
  })

  submitLogin() {
    this.DOMServiceService.onloading('.btn_login')
    this.authen.login(this.loginForm.value).subscribe(
      data => {
        if (data.status == true) {
          this.dataTrasferService.transferUserProfile(data.user[0])
          // luu cookie vao store rate
          const myCookieValue = this.cookieService.get('.AspNetCore.Cookies');
          let json_user = JSON.stringify(data.user)
          sessionStorage.setItem("user",json_user )

          // quay lai trang truoc khi login
          let currentURL = localStorage.getItem('currentURL')+""
          console.log(currentURL)
          location.href = currentURL
        } else {
          this.massage = "Code or Password not correct!"
        }
        this.DOMServiceService.onloaded('.btn_login')
        
      },
      error => {
        this.massage = "System Erorr!"
        this.DOMServiceService.onloaded('.btn_login')
      }

    )
  }

}
