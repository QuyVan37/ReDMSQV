import { Component, OnInit, NgZone, ChangeDetectorRef } from '@angular/core';
import { AuthenService } from '../../API-Services/authen.service';
import { Router } from '@angular/router';
import { DataTrasferService } from '../../common-services/data-transfer.service';
import { DOMServiceService } from '../../common-services/dom-service.service';
import { AppAPIService } from '../../API-Services/app-api.service';
import moment from 'moment';
declare var $: any;
declare var bootstrap: any;
declare var Validator: any;
@Component({
  selector: 'app-main-layout',
  templateUrl: './main-layout.component.html',
  styleUrl: './main-layout.component.css'
})
export class MainLayoutComponent implements OnInit {

  userLogined: any;
  constructor(private authen: AuthenService,
    private router: Router,
    private dataTrasferService: DataTrasferService,
    private ngZone: NgZone,
    private changeDetected: ChangeDetectorRef,
    private domService: DOMServiceService,
    private APIservices: AppAPIService,
    

  ) { }

  ngOnInit(): void {
    this.userLogined = this.authen.isLogined()
   

    console.log( this.userLogined)
  }

  logout() {
    this.authen.logout().subscribe(res => {
      this.router.navigateByUrl('login')
      this.userLogined = this.authen.isLogined()
    })
  }

  async showUserProfile() {
    const offcanvasElement = document.getElementById('model_user_profile');
    const bsOffcanvas = new bootstrap.Offcanvas(offcanvasElement);
    this.createOptionForDept()
    this.renderRoleByDeptSelect()

    let result = await this.authen.isLoginedAndUserProfile().toPromise()
    if (result?.status) {
      this.userLogined = {
        status: true,
        user: result.user
      }
      bsOffcanvas.show();
    } else {
      bsOffcanvas.hide();
      this.router.navigateByUrl('login')
    }
  }


  async createGradeOptionElement() {
    let grades = await this.APIservices.getGradeCategory().toPromise()
    let result = this.domService.createOptionElement(grades, ["grade_name"], "grade_id", this.userLogined.user[0].grade_id)
    this.domService.appendToElement("select#grade_id", result)
    
  }

  async createRoleOptionElement(roleFor: string, selector: string, index:number) {
    let roles = await this.APIservices.getRolesCategory().toPromise()
    let result = this.domService.createOptionElement(roles, ["role_name"], "role_id", this.userLogined.user[index][roleFor])
    this.domService.appendToElement(selector, result)
  }

  createOptionForDept(){
    let result = this.domService.createOptionElement(this.userLogined.user, ["dept_name","factory"], "dept_id",this.userLogined.user[0].dept_id )
    this.domService.appendToElement("select#dept_id", result)
  }
  momentJS(datestring: string) {
    return moment(datestring).format("YYYY/MM/DD hh:mm:ss A")
  }

  renderRoleByDeptSelect(){
    let indexSelected = 0
    let s_dept_id = $('select#dept_id').val()
    console.log('s_dept_id'  + s_dept_id)
    if(typeof(s_dept_id) == undefined){
      indexSelected = 0
    }else {
      for(let i = 0; i < this.userLogined.user.length; i++){
        if(this.userLogined.user[i].dept_id == s_dept_id){
          indexSelected = i
        }
      }
    }
    console.log('indexSelected '  + indexSelected)

    this.createGradeOptionElement()
    this.createRoleOptionElement('mr_role_id', 'select#mr_role_id', indexSelected)
    this.createRoleOptionElement('po_role_id', 'select#po_role_id', indexSelected)
    this.createRoleOptionElement('tpi_role_id', 'select#tpi_role_id', indexSelected)
    this.createRoleOptionElement('die_role_id', 'select#die_role_id', indexSelected)
    this.createRoleOptionElement('dtf_role_id', 'select#dtf_role_id', indexSelected)
    this.createRoleOptionElement('dsum_role_id', 'select#dsum_role_id', indexSelected)
    this.createRoleOptionElement('dispose_role_id', 'select#dispose_role_id', indexSelected)
    this.createRoleOptionElement('dcf_role_id', 'select#dcf_role_id', indexSelected)
    
  }

  changeProfile(){
    console.log("ddd")
      this.domService.onloading(".btn_change_user_profile")
      Validator({
        form: '#form_edit_user',
        formGroupSelector: '.nice-form-group',
        rules: [
            Validator.isRequired('input[name=user_name]', 'Please input your full name'),
            Validator.isRequired('input[name=user_code]', 'Please input your code'),
            Validator.isRequired('input[name=email]', 'Please input your email'),
            Validator.isEmail('input[name=email]', 'Not correct Email'),
            Validator.isRequired('select[name=grade_id]', 'Please input your full name'),
        ],
        onSubmit: async function (data:any) {
           console.log(data)
          //  let result = await api_changeUserProfile(data)
          //  if (result.status) {
          //      showAlertMassage(result.msg, true)
          //  } else {
          //      showAlertMassage(result.msg, false)
          //  }
        }
    });

      this.domService.onloaded(".btn_change_user_profile")
  }

}
