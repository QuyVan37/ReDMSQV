import { Injectable } from '@angular/core';
declare var $: any;
declare var bootstrap: any;
@Injectable({
  providedIn: 'root'
})
export class DOMServiceService {

  constructor() { }

  onloading(selector: string) {
    $(selector).addClass('disabled')
    $(selector).children('.spinner-border').remove()
    $(selector).append(
      `
        <span class="spinner-border spinner-border-sm" aria-hidden="true"></span>
      `)
  }

  onloaded(selector: string) {
    $(selector).children('.spinner-border').remove()
    $(selector).removeClass('disabled')
  }


  createOptionElement(
    listOption: any[] | undefined,
    fields_view: Array<string>,
    Field_value: string,
    selected_Value: string
  ): string {
    let option = '<option value="">***</option>';
    listOption?.forEach(e => {
      let view: Array<string> = [];
      fields_view.forEach(f => {
        view.push(e[f]);
      });
      option += `<option ${e[Field_value] === selected_Value ? 'selected' : ''} value="${e[Field_value]}">${view.join('-')}</option>`;
    });
    return option;
  }

  appendToElement(selector: string, content : string){
    $(selector).empty().append(content)
  }











  

}