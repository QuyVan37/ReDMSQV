import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class DataTrasferService {

  constructor() { }

  private userSource = new BehaviorSubject<any>(null);
  currentUser = this.userSource.asObservable();

  transferUserProfile(user: any) {
    this.userSource.next(user);
  }

}
