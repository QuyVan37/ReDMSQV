import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';
import { AuthenService } from '../API-Services/authen.service';
import { map } from 'rxjs/operators';
import { DOMServiceService } from '../common-services/dom-service.service';
import { CookieService } from 'ngx-cookie-service';
import { DataTrasferService } from '../common-services/data-transfer.service';
export const authenticatorGuard: CanActivateFn = (route, state) => {

  const authService = inject(AuthenService);
  const router = inject(Router);
  const DomService = inject(DOMServiceService)
  const transferData = inject(DataTrasferService)
  const cookieService = inject(CookieService)
  console.log( "guard "+authService.isLogined().status)
  // luu current url
  localStorage.setItem("currentURL", state.url)
  let userLogin = authService.isLogined()
  if(userLogin.status){
    return true
  }else{
    router.navigateByUrl('login')
    return false
  }

};
