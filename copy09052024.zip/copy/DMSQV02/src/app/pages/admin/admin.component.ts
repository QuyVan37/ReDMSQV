import { Component, AfterViewInit, OnDestroy, Renderer2, ElementRef, OnInit, ViewChild, provideExperimentalZonelessChangeDetection } from '@angular/core';
import { Config } from 'datatables.net';
import { AuthenService } from '../../API-Services/authen.service';
import { Router, ActivatedRoute  } from '@angular/router';
import { DOMServiceService } from '../../common-services/dom-service.service';
import { AppAPIService } from '../../API-Services/app-api.service';
import { Subject } from 'rxjs';
import moment from 'moment';
declare var $: any;
declare var bootstrap: any;
declare var Validator: any;
declare var DataTable: any;
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrl: './admin.component.css',
  host: {ngSkipHydration: 'true'},
})
export class AdminComponent implements OnInit {
  private eventListenerClick!: () => void;
  private eventListener_change!: () => void;
  constructor(private authen: AuthenService,
    private router: Router,
    private route: ActivatedRoute,
    private DOMService: DOMServiceService,
    private APIservices: AppAPIService,
    private renderer: Renderer2,

  ) { }
  searchParameter = {
    page: 1,
    search: null,
  }


  dtOptions: any = {
    serverSide: false,
    paging: false,
    ordering: false,
    select: true, keys: true,
    scrollY: '300',
    scrollX: true,
    fixedColumns: {
      left: 2,
      right: 0
    },
    searching: false,
    columns: [{
      title: 'Name',
      data: 'user_name'
    }, {
      title: 'Code',
      data: 'user_code',
      render: function (data: any, type: any, row: any) {
        return `<button class="btn btn-sm btn-primary btn_show_modal_detail" data-user-id='${row.user_id}'>${data}</button>`
      }
    }, {
      title: 'Dept',
      data: 'dept_name'
    }, {
      title: 'Factory',
      data: 'factory'
    }, {
      title: 'Grade',
      data: 'grade_name'
    }, {
      title: 'email',
      data: 'email'
    }, {
      title: 'Admin',
      data: 'is_admin'
    }, {
      title: 'Verified',
      data: 'is_verified'
    }, {
      title: 'Active',
      data: 'is_active'
    }, {
      title: 'Delete',
      data: 'is_delete'
    }, {
      title: 'Lock reason',
      data: 'lock_reason'
    }, {
      title: 'Last Online',
      data: 'last_online',
      render: function (data: any, type: any, row: any) {
        return moment(data).format('YYYY/MM/DD HH:MM:SS A')
      }
    }, {
      title: 'Create',
      data: 'create_date',
      render: function (data: any, type: any, row: any) {
        return moment(data).format('YYYY/MM/DD HH:MM:SS A')
      }
    }
    ]
  };
  dtTrigger: Subject<any> = new Subject();
  ngOnInit(): void {
    let _that = this
    // start render
    this.renderTable(this.searchParameter)
    this.createDeptOptionElement()
    // Handle sự kiện click ngoài angular
   this.eventListenerClick =  this.renderer.listen(document, "click", function (e) {

      //1. trường hợp admin click vào page
      // => add page vào object searchParameter => render lại table
      let page = $(e.target).attr('data-page')
      if (page) {
        let isnewpage = _that.searchParameter.page != page
        if (isnewpage) {
          _that.searchParameter.page = page
          _that.renderTable(_that.searchParameter)
        }
      }

      //2. trường hợp admin click vào button code của users
      // => show cái modal "modalUserDetail" để xong thông tin của user đó
      let isBtnShowDetial = $(e.target).hasClass('btn_show_modal_detail')
      if (isBtnShowDetial) {
        let user_id = $(e.target).attr('data-user-id')
        _that.showModalUserDetail(user_id)
      }

      //3. Trường hợp admin click vào button Change role
      let btnChangeRole = $(e.target).hasClass('btn_admin_change_user_role')
      if (btnChangeRole) {
        let user_id = $(e.target).attr('data-user-id')
        _that.adminUpdateUserRole(user_id)
      }

      //4. Trường hợp admin click vào button save or verify user
      let btnVerify = $(e.target).hasClass('btn_admin_verified_users')
      if (btnVerify) {
        let action = $(e.target).attr('action')
        _that.adminVerifiedUser(action)
      }
    })

    //Handle sự kiện on change ngoài angular
    //3. Trường hợp admin chọn dept cho user
    //> show role hiện có nếu đã setup, hiện --- nếu dept chưa setup role
   this.eventListener_change =  this.renderer.listen(document, "change", function (e: any) {
      let isDeptSelected = $(e.target).attr('name') == "dept_id"
      if (isDeptSelected) {
        let user_id = $('input[name=user_id]').val()
        let dept_id = $(e.target).val()
        _that.renderRoleWhenDeptSelect(user_id, dept_id)
      }
    })



  }

  ngOnDestroy() {
    if (this.eventListenerClick) {
      this.eventListenerClick();
    }
    if (this.eventListener_change) {
      this.eventListener_change();
    }
    
  }

  async renderTable(searchParameter: any) {
    this.DOMService.onloading('.btn_search')
    let _that = this
    this.dtOptions.destroy = true,
      this.dtOptions.processing = true;
    let dataResult = await this.authen.getListUser(searchParameter).toPromise()
    if (dataResult?.status == false) {
      this.DOMService.showAlertMassage(dataResult.msg, false)
      return
    }
    this.dtOptions.data = dataResult?.data
    this.dtOptions.data.recordsFiltered = dataResult?.recordsFiltered
    this.dtOptions.data.recordsTotal = dataResult?.recordsTotal

    this.DOMService.pagination(dataResult?.page, dataResult?.pageSize, dataResult?.recordsTotal, '.render_paganation')
    this.dtTrigger.next(null)
    _that.DOMService.onloaded('.btn_search')
  }

  async createDeptOptionElement() {
    let depts = await this.APIservices.getListDept().toPromise()
    let result = this.DOMService.createOptionElement(depts?.data, ["dept_name", 'factory'], "dept_id", "")
    this.DOMService.appendToElement("select[name=dept_id]", result)
  }

  searchUsers() {
   
    let _that = this
    Validator({
      form: '#form_Search',
      formGroupSelector: '.nice-form-group',
      rules: [

      ],
      onSubmit: async function (data: any) {
        _that.searchParameter = {..._that.searchParameter, ...data}
        _that.renderTable(data)
        _that.router.navigate([], {
          relativeTo: _that.route,
          queryParams: { search: data },
          queryParamsHandling: 'merge' // This will keep existing query parameters and add new ones
        });
      }
    })
    
  }


  async showModalUserDetail(user_id: number) {
    let userProfile = await this.authen.getUserProfileByID(user_id).toPromise()
    if (userProfile?.status == false) {
      this.DOMService.showAlertMassage(userProfile.msg, false)
      return
    }
    this.DOMService.renderModalUserDetail(userProfile)
  }

  async renderRoleWhenDeptSelect(user_id: number, dept_id: number) {
    let userProfile = await this.authen.getUserProfileByID(user_id).toPromise()
    if (userProfile?.status == false) {
      this.DOMService.showAlertMassage(userProfile.msg, false)
      return
    }
    let roleOfDeptSelect = userProfile?.roles.find(e => e.dept_id == dept_id)
    $('select[name=mr_role_id]').val(roleOfDeptSelect ? roleOfDeptSelect.mr_role_id : '')
    $('select[name=po_role_id]').val(roleOfDeptSelect ? roleOfDeptSelect.po_role_id : '')
    $('select[name=tpi_role_id]').val(roleOfDeptSelect ? roleOfDeptSelect.tpi_role_id : '')
    $('select[name=die_role_id]').val(roleOfDeptSelect ? roleOfDeptSelect.die_role_id : '')
    $('select[name=dtf_role_id]').val(roleOfDeptSelect ? roleOfDeptSelect.dtf_role_id : '')
    $('select[name=dsum_role_id]').val(roleOfDeptSelect ? roleOfDeptSelect.dsum_role_id : '')
    $('select[name=dispose_role_id]').val(roleOfDeptSelect ? roleOfDeptSelect.dispose_role_id : '')
    $('select[name=dcf_role_id]').val(roleOfDeptSelect ? roleOfDeptSelect.dcf_role_id : '')

  }



  adminUpdateUserRole(user_id: number) {
    let _that = this
    Validator({
      form: '#form_update_role',
      formGroupSelector: '.nice-form-group',
      rules: [
        Validator.isRequired('select[name=dept_id]', 'Must select department!'),
        Validator.isRequired('select[name=mr_role_id]', 'Must select roles!'),
        Validator.isRequired('select[name=po_role_id]', 'Must select roles!'),
        Validator.isRequired('select[name=tpi_role_id]', 'Must select roles!'),
        Validator.isRequired('select[name=die_role_id]', 'Must select roles!'),
        Validator.isRequired('select[name=dtf_role_id]', 'Must select roles!'),
        Validator.isRequired('select[name=dsum_role_id]', 'Must select roles!'),
        Validator.isRequired('select[name=dispose_role_id]', 'Must select roles!'),
        Validator.isRequired('select[name=dcf_role_id]', 'Must select roles!'),
      ],
      onSubmit: async function (data: any) {
        _that.DOMService.onloading(".btn_admin_change_user_role")
        data.user_id = user_id
        let result = await _that.authen.changOrAddRolesForUser(data).toPromise()
        if (result?.status) {
          _that.DOMService.showAlertMassage(result.msg, true)
        } else {
          _that.DOMService.showAlertMassage(result?.msg, false)
        }
        _that.DOMService.onloaded(".btn_admin_change_user_role")
      }
    });


  }



  adminVerifiedUser(action: string) {

    let _that = this
    Validator({
      form: '#form_user_information',
      formGroupSelector: '.nice-form-group',
      rules: [
        Validator.isRequired('input[name=user_name]', 'Must input!'),
        Validator.isRequired('input[name=user_code]', 'Must input!'),
        Validator.isRequired('select[name=grade_id]', 'Must input!'),
        Validator.isRequired('input[name=email]', 'Must input!'),
      ],
      onSubmit: async function (data: any) {
        _that.DOMService.onloading('.btn_admin_verified_users')
        data.action = action
        let result = await _that.authen.adminChangeUserProfile(data).toPromise()
        if (result?.status) {
          _that.DOMService.showAlertMassage(result.msg, true)
        } else {
          _that.DOMService.showAlertMassage(result?.msg, false)
        }
        _that.DOMService.onloaded(".btn_admin_verified_users")
      }
    });
  }





}

