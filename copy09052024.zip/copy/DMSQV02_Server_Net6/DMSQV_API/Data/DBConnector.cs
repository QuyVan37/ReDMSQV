﻿using DMSQV_API.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Razor.TagHelpers;
using Npgsql;
using System.Data.Common;
using System.Text;

namespace DMSQV_API.Data
{
    public class DBConnector
    {
        //START*** Cấu hình kết nối đến Postgress **//
        string connectionString = "Host=localhost;Username=postgres;Password=sa;Database=DMS";

        public class dataReturn
        {
            public int rowEffected { get; set; }
            public int totalCount { get; set; }
            public List<Dictionary<string, object>> data { get; set; }

        }

        public dataReturn ExcuteQueryAndGetData(string sql)
        {
            int rowEffected = 0;
            List<Dictionary<string, object>> data = new List<Dictionary<string, object>>();
            using (var connection = GetConnection())
            {
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = sql;
                    using (var reader = command.ExecuteReader())
                    {
                        rowEffected = reader.RecordsAffected;
                        while (reader.Read())
                        {
                            var row = new Dictionary<string, object>();
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                row.Add(reader.GetName(i), reader.GetValue(i) == DBNull.Value ? "" : reader.GetValue(i));
                            }
                            data.Add(row);
                        }
                    }
                    connection.Close();
                }
            }
            var output = new dataReturn
            {
                rowEffected = rowEffected,
                data = data
            };
            return output;
        }

        public dataReturn ExcuteFunctionAndGetListData(string sql)
        {
            int rowEffected = 0;
            int totalCount = 0;
            List<Dictionary<string, object>> data = new List<Dictionary<string, object>>();
            using (var connection = GetConnection())
            {
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = sql;
                    
                    using (var reader = command.ExecuteReader())
                    {
                        rowEffected = reader.RecordsAffected;
                        while (reader.Read())
                        {
                            var row = new Dictionary<string, object>();
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                row.Add(reader.GetName(i), reader.GetValue(i) == DBNull.Value ? "" : reader.GetValue(i));
                                var a = reader.GetName(i);
                                if (reader.GetName(i) == "total_count")
                                {
                                    totalCount = reader.GetInt32(i);
                                }
                            }
                            data.Add(row);
                        }
                    }
                    connection.Close();
                }
            }
            var output = new dataReturn
            {
                rowEffected = rowEffected,
                data = data,
                totalCount = totalCount
            };
            return output;

        }


        private DbConnection GetConnection()
        {

            var connection = new NpgsqlConnection(connectionString);
            connection.Open();
            return connection;
        }

        //END*** Cấu hình kết nối đến Postgress **//


        // Start các chuỗi kết nối đến databse

        public dataReturn ExistUser(string code, string password)
        {
            var today = DateTime.Now;
            string sql = $"update users set last_online = '{today}' where user_code = '{code}' and password = '{password}'; " +
                $"SELECT CASE WHEN EXISTS ( SELECT 1  FROM users u WHERE user_code = '{code}' and password = '{password}')" +
                $"THEN (SELECT u.user_id FROM users u WHERE user_code = '{code}' and password = '{password}') ELSE 0 END AS result;";

            var resutl = ExcuteQueryAndGetData(sql);
            // nếu ko tồn tại thì return 0, nếu tồn tại user thì return user_id
            return resutl;
        }

        public List<user> getUserProfile(int user_id)
        {
            string sql = $"SELECT u.user_id, user_name, user_code, buyer_code, grade_id, email,  is_admin, is_verified,is_active, is_delete, lock_reason, last_online, create_date  ,d.dept_id, dept_name, division, factory ,c.tpi_role_id, c.mr_role_id, c.po_role_id, c.die_role_id, c.dtf_role_id, c.dsum_role_id, c.dispose_role_id,c.dcf_role_id from userrole c " +
                $"inner join users u on c.user_id = u.user_id  " +
                $"inner join  department d on c.dept_id = d.dept_id " +
                $"where c.user_id = {user_id}";

            List<user> dataUsers = new List<user>();
            using (var connection = GetConnection())
            {
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = sql;
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var user = new user
                            {
                                user_id = reader.GetInt32(0),
                                user_name = reader.GetString(1),
                                user_code = reader.GetString(2),
                                buyer_code = reader.GetString(3),
                                grade_id = reader.GetInt32(4),
                                email = reader.GetString(5),
                                is_admin = reader.GetBoolean(6),
                                is_verified = reader.GetBoolean(7),
                                is_active = reader.GetBoolean(8),
                                is_delete = reader.GetBoolean(9),
                                //lock_reason = reader.IsDBNull(10) ? null : reader.GetString(10),
                                lock_reason =  reader.GetString(10),
                                last_online = reader.GetDateTime(11),
                                create_date = reader.GetDateTime(12),
                                dept_id = reader.GetInt32(13),
                                dept_name = reader.GetString(14),
                                division = reader.GetString(15),
                                factory = reader.GetString(16),
                                tpi_role_id = reader.GetInt32(17),
                                mr_role_id = reader.GetInt32(18),
                                po_role_id = reader.GetInt32(19),
                                die_role_id = reader.GetInt32(20),
                                dtf_role_id = reader.GetInt32(21),
                                dsum_role_id = reader.GetInt32(22),
                                dispose_role_id = reader.GetInt32(23),
                                dcf_role_id = reader.GetInt32(24),
                            };
                            dataUsers.Add(user);
                        }
                    }
                    connection.Close();
                }
            }


            return dataUsers;
        }

        public dataReturn getDMSGradeCatergory()
        {
            string sql = $"SELECT * FROM gradecategory";
            var result = ExcuteQueryAndGetData(sql);
            return result;
        }

        public dataReturn getDMSRoleCatergory()
        {
            string sql = $"SELECT * FROM rolecategory";
            var result = ExcuteQueryAndGetData(sql);
            return result;
        }

        public dataReturn getListDept()
        {
            string sql = $"SELECT * FROM department";
            var result = ExcuteQueryAndGetData(sql);
            return result;
        }
        public dataReturn getListUser(string? user_name, string? user_code, string? dept_id, int? page = 1, int? pageSize = 10)
        {

            string sql = $"SELECT * from get_list_user_after_search('{user_name}','{user_code}','{dept_id}',{page},{pageSize})";

            var result = ExcuteFunctionAndGetListData(sql);
            return result;
        }
        public dataReturn getMRTypeCategory()
        {
            string sql = $"SELECT * FROM mr_type_category";
            var result = ExcuteQueryAndGetData(sql);
            return result;
        }

        public dataReturn getSupplierList()
        {
            string sql = $"SELECT * FROM suppliers";
            var result = ExcuteQueryAndGetData(sql);
            return result;
        }
        public dataReturn resetPW(string code, string encodePW)
        {
            string sql = $"UPDATE users set password = '{encodePW}' WHERE user_code = '{code}'";
            var result = ExcuteQueryAndGetData(sql);
            return result;
        }

        public bool isExistEmployeeCode(string user_code)
        {
            /// <summary>
            /// Signs in a principal using the default authentication scheme.
            /// The default authentication scheme is determined by the `isExistEmployeeCode` property,
            /// which indicates whether to check for an existing employee code.
            /// 
            /// Returns `true` if a user with the specified `user_code` already exists in the system,
            /// otherwise returns `false`.
            /// </summary>
            /// <param name="user_code">The user code to authenticate.</param>
            /// <returns>True if the user exists, false otherwise.</returns>
            bool status = false;
            string sql = $"SELECT user_id FROM users u WHERE user_code ILIKE '%{user_code}%'";
            var result = ExcuteQueryAndGetData(sql);

            if (result.data.Count() > 0)
            {
                status = true;
            }
            return status;
        }

        public dataReturn CreateNewDMSAccount(string user_code, string user_name, string password, string buyer_code, int grade_id, string email, string[] dept_ids)
        {
            int user_id = 0;
            var result = new dataReturn();
            var encodePW = encodePassword.EncodePasswordMd5(password);
            // 1. insert vao bang user va lay duoc user_id
            string sqlInsertUser = $"INSERT INTO public.users(user_name, user_code, password, buyer_code, grade_id, email, is_admin, is_verified, is_active, is_delete, lock_reason, last_online, create_date)" +
                $"VALUES ('{user_name}', '{user_code}', '{encodePW}', '{buyer_code}', {grade_id}, '{email}', {false}, {false}, {false}, {false}, '{"Waiting Admin verify you register!"}','{DateTime.Now}' ,'{DateTime.Now} ');";
            var resultInsertUser = ExcuteQueryAndGetData(sqlInsertUser);
            if (resultInsertUser.rowEffected > 0)
            {
                string sql_getnewUser_id = $"SELECT u.user_id FROM users u WHERE user_code = '{user_code}'";
                var user_id_raw = ExcuteQueryAndGetData(sql_getnewUser_id);
                user_id = (int)user_id_raw.data[0].Values.ToList()[0];
                foreach (var dept_id_str in dept_ids)
                {
                    int dept_id_int = int.Parse(dept_id_str);
                    //2. insert vao bang userrole 
                    string sqlInsertRole = $"INSERT INTO public.userrole( user_id, dept_id, tpi_role_id, mr_role_id, po_role_id, die_role_id, dtf_role_id, dsum_role_id, dispose_role_id, dcf_role_id)" +
                                            $"VALUES ({user_id},{dept_id_int},{1},{1},{1},{1},{1},{1},{1},{1});";
                    result = ExcuteQueryAndGetData(sqlInsertRole);
                }
            }
            return result;
        }


        public dataReturn getMRList(string search, string? supplier_id, string? mr_type_id, int? page = 1, int? pageSize = 10)
        {
            //**** go to store procudure
            string sql = $"SELECT * from get_list_mr_after_search('{search}','{supplier_id}','{mr_type_id}',{page},{pageSize})";

            var result = ExcuteFunctionAndGetListData(sql);
            return result;
        }

        public dataReturn getSumarizeMRPending()
        {
            //**** go to store procudure
            string sql = $"SELECT * from sumarize_mr_pending()";
            var result = ExcuteFunctionAndGetListData(sql);

            return result;
        }

        public dataReturn getMRByID(int mr_id) 
        {
            string sql = $"SELECT * FROM mr WHERE mr_id = {mr_id}";
            var output = ExcuteQueryAndGetData(sql);
            return output;
        }
        public dataReturn getMRStatusResponByID(int mRstatusID)
        {
            string sql = $"SELECT * FROM mr_status_category WHERE mr_status_id = {mRstatusID}";
            var output = ExcuteQueryAndGetData(sql);
            return output;
        }

    }
}
