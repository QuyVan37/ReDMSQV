﻿using DMSQV_API.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using static DMSQV_API.Data.DBConnector;

namespace DMSQV_API.Controllers
{
    public class MR_API : Controller
    {
        DBConnector db = new DBConnector();
        Authen authen = new Authen();

        public JsonResult api_getMRList(string search, string? supplier_id, string? mr_type_id, int? page = 1, int? pageSize = 50)
        {
            search = search?.Trim();
            bool status = false;
            string msg = "";
            var islogin = authen.isLoginAndReturnUserProfile(HttpContext);

            dataReturn data = new dataReturn();
            if (islogin.status)
            {
                data = db.getMRList(search, supplier_id, mr_type_id, page, pageSize);
                status = true;
            }
            else
            {
                msg = "Please login!";
                status = false;
            }


        exit:
            var output = new
            {
                status = status,
                msg = msg,
                recordsTotal = data.totalCount,
                recordsFiltered = data.totalCount,
                page = page,
                pageSize = pageSize,
                Data = data.data,
            };
            return Json(output);
        }

        public JsonResult api_getSumarizeMRPending()
        {
            var result = db.getSumarizeMRPending();
            return Json(result);
        }

        public JsonResult api_isExistMR(string part_no, string dim)
        {
            var result = new
            {
                status = true,
                msg = DateTime.Now + "MR was issue by NVQ on 11-11-2024, MRNo: 123456"
            };
            return Json(result);
        }

        public JsonResult api_issueMR(IFormCollection data)
        {
            var result = new
            {
                status = true,
                msg = DateTime.Now + "MR was issue by NVQ on 11-11-2024, MRNo: 123456"
            };
            return Json(result);
        }
        public JsonResult api_issueMRByExcel(IFormCollection file)
        {
            var result = new
            {
                status = true,
                msg = DateTime.Now + "MR was issue by NVQ on 11-11-2024, MRNo: 123456"
            };
            return Json(result);
        }

        public JsonResult api_approveMR(string mRIDs, string comment)
        {
            var result = new
            {
                status = true,
                msg = DateTime.Now + "MR was issue by NVQ on 11-11-2024, MRNo: 123456"
            };
            return Json(result);
        }

        public JsonResult api_rejectMR(string mRIDs, string comment)
        {
            var result = new
            {
                status = true,
                msg = DateTime.Now + "MR was issue by NVQ on 11-11-2024, MRNo: 123456"
            };
            return Json(result);
        }

        public JsonResult api_getMRByID(int id)
        {
            
            bool status = false;
            string msg = "";
            var islogin = authen.isLoginAndReturnUserProfile(HttpContext);

            dataReturn data = new dataReturn();
            if (islogin.status)
            {
                data = db.getMRByID(id);
                status = true;
            }
            else
            {
                msg = "Please login!";
                status = false;
            }


        exit:
            var output = new
            {
                status = status,
                msg = msg,
                Data = data.data,
            };
            return Json(output);
        }

        public JsonResult api_getMRStatusResponByID(int id)
        {

            bool status = false;
            string msg = "";
            var islogin = authen.isLoginAndReturnUserProfile(HttpContext);

            dataReturn data = new dataReturn();
            if (islogin.status)
            {
                data = db.getMRStatusResponByID(id);
                status = true;
            }
            else
            {
                msg = "Please login!";
                status = false;
            }


        exit:
            var output = new
            {
                status = status,
                msg = msg,
                Data = data.data,
            };
            return Json(output);
        }
    }
}
