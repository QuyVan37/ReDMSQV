import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { HttpClient, HttpHeaders, HttpParams, HttpErrorResponse } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { Router, UrlTree } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AppAPIService {

  constructor(private http: HttpClient, private router: Router) { }
  private apiCommonUrl = 'http://localhost:5019/commonAPI';
  private apiMRURL = 'http://localhost:5019/MR_API';
  private handleError(error: HttpErrorResponse) {
    try {

      if (error.status === 0) {
        // Lỗi phía client hoặc lỗi mạng
        console.error('An error occurred:', error.error);
      } else if (error.status === 404) {
        // Lỗi 404 - Không tìm thấy
        console.error('Not Found:', error.message);
      } else {
        // Các lỗi khác từ server
        console.error(`Backend returned code ${error.status}, body was: `, error.error);
      }
    } catch (e) {

    }

    // Trả về một observable với thông báo lỗi thân thiện với người dùng
    //location.href = '/error'
    return throwError(() => new Error('Something bad happened; please try again later.'));

  }

  private convertToFormData(data: any): FormData {
    let formData = new FormData()
    for (let key in data) {

      if (data.hasOwnProperty(key)) {
        formData.append(key, data[key]);
      }
    }
    return formData
  }

  getGradeCategory(): Observable<{ rowEffected: number, data: any[] }> {
    return this.http.get<{ rowEffected: number, data: any[] }>(this.apiCommonUrl + '/api_DMSGradeCategory', { withCredentials: true })
  }

  getRolesCategory(): Observable<{ rowEffected: number, data: any[] }> {
    return this.http.get<{ rowEffected: number, data: any[] }>(this.apiCommonUrl + '/api_DMSRoleCategory', { withCredentials: true })
  }

  getListDept(): Observable<{ rowEffected: number, data: any[] }> {
    return this.http.get<{ rowEffected: number, data: any[] }>(this.apiCommonUrl + '/api_GetListDept', { withCredentials: true })
  }

  getMRTypeCategory(): Observable<{ rowEffected: number, data: any[] }> {
    return this.http.get<{ rowEffected: number, data: any[] }>(this.apiCommonUrl + '/api_GetMRTypeCategory', { withCredentials: true })
  }

  getSupplierList(): Observable<{ rowEffected: number, data: any[] }> {
    return this.http.get<{ rowEffected: number, data: any[] }>(this.apiCommonUrl + '/api_GetSupplierList', { withCredentials: true })
  }

  getMRList(data: any): Observable<{ status: boolean, msg: string, page: number, pageSize: number, recordsTotal: number, recordsFiltered: number, data: any }> {
    let formData = this.convertToFormData(data);
    return this.http.post<any>(this.apiMRURL + '/api_getMRList', formData, { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }

  getSumarizeMRPending(): Observable<{ rowEffected: number, data: any[] }> {
    return this.http.get<any>(this.apiMRURL + '/api_getSumarizeMRPending', { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }

  isExistMR(data: any): Observable<{ status: boolean, msg: string }> {
    let formData = this.convertToFormData(data);
    return this.http.post<any>(this.apiMRURL + '/api_isExistMR', formData, { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }

  issueMR(data: any): Observable<{ status: boolean, msg: string }> {
    let formData = this.convertToFormData(data);
    return this.http.post<any>(this.apiMRURL + '/api_issueMR', formData, { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }
  issueMRByExcel(data: any): Observable<{ status: boolean, msg: string }> {

    return this.http.post<any>(this.apiMRURL + '/api_issueMRByExcel', data, { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }

  checkAndapproveMR(data: any): Observable<{ status: boolean, msg: string, success: any[], fail:any[] }> {
    let formData = this.convertToFormData(data);
    return this.http.post<any>(this.apiMRURL + '/api_checkAndApproveMR', formData, { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }

  rejectMR(data: any): Observable<{ status: boolean, msg: string, data: any[] }> {
    let formData = this.convertToFormData(data);
    return this.http.post<any>(this.apiMRURL + '/api_rejectMR', formData, { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }

  getMRById(mr_id: number): Observable<{ status: boolean, msg: string, data: any[] }> {
    return this.http.get<any>(this.apiMRURL + '/api_getMRByID/' + mr_id,  { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }

  getMRStatusRespon(statusID: number): Observable<{ status: boolean, msg: string, data: any[] }> {
    return this.http.get<any>(this.apiMRURL + '/api_getMRStatusResponByID/' + statusID,  { withCredentials: true }).pipe(
      catchError(this.handleError)
    )
  }
}
