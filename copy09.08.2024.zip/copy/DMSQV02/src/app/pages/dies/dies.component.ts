import { Component } from '@angular/core';

@Component({
  selector: 'app-dies',
  templateUrl: './dies.component.html',
  styleUrl: './dies.component.css'
})
export class DiesComponent {

}
